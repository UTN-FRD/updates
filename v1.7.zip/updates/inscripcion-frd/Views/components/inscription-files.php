<section>
	<h2>Documentación</h2>
	<h6>Utilice una aplicación de escaneo digital para subir la documentación. </h6>
	<p>Le sugerimos <i>Microsoft Office Lens - PDF Scanner</i> que puede descargar gratis desde: <br> <a href="https://apps.apple.com/es/app/microsoft-office-lens-pdf-scan/id975925059" title="Descargar Microsoft Office Lens - PDF Scanner"><img src="img/app-store-badge.png"/></a> o <a href="https://play.google.com/store/apps/details?id=com.microsoft.office.officelens" title="Descargar Microsoft Office Lens - PDF Scanner"><img src="./img/google-play-badge.png"/></a></p>
	<br><br>
	<div class="row">
		<div class="col-md question">
			<div class="image-upload">
				<label for="documentaciondni">
					<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
					<img id="documentaciondni-subido" src="./img/dni-front.jpg" height="200px" width="auto" />
					<br><span class="description">DNI (ambos lados) o Pasaporte</span>
				</label>
				<input  id="documentaciondni" name="documentaciondni" type="file" required>
				<div class="invalid-feedback">Es necesario subir este archivo</div>
			</div>
		</div>
		<div class="col-md question">
			<div class="image-upload">
				<label for="documentacioncuil">
					<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
					<img id="documentacioncuil-subido" src="./img/cuil.jpg" height="200px" width="auto" />
					<br><span>CUIL</span>
				</label>
				<input  id="documentacioncuil" name="documentacioncuil" type="file" required>
				<div class="invalid-feedback">Es necesario subir este archivo</div>
			</div>
		</div>
		<div class="col-md question">
			<div class="image-upload">
				<label for="documentacionnacimiento">
					<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
					<img id="documentacionnacimiento-subido" src="./img/partida.jpg" height="200px" width="auto" />
					<br><span>Acta de Nacimiento</span>
				</label>
				<input  id="documentacionnacimiento" name="documentacionnacimiento" type="file" required>
				<div class="invalid-feedback">Es necesario subir este archivo</div>
			</div>
		</div>
		<div class="col-md question">
			<div class="image-upload">
				<label for="documentacionanalitico">
					<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
					<img id="documentacionanalitico-subido" src="./img/analitico.jpg" height="200px" width="auto" />
					<br><span class="description">Constancia de finalizacion nivel medio o título analítico</span>
				</label>
				<input  id="documentacionanalitico" name="documentacionanalitico" type="file" required>
				<div class="invalid-feedback">Es necesario subir este archivo</div>
			</div>
		</div>
		<div class="col-md question">
			<div class="image-upload">
				<label for="documentaciontitulogrado">
					<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
					<img id="documentaciontitulogrado-subido" src="./img/analitico.jpg" height="200px" width="auto" />
					<br><span class="description">T&iacute;tulo de Grado</span>
				</label>
				<input  id="documentaciontitulogrado" name="documentaciontitulogrado" type="file" required>
				<div class="invalid-feedback">Es necesario subir este archivo</div>
			</div>
		</div>
		<div class="col-md question">
			<div class="image-upload">
				<label for="documentacioncv">
					<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
					<img id="documentacioncv-subido" src="./img/analitico.jpg" height="200px" width="auto" />
					<br><span class="description">Curr&iacute;culum Vitae</span>
				</label>
				<input  id="documentacioncv" name="documentacioncv" type="file" required>
				<div class="invalid-feedback">Es necesario subir este archivo</div>
			</div>
		</div>
		<div class="col-md question">
			<div class="image-upload">
				<label for="documentacioncertmaterias">
					<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
					<img id="documentacioncertmaterias-subido" src="./img/analitico.jpg" height="200px" width="auto" />
					<br><span class="description">Certificado de T&iacute;tulo en tr&aacute;mite</span>
				</label>
				<input  id="documentacioncertmaterias" name="documentacioncertmaterias" type="file" >
				<div class="invalid-feedback">Es necesario subir este archivo</div>
			</div>
		</div>
	</div>
</section>
