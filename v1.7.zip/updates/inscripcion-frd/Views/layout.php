<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Ingresantes &#8211; UTN</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
        <link rel="stylesheet" type="text/css" href="./css/styles.css">
        <link rel="stylesheet" type="text/css" href="./css/font-awesome.min.css">
		<script src="./js/commons.js"></script>
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-5XTL7WMTB6"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'G-558Q3PX3LQ');
		</script>
    </head>
    <body>
    	<nav class="navbar sticky-top navbar-light bg-light" style="background-color: white!important;">
			<a class="navbar-brand" href="#">
				<img src="img/utn-logo.jpg" width="250" alt="">
			</a>
			<ul class="navbar-nav">
				<li class="nav-item"><span style="cursor:pointer;padding:15px" data-toggle="modal" data-target="#contactModal">CONTACTO</span></li>
			</ul>
		</nav>
		<nav class="navbar sticky-top frd-band">
			<h1>INSCRIPCION</h1>
		</nav>
		<div class="container">
		<?php
			$controller = new Controller();
			$controller -> showPage();
		?>	
		<?php include 'contact.php' ?>		
		</div>
	</body>
</html>

