<?php
require_once('Modells/Data.php');
require_once('Controllers/Controller.php');

if( $_SERVER['REQUEST_METHOD']=='GET' && preg_match("/rest.inscripciones.(\d+)/i", $_SERVER['REQUEST_URI']) ){
	// method: GET 
	// /rest/inscripciones/[id]
	$data = Controller::getInscriptionDetail( preg_match("/rest.inscripciones.(\d+)/i", $_SERVER['REQUEST_URI'], $out) ? $out[1] : '' );
	header('Content-Type: application/json');
	echo json_encode( $data );

}else if( $_SERVER['REQUEST_METHOD']=='GET' && preg_match("/rest.inscripciones/i", $_SERVER['REQUEST_URI']) ){
	// method: GET 
	// /rest/inscripciones
	$data = Data::fetchInscriptions();	
	header('Content-Type: application/json');
	echo json_encode( $data );

}else if( $_SERVER['REQUEST_METHOD']=='PUT' && preg_match("/rest.inscripciones.(\d+)/i", $_SERVER['REQUEST_URI']) ){
	$id = preg_match("/rest.inscripciones.(\d+)/i", $_SERVER['REQUEST_URI'], $out) ? $out[1] : '';
	// method: PUT 
	// /rest/inscripciones/[id]
	// data: {legajo: string, error: string}
	$data = json_decode(file_get_contents('php://input'));
	if( Data::updateSysAcadData($id, $data->legajo, $data->error) ){
		header('HTTP/1.0 204 No Content');
		exit;
	}else{
		header('HTTP/1.0 500 Internal Server Error');
		echo "Error al guardar el registro";
		exit;
	}

}else{
	// Method not found
	header('HTTP/1.0 405 Method Not Allowed');
	echo "405 Method Not Allowed";
	exit;
}


?>