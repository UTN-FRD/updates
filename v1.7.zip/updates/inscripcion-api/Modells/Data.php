<?php
require_once('Connection.php');

class Data extends Connection{

    public static function checkUser($user){
        $stmt = Connection::connect()->prepare("SELECT * FROM users WHERE username = :username AND password = md5(:password) ");
        $stmt->bindParam(':username', $user['username'], PDO::PARAM_STR);
        $stmt->bindParam(':password', $user['password'], PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function fetchInscriptions(){
        $db = Connection::connect();
        $stmt = $db->prepare("SELECT value FROM `configuration` WHERE id='SA_CARRERA'");
        $stmt->execute();
        $carreras = $stmt->fetchColumn();
        if($carreras && !empty(trim($carreras))){
            $carreras=' carrera in ('.$carreras.') and ';
        }

        $stmt = $db->prepare("SELECT value FROM `configuration` WHERE id='I_SEDE'");
        $stmt->execute();
        $sedes = $stmt->fetchColumn();
        if($sedes && !empty(trim($sedes))){
            $sedes=' lugarcursado in ('.$sedes.') and ';
        }

        $stmt = $db->prepare("SELECT `id` as id, `alumnonumerodocumento` as numero_documento, `alumnotipodocumento` as tipo_documento FROM `inscriptions`, (SELECT value FROM `configuration` WHERE id='SA_STATE') ss where ".$carreras.$sedes." state=ss.value and (legajo_sysacad is null or legajo_sysacad = '')");

        $stmt->execute();
        $r = array();
        $r = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public static function fetchInscription($id){
        $stmt = Connection::connect()->prepare("SELECT i.`id` as id,
         `alumnoapellido` as apellidos,
         `alumnonombres` as nombres, 
         `alumnotipodocumento` as tipo_documento, 
         `alumnonumerodocumento` as numero_documento, 
         `alumnocuil` as cuil, 
         `alumnosexo` as sexo, 
         `alumnogenero` as identidad_genero, 
         `alumnogenerodet` as detalle_genero,
         `alumnoestadocivil` as id_estado_civil, 
         `contactoemail` as email, 
         `contactoemailalternativo` as email_alternativo, 
         `contactotelefonofijo` as telefono, 
         `contactotelefonomovil` as celular, 
         `emergenciatelefono` as telefono_emergencia, 
         `emergenciacontacto` as contacto_emergencia, 
         `carrera` as id_carrera, 
         `lugarcursado` as extensiona, 
         `formaingreso` as id_forma_ingreso, 
         `tipocursado` as tipo_cursado, 
         `introductoriointensivo` as curso_intensivo,
         `nacfechanacimiento` as fecha_nacimiento, 
         `nacnacionalidad` as nacionalidad, 
         `nacvencdni` as vencimiento_dni, 
         `nacpais` as pais_nacimiento, 
         `nacprovincia` as provincia_nacimiento, 
         `naclocalidad` as localidad_nacimiento, 
         `nacpartidodepartamento` as partido_nacimiento, 
         `nacgruposanguineo` as grupo_sanguineo, 
         if(`d`.`id` is null,'NO','SI') as discapacidad,
         CERTDISCAP as CERTDISCAP, 
         NEAEAUDITI as NEAEAUDITI, 
         NEAEVISUAL as NEAEVISUAL, 
         NEAEMOTRIZ as NEAEMOTRIZ, 
         NEAEPSICOS as NEAEPSICOS, 
         if(NEAEOTRAS is null OR NEAEOTRAS='' ,'NO','SI') as OTRAS,
         NEAEOTRAS as NEAEOTRAS, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_DIFICU) as AUD_DIFICU, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_COMUNI) as AUD_COMUNI, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_COM_LA) as AUD_COM_LA, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_COMOTR) as AUD_COMOTR, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_APOYO) as AUD_APOYO, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_APY_I) as AUD_APY_I, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_APY_A) as AUD_APY_A, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_APY_O) as AUD_APY_O, 
         if(NEAEAUDITI is null OR NEAEAUDITI='', '', AUD_APY_D) as AUD_APY_D, 
         
         if(NEAEVISUAL is null OR NEAEVISUAL='', '', VIS_DIFICU) as VIS_DIFICU, 
         if(NEAEVISUAL is null OR NEAEVISUAL='', '', VIS_APOYO) as VIS_APOYO, 
         if(NEAEVISUAL is null OR NEAEVISUAL='', '', VIS_APY_A) as VIS_APY_A, 
         if(NEAEVISUAL is null OR NEAEVISUAL='', '', VIS_APY_T) as VIS_APY_T, 
         if(NEAEVISUAL is null OR NEAEVISUAL='', '', VIS_APY_B) as VIS_APY_B, 
         if(NEAEVISUAL is null OR NEAEVISUAL='', '', VIS_APY_O) as VIS_APY_O, 
         if(NEAEVISUAL is null OR NEAEVISUAL='', '', VIS_APY_D) as VIS_APY_D, 
         
         if(NEAEMOTRIZ is null OR NEAEMOTRIZ='', '', MOT_APOYO) as MOT_APOYO, 
         if(NEAEMOTRIZ is null OR NEAEMOTRIZ='', '', MOT_APY_P) as MOT_APY_P, 
         if(NEAEMOTRIZ is null OR NEAEMOTRIZ='', '', MOT_APY_O) as MOT_APY_O, 
         if(NEAEMOTRIZ is null OR NEAEMOTRIZ='', '', MOT_APY_D) as MOT_APY_D, 

         if(NEAEPSICOS is null OR NEAEPSICOS='', '', PSI_DESCRI) as PSI_DESCRI, 
         if(NEAEPSICOS is null OR NEAEPSICOS='', '', PSI_APOYO) as PSI_APOYO, 
         if(NEAEPSICOS is null OR NEAEPSICOS='', '', PSI_APY_O) as PSI_APY_O, 
         if(NEAEPSICOS is null OR NEAEPSICOS='', '', PSI_APY_D) as PSI_APY_D, 

         if(NEAEOTRAS is null OR NEAEOTRAS='', '', OTRA_CUAL) as OTRA_CUAL, 
         if(NEAEOTRAS is null OR NEAEOTRAS='', '', OTRA_APY_O) as OTRA_APY_O, 
         if(NEAEOTRAS is null OR NEAEOTRAS='', '', OTRA_APY_D) as OTRA_APY_D, 
         if(NEAEOTRAS is null OR NEAEOTRAS='', '', OTRA_DISCA) as OTRA_DISCA,

         `domiciliocalle` as domicilio_calle, 
         `domicilionumero` as domicilio_numero, 
         `domiciliopiso` as domicilio_piso, 
         `domiciliolocalidad` as domicilio_localidad, 
         `domiciliopartido` as domicilio_partido, 
         `domicilioprovincia` as domicilio_provincia, 
         `domiciliocp` as domicilio_cp, 
         `secundarioegreso` as secundario_egreso, 
         `secundarioestado` as secundario_estado, 
         `secundarioanioegreso` as secundario_anio_egreso, 
         `secundariotituladoen` as secundario_titulo, 
         `secundariotecnico` as id_secundario_tecnico, 
         `secundarioanalitico` as id_titulo_sec,
         `secundariolocalidad` as secundario_localidad,
         `secundarioinstitucion` as secundario_colegio,
         `secundarioprovincia` as secundario_provincia,
         if(locate('secundariocue',(SELECT value FROM configuration where id='X_QUESTION'))>0, secundariocue, titulounivcue) as cue_entidad_educativa,
         `titulounivanioegreso` as titulo_anio_egreso,
         `titulouniventramite` as titulo_en_tramite,
         `titulounivinstitucion` as titulo_institucion,
         `titulounivlocalidad` as titulo_localidad,
         `titulounivnombre` as titulo_anterior,
         `titulounivprovincia` as titulo_provincia,
         `otrosestudiostipo` as otros_estudios, 
         `otrosestudioscarrera` as otra_carrera, 
         `otrosestudiosinstitucion` as otra_institucion, 
         `otrosestudiosmateriasaprobadas` as otra_aprobadas, 
         `otrosestudiosestado` as otra_estado, 
         `trabajotrabajas` as trabajo,
         `situacionlaboral` as id_situacion_laboral,
         `tipotrabajo` as id_tipo_trabajo,
         `trabajoocupacion` as id_ocupacion,
         `tipoocupacion` as id_tipo_ocupacion,
         `trabajoenque` as trabajo_cargo, 
         `trabajohoras` as id_trabajo_horas, 
         `trabajoempresa` as trabajo_empresa, 
         `trabajodireccion` as trabajo_direccion, 
         `trabajotelefono` as trabajo_telefono, 
         `trabajorelcarrera` as id_trabajo_relacion_carrera,
         `deporte` as deporte, 
         `tecnotienepc` as pc, 
         `tecnodondepc` as pc_acceso, 
         `tecnocelular` as cantidad_celulares, 
         `tecnotieneinternet` as tiene_internet, 
         `tecnointernet` as acceso_internet,
         `tecnousointernet` as uso_internet, 
         `hijosacargo` as id_hijos_a_cargo,
         `familiaacargo` as id_familia_a_cargo,
         `padreapellido` as padre_apellidos, 
         `padrenombre` as padre_nombres, 
         `padrefechanac` as padre_fecha_nac, 
         `padrevive` as padre_vive, 
         `padreestudios` as id_instruccion_padre, 
         `padretrabajo` as padre_trabajo, 
         `padresituacionlaboral` as id_situacion_laboral_padre,
         `padreobrasocial` as padre_obra_social, 
         `madreapellido` as madre_apellidos, 
         `madrenombre` as madre_nombres, 
         `madrefechanac` as madre_fecha_nac, 
         `madrevive` as madre_vive, 
         `madreestudios` as id_instruccion_madre, 
         `madretrabajo` as madre_trabajo, 
         `madresituacionlaboral` as id_situacion_laboral_madre,
         `madreobrasocial` as madre_obra_social, 
         `hermanoscantidad` as hermanos_cantidad, 
         `hermanosedades` as hermanos_edades, 
         `hermanosactividades` as hermanos_actividades, 
         `casatipo` as casa_tipo, 
         `casacondicion` as casa_condicion, 
         `casamediotraslado` as traslado,
         `documentacionanalitico`,
         `documentacioncuil`,
         `documentacioncv`,
         `documentaciondni`,
         `documentacionnacimiento`,
         `documentaciontitulogrado`
         FROM `inscriptions` i left join `discapacidad` d on i.id=d.id WHERE i.id=:id and state = (SELECT value FROM `configuration` WHERE id='SA_STATE')");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function fetchMatCom($cursoId){
        $stmt = Connection::connect()->prepare("select c.codigo as codigo, mc.id_materia as materia, mc.id_comision as comision from mat_com mc join cursos c on mc.id_curso=c.id where c.id=:id");
        $stmt->bindParam(':id', $cursoId, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);        
    }

    public static function updateSysAcadData($id, $legajo, $error){
        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET state_messages = concat(state_messages, concat(now(), '[SysAcad] legajo: ".$legajo." - error: ".$error."\n')), legajo_sysacad = :legajo, error_sysacad = :error, fecha_sysacad = NOW() where id = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':legajo', $legajo, PDO::PARAM_STR);
        $stmt->bindParam(':error', $error, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public static function fetchDocumentsIds(){
        $stmt = Connection::connect()->prepare("SELECT * FROM requisitosacad where related_field is not null");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function fetchConfiguration($id){
        $stmt = Connection::connect()->prepare("SELECT value FROM configuration where id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        
        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchInscriptionConfiguration(){
        $stmt = Connection::connect()->prepare("SELECT id, value FROM configuration where id IN ('I_MATERIA','I_COMISION') order by 1 asc");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

}
?>