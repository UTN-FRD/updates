update `configuration` set `value`='1.7' where `id`='VERSION';

CREATE TABLE `mat_com` ( `id` INT NOT NULL AUTO_INCREMENT , `id_curso` INT NOT NULL , `id_materia` INT NOT NULL , `id_comision` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
CREATE TABLE `cursos` ( `id` int(11) NOT NULL AUTO_INCREMENT, `id_especialidad` INT NOT NULL , `codigo` varchar(255) NOT NULL , `nombre` varchar(255) NOT NULL, `cupo` int(11) DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB;

update config_params set display='Desocupado' where field='situacionlaboral' and value='1';
update config_params set display='Trabaja' where field='situacionlaboral' and value='2';
delete from config_params where field='situacionlaboral' and value='3';
update config_params set display='No Trabaja' where field='situacionlaboral' and value='4';

delete FROM `config_params` WHERE field='tipocursado';
