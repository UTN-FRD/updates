<?php 
require_once('../Modells/emailer.php');

if (!empty($_POST["id"])) {
	echo Emailer::reenviarCorreo( $_POST["id"] );
} 
?>