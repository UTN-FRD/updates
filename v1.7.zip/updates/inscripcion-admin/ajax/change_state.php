<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["id"])) {
	echo Data::updateInscriptionField( $_POST["id"], "state", $_POST["state"] );
} 
?>