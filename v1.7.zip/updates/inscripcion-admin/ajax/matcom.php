<?php 
require_once('../Modells/Data.php');

if ($_POST["action"]=='crearcurso') {
    $idCarrera = $_POST["idCarrera"];
    $codigo = $_POST["codigo"];
    $nombre = $_POST["nombre"];
    $cupo = $_POST["cupo"];
    $result = Data::addCurso($idCarrera,$codigo,$nombre,$cupo);
    echo json_encode($result);
} else if ($_POST["action"]=='eliminarcurso'){
    $id = $_POST["id"];
    $result = Data::removeCurso($id);
    echo json_encode($result);
} else if ($_POST["action"]=='crearmatcom'){
    $idCurso = $_POST["idCurso"];
    $materia = $_POST["materia"];
    $comision = $_POST["comision"];
    $result = Data::addMatCom($idCurso, $materia, $comision);
    echo json_encode($result);
} else if ($_POST["action"]=='eliminarmatcom'){
    $id = $_POST["id"];
    $result = Data::removeMatCom($id);
    echo json_encode($result);
}


?>