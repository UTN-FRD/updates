<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["id"])) {
    $id = $_POST["id"];
    $carrera = Data::fetchCarreraDetail($id);
    $cursos = Data::fetchCursosForCarrera($id);
    $matcom = Data::fetchMatComForCarrera($id);

    echo json_encode( array(
                    "carrera" => $carrera,
                    "cursos" => $cursos,
                    "matcom" => $matcom
                ) );
} 
?>