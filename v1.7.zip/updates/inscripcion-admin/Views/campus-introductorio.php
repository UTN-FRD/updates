<?php
require_once('Modells/Data.php');

$controller = new Controller();
date_default_timezone_set('America/Argentina/Buenos_Aires');
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Ingresantes &#8211; UTN</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.css"/>
		<!-- https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css -->
		<link rel="stylesheet" type="text/css" href="css/styles.css">
		<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.js"></script>
		<script type="text/javascript" src="js/commons.js"></script>

		<script type="text/javascript" src="js/yadcf/jquery.dataTables.yadcf.js"></script>
		<link rel="stylesheet" type="text/css" href="js/yadcf/jquery.dataTables.yadcf.css">

		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-5XTL7WMTB6"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'G-');
		</script>
    </head>
    <body>
		<?= include 'components/navbar-menu.php' ?>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2>Introductorio para Ingenierías</h2>
					<table class="table">
						<thead>
							<tr>
								<th rowspan="2">Carrera</th>
								<th colspan="2">Introductorio</th>
								<th rowspan="2">Directo</th>
							</tr>
							<tr>
								<th>Verano</th>
								<th>Normal</th>
							</tr>
						</thead>
						<tbody>
							<tr id="7">
								<td>Ing. Eléctrica</td>
								<td class="SI"></td>
								<td class="NO"></td>
								<td class="X"></td>
							</tr>
							<tr id="27">
								<td>Ing. Química</td>
								<td class="SI"></td>
								<td class="NO"></td>
								<td class="X"></td>
							</tr>
							<tr id="17">
								<td>Ing. Mecánica</td>
								<td class="SI"></td>
								<td class="NO"></td>
								<td class="X"></td>
							</tr>
							<tr id="5">
								<td>Ing. Sistemas</td>
								<td class="SI"></td>
								<td class="NO"></td>
								<td class="X"></td>
							</tr>
							<tr id="totales">
								<td>Totales</td>
								<td class="SI"></td>
								<td class="NO"></td>
								<td class="X"></td>
							</tr>
							<tr id="total">
								<td colspan="3">Total</td>
								<td class="X"></td>
							</tr>
						</tbody>
					</table>
					<script>
					$(document).ready(function() {	
					<?php
					$totales=array(
						"SI"=>0,
						"NO"=>0,
						"X"=>0,
						""=>0
					);

					foreach (Data::getCantidadesIntroductorio() as $key => $value) {
						$totales[$value['introductoriointensivo']]=$totales[$value['introductoriointensivo']]+$value['cantidad'];
					?>
					$("tr#<?= $value['carrera_id'] ?>>.<?= $value['introductoriointensivo'] ?>").text(<?= $value['cantidad'] ?>); //<?= $value['carrera'] ?>

					<?php
					}
					?>
					});
					$("tr#totales>.SI").text(<?=$totales['SI']?>);
					$("tr#totales>.NO").text(<?=$totales['NO']?>);
					$("tr#totales>.X").text(<?=$totales['X']?>);
					$("tr#total>.X").text(<?=$totales['SI']+$totales['NO']+$totales['X']?>);
					</script>
				</div>
			</div>
			<div class="row">
				<div class="col-6">
				</div>
				<div class="col-6">
					<form action="ajax/exportCampus.php" method="get" accept-charset="utf-8">
						<input type="hidden" name="generate" value="1">
						<input type="hidden" name="path" value="<?= dirname($_SERVER['SCRIPT_FILENAME']) ?>">
						<button class="pull-right">Generar y descargar archivo</button>
					</form>
				</div>
			</div>
		</div>
		<style>
		th{text-align: center}
		td{text-align: right;}
		td:first-child{text-align: left;}
		tr:last-child{font-weight: bolder;}
		</style>
	</body>
</html>

