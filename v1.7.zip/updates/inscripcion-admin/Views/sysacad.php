<?php
require_once('Controllers/Controller.php');

$controller = new Controller();
$config = $controller->getConfigurations();

?>
<hr>
<h2>Migraci&oacute;n al SysAcad</h2>
<div class="alert alert-primary" role="alert">Inscripciones a exportar: <b><span id="apiamount"></span></b></div>
<div class="row">
	<div class="col">
		<!-- SA_STATE -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "SA_STATE";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="SA_STATE"><?= $row['description'] ?></label>
			<select id="SA_STATE" class="custom-select">
			  <option value="pendiente" <?= $row['value']=='pendiente'?"selected":"" ?>>Pendiente</option>
			  <option value="aprobado" <?= $row['value']=='aprobado'?"selected":"" ?>>Aprobado</option>
			</select>
		</div>
		<script>
			$("#SA_STATE").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=SA_STATE&value='+$(this).val(),
					success: function(data){
                        updateCant();
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
            function updateCant(){
				$.ajax({
					type: 'POST',
					url: './ajax/apiamount.php',
					success: function(data){
						$("#apiamount").html(JSON.parse(data)[0].cant);
					}
				});
            }
            $( document ).ready(function() {
                updateCant()
            });
		</script>
	</div>
	<div class="col">
		<!-- SEDE -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "I_SEDE";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="I_SEDE"><?= $row['description'] ?></label>
		    <input type="text" id="I_SEDE" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		</div>
		<script>
			$("#I_SEDE").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=I_SEDE&value='+$(this).val(),
					success: function(data){
						updateCant();
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>		
	</div>	
</div>
<h4>Carreras a exportar</h4>
<div class="row" >
		<!-- SA_CARRERA -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "SA_CARRERA";
		}, ARRAY_FILTER_USE_BOTH))[0];
		$carrerasSeleccionadas = explode(',',$row['value']);
		foreach ($controller->getAllCarreras() as $carr) {
		?>
		<div class="col-6">
			<div class="form-check form-check-inline">
				<input type="checkbox" class="form-check-input" name="SA_CARRERA" value="<?= $carr['value'] ?>" id="<?= $carr['value'] ?>" <?= in_array($carr['value'],$carrerasSeleccionadas)?"checked":"" ?>>
				<label class="form-check-label" for="inlineRadio1"><?= $carr['value'] ?> - <?= $carr['display'] ?></label>
			</div>
		</div>
		<?php
		}
		?>
</div>
<div class="row">
	<div class="col">
	</div>
</div>




<hr>
<div class="card">
  <div class="card-header">Configurar carga de aspirantes Web</div>
  <div class="card-body">
    <p class="card-text">Para configurar la migración de inscripciones, ingrese al menú del SysAcad: <b>Archivo -> Supervisión -> Configuración Aspirantes Web</b> e ingrese los siguientes valores:</p>
    <form>
        <div class="row mb-3">
            <label for="url" class="col-sm-4 col-form-label">URL</label>
            <div class="col-sm-8">
                <p class="form-control" id="url"><?php echo str_replace("admin/index.php","api/rest/inscripciones",sprintf("%s://%s%s",isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',$_SERVER['SERVER_NAME'],$_SERVER['SCRIPT_NAME'])); ?></p>
            </div>
        </div>
        <div class="row mb-3">
            <label for="usuariosysacad" class="col-sm-4 col-form-label">Usuario</label>
            <div class="col-sm-8">
                <p class="form-control" id="usuariosysacad">sysacad</p>
            </div>
        </div>
        <div class="row mb-3">
            <label for="passwordsysacad" class="col-sm-4 col-form-label">Password</label>
            <div class="col-sm-8">
                <p class="form-control" id="passwordsysacad">sys4c4d</p>
            </div>
        </div>
        <div class="row mb-3">
            <label for="estadoingresante" class="col-sm-4 col-form-label">Estado Ingresante</label>
            <div class="col-sm-8">
                <p class="form-control" id="estadoingresante">Seleccione un estado</p>
            </div>
        </div>
        <div class="row mb-3">
            <label for="estadoingresantepe" class="col-sm-4 col-form-label">Estado ingresante con persona existente</label>
            <div class="col-sm-8">
                <p class="form-control" id="estadoingresantepe">Seleccione un estado</p>
            </div>
        </div>
    </form>
  </div>
</div>
<hr>

<script>
function saveChangeCarrera(nameElem){
	var favorite = [];
	$.each($("input[name='"+nameElem+"']:checked"), function(){
		favorite.push($(this).val());
	});
	$.ajax({
		type: 'POST',
		url: './ajax/saveconfig.php',
		data:'id='+nameElem+'&value='+favorite.join(","),
		success: function(data){
		}
	});
}

$("input[name='SA_CARRERA']").change(function(){saveChangeCarrera('SA_CARRERA')});
</script>
