<?php
require_once('Controllers/Controller.php');

$controller = new Controller();

?>
<table id="example" class="display" >
    <thead>
        <tr>
            <th>Nombre de Usuario</th>
            <th>Correo Electrónico</th>
            <th>Rol</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
</table>
<hr>
<div class="row">

    <div class="col-12">
        <h3>Agregar Usuario</h3>
    </div>
    <div class="col-12">
        <div class="row">
            <div class="form-group col-4">
                <label for="username">Nombre de usuario</label>
                <input type="text" class="form-control" id="username" name="username">
            </div>
            <div class="form-group col-4">
                <label for="email">Correo Electrónico</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="form-group col-2">
                <label for="role">Rol</label>
                <select class="form-control" id="role" name="role" >
                    <option value="Consumidor">Consumidor</option>
                    <option value="Supervisor">Supervisor</option>
                    <option value="Admin">Administrador</option>
                </select>
            </div>
            <div class="form-group col-2">
                <br>
                <button id="adduser" class="btn btn-success">Agregar</button>
            </div>
        </div>
        <div class="row">
        <p>Detalle de los roles disponibles:</p>
        <ul>
            <li><b>Administrador:</b> Acceso total al sistema, puede ver todas las inscripciones, configuraciones y crear usuarios</li>
            <li><b>Supervisor:</b> Acceso a las inscripciones para gestionar los estados</li>
            <li><b>Consumidor:</b> Acceso a los reportes para descarga de datos de inscripciones en CSV</li>
        </ul>
        </div>
    </div>
</div>
<script>

var table;
$('#adduser').click(function(){
    $(this).prop('disabled', true);
    $.ajax({
        type: 'POST',
		url: './ajax/adduser.php',
		data:'username='+$('#username').val()+'&email='+$('#email').val()+'&role='+$('#role').val(),
		success: function(data){
            if(data.startsWith("[")){
                table.row.add(data).draw(false);
                $('#username').val('');
                $('#email').val('');
                $('#role').val('');
            }else{
                alert(data);
            }
            $('#adduser').prop('disabled', false);
        }
    });
});


$(document).ready(function() {
    table = $('#example').DataTable( {
        'processing': true,
        'serverSide': true,
        'search': { 'regex': true },
        'ajax': './ajax/dt_users.php',
        'columnDefs': [ 
            {
                'targets': -2,
                'data': null,
                'orderable': false,
                'defaultContent': '<button id="edituser" class="btn btn-info">Editar</button>'
            },
            {
                'targets': -1,
                'data': null,
                'orderable': false,
                'defaultContent': '<button id="deleteuser" class="btn btn-danger">Eliminar</button>'
            }
        ]
    } );

    yadcf.init(table, [
        {column_number : 2, data:['Admin','Supervisor','Consumidor'], column_data_type: "html", html_data_type: "text", filter_default_label: "Todos"}
        ]);

        $('#example tbody').on( 'click', 'button#deleteuser', function () {
            if(confirm("¿Está seguro que desea eliminar el usuario?")){
                $(this).attr('disabled', true);
                var parent = $(this).parents('tr');
                var data = table.row( parent ).data();
                $.ajax({
                    type: 'POST',
                    url: './ajax/removeuser.php',
                    data:'userid='+data[ 3 ],
                    success: function(data){
                        table.row(parent).remove().draw();
                        if( data != true ){
                            alert(data);
                        }
                    }
                });
            }
    } );

    $('#example tbody').on( 'click', 'button#edituser', function () {
        $("#usuarioModal input[type=checkbox]").prop('checked', false);
        var parent = $(this).parents('tr');
        var data = table.row( parent ).data();
        $("input[name=usuarioidmodal]").val( data[ 3 ] );
        $.ajax({
            type: 'POST',
            url: './ajax/getusuarioDetail.php',
            data:'id='+data[ 3 ],
            dataType: 'json',
            success: function(data){
                $("input[name=usuariomodemodal]").val( "edit" );
                
                $("input[name=usuarionombremodal]").val( data[0].username );
                $("input[name=usuariocorreomodal]").val( data[0].email );
                $("#usuariorolmodal").val( data[0].role ).change();
                
                if(data[0].lugarcursado) data[0].lugarcursado.split(" ").forEach(function(i){
                    if(i) $("#usuariosedesmodal #ea-"+i).prop('checked', true);
                });

                if(data[0].carreras) data[0].carreras.split(" ").forEach(function(i){
                    if(i) $("#usuariocarrerasmodal #"+i).prop('checked', true);
                });

                $('#usuarioModal').modal('show');

            }
        });
    } );

} );
</script>
<style>
</style>

<!-- Modal -->
<div class="modal fade" id="usuarioModal" tabindex="-1" role="dialog" aria-labelledby="usuarioModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="usuarioModalLabel">Editar usuario</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="usuariomodemodal" name="usuariomodemodal">
            <input type="hidden" id="usuarioidmodal" class="form-control" name="usuarioidmodal">
            <div class="form-group">
                <label for="usuarionombremodal">Nombre de usuario</label>
                <input type="text" id="usuarionombremodal" class="form-control" name="usuarionombremodal">
            </div>
            <div class="form-group">
                <label for="usuariocorreomodal">Correo Electrónico</label>
                <input type="text" id="usuariocorreomodal" class="form-control" name="usuariocorreomodal">
            </div>
            <div class="form-group">
                <label for="usuariorolmodal">Rol</label>
                <select id="usuariorolmodal" class="form-control" name="usuariorolmodal">
                    <option value="Consumidor">Consumidor</option>
                    <option value="Supervisor">Supervisor</option>
                    <option value="Admin">Administrador</option>
                </select>
            </div>
            <div class="row">
                <div class="col">
                    <div class="form-group" id="usuariosedesmodal">
                        <label><b>Extensi&oacute;n &Aacute;ulica</b></label>
                        <?php
                        foreach ($controller->getLugaresCursado() as $lc) {
                        ?>
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" name="ea-<?= $lc['value'] ?>" id="ea-<?= $lc['value'] ?>">
                            <label class="custom-control-label" for="ea-<?= $lc['value'] ?>"><?= $lc['display'] ?></label>
                        </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group" id="usuariocarrerasmodal">
                        <label><b>Carreras</b></label>
                        <?php
                        foreach ($controller->getActiveCarreras() as $fi) {
                        ?>
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" name="<?= $fi['value'] ?>" id="<?= $fi['value'] ?>">
                            <label class="custom-control-label" for="<?= $fi['value'] ?>"><?= $fi['display'] ?></label>
                        </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
            <button type="button" class="btn btn-primary" id="btnsaveusuariomodal">Guardar</button>
        </div>
        </div>
    </div>
</div>
<script>
    function editusuario(id,nombre){
        $("#usuarioModal input[type=checkbox]").prop('checked', false);
        $.ajax({
            type: 'POST',
            url: './ajax/getusuarioDetail.php',
            data:'id='+id,
            dataType: 'json',
            success: function(data){
                for(i in data){
                    $("#"+data[i].campo+" input[name="+data[i].campoid+"]").prop('checked', true);
                }
                $("input[name=usuariomodemodal]").val( "edit" );
                $("input[name=usuarioidmodal]").val( id );
                $("input[name=usuarionombremodal]").val( data.username );
                $("input[name=usuariocorreomodal]").val( data.email );
                $('#usuarioModal').modal('show');
            }
        });
    }
    function newusuario(){
        $("input[name=usuariomodemodal]").val( "new" );
        $("input[name=usuarioidmodal]").prop( "readonly", false );
        $("input[name=usuarioidmodal]").val( "" );
        $("input[name=usuarionombremodal]").val( "" );
        $('#usuarioModal').modal('show');
    }
    function saveChangeusuario(nameElem){
        var favorite = [];
        $.each($("input[name='"+nameElem+"']:checked"), function(){
            favorite.push($(this).val());
        });
        $.ajax({
            type: 'POST',
            url: './ajax/saveconfig.php',
            data:'id='+nameElem+'&value='+favorite.join(","),
            success: function(data){
            }
        });
    }

    $("#btnsaveusuariomodal").click(function(){
        var sedes = '';
        var carreras='';
        $('#usuariosedesmodal input:checkbox:checked').each(function () {
            sedes = sedes+$(this).prop('name').substring(3)+' ';
        });
        $('#usuariocarrerasmodal input:checkbox:checked').each(function () {
            carreras = carreras+$(this).prop('name')+' ';
        });
        $.ajax({
            type: 'POST',
            url: './ajax/saveusuario.php',
            data:'mode='+$("#usuariomodemodal").val()+'&id='+$("#usuarioidmodal").val()+'&nombre='+$("#usuarionombremodal").val()+'&correo='+$("#usuariocorreomodal").val()+'&rol='+$("#usuariorolmodal").val()+'&lugarcursado='+sedes+'&carreras='+carreras,
            success: function(data){
                if($("#usuariomodemodal").val()=='edit'){
                    $("#usuario"+$("#usuarioidmodal").val()+">td:first-child").text($("#usuarioidmodal").val()+' - '+$("#usuarionombremodal").val());
                }else{
                    $("#list-usuarios").append('<tr id="usuario'+$("#usuarioidmodal").val()+'"><td>'+$("#usuarioidmodal").val()+' - '+$("#usuarionombremodal").val()+'</td><td><input type="checkbox" name="OPEN_CARRE" value="'+$("#usuarioidmodal").val()+'" ></td><td><input type="checkbox" name="SA_usuario" value="'+$("#usuarioidmodal").val()+'" ></td><td><button class="btn btn-info usuario" onclick="editusuario('+$("#usuarioidmodal").val()+', \''+$("#usuarionombremodal").val()+'\')">Editar</button></td></tr>');
                }
                $('#usuarioModal').modal('hide');
            }
        });
    });
</script>
