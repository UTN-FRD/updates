<?php
require_once('Controllers/Controller.php');

$controller = new Controller();
$questions = $controller->getQuestions();
$allQuestions = $controller->getAllQuestions();
$results = $controller->getActiveQuestions();
$activeQuestions = explode('|',$results);
$config = $controller->getConfigurations();
?>

<p>Las preguntas marcadas son las que se muestran en el formulario de inscripción</p>

<h5>Referencias</h5>
<p><i class="fa fa-info-circle btn-info"></i> - Al presionar este bot&oacute;n se muestra información adicional de la pregunta</p>
<p><i class="fa fa-share"></i> - Indica que esta pregunta se envía al SysAcad</p>
<form>
<?php include './Views/questions2.php' ?>
</form>

<script>
$(document).ready(function(){
	$(".question input").change(function(){
		var elem = $(this);
		var ids = [];
		$('.question input:checked').each(function(i, e) {
		    ids.push($(this).val());
		});
		$.ajax({
			type: 'POST',
			url: './ajax/updateactivequestion.php',
			data:'a='+ids.join('|'),
			dataType: "json",
			success: function(data){
				if(data)
					alert(data);
			}
		});
	});
	$(".btn-info").click(function(){
		var field = $(this).data('field');
		$.ajax({
			type: 'POST',
			url: './ajax/getquestionvalues.php',
			data:'field='+field,
			dataType: "json",
			success: function(data){
				var msg = '';
				if(data.length==0){
					msg = 'Este campo no tiene valores disponibles';
				}else{
					var msg = 'Valores:\n';
					for(d in data){
						msg += data[d].display + '\n';
					}
				}
				alert(msg);
			}
		});
	});
});
</script>
<style>
.fa{
	padding: 0 5px;
	margin: 2px 5px;
}
.btn-info{
	cursor:pointer
}
</style>