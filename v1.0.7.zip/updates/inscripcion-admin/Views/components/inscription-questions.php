<input type="hidden" name="id" id="id" value="<?=$_GET['id']?>">
<section>
	<h2>Carrera</h2>
	<div class="form-group question">
		<label for="carrera">Carrera</label>
		<select class="custom-select" id="carrera" name="carrera" data-related="lugarcursado|formaingreso" required >
			<option value="">--Seleccione--</option>
		</select>
		<div class="invalid-feedback">Debe seleccionar una opción</div>
	</div>
	<div class="form-group question">
		<label for="lugarcursado">Lugar cursado</label>
		<select class="custom-select" id="lugarcursado" name="lugarcursado" required >
			<option value="">--Seleccione--</option>
		</select>
		<div class="invalid-feedback">Debe seleccionar una opción</div>
	</div>
	<div class="form-group question">
		<label for="formaingreso">Forma ingreso</label>
		<select class="custom-select" id="formaingreso" name="formaingreso" required data-dynamic-section="formaingreso">
			<option value="">--Seleccione--</option>
		</select>
		<div class="invalid-feedback">Debe seleccionar una opción</div>
	</div>
	<div class="formaingreso-block collapse" data-showon="introductorio">
		<div class="form-group question">
			<label for="tipocursado">Modalidad de cursado</label>
			<select class="custom-select" id="tipocursado" name="tipocursado" >
				<option value="">--Seleccione--</option>
			</select>
			<div class="invalid-feedback">Debe seleccionar una opción</div>
		</div>
		<div class="mb-12 question">
			<label for="introductoriointensivo">Desea realizar el curso intensivo de verano?</label><br>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" id="introductoriointensivo" name="introductoriointensivo" value="SI" >
				<label for="" class="form-check-label">SI</label>
			</div>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" id="introductoriointensivo" name="introductoriointensivo" value="NO" >
				<label for="" class="form-check-label">NO</label>
			</div>
		</div>
	</div>
</section>
<section>
	<h2>Alumno</h2>
	<div class="form-group question">
		<label for="alumnoapellido">Apellido</label>
		<input type="text" class="form-control" id="alumnoapellido" name="alumnoapellido" required>
		<small id="alumnoapellidoHelpBlock" class="form-text text-muted">Si su apellido es compuesto, ingréselo completo.</small>
		<div class="invalid-feedback">Este valor es obligatorio.</div>
	</div>
	<div class="form-group question">
		<label for="alumnonombres">Nombres</label>
		<input type="text" class="form-control" id="alumnonombres" name="alumnonombres" required>
		<small id="alumnonombreHelpBlock" class="form-text text-muted">Si su nombre es compuesto, ingréselo completo.</small>
		<div class="invalid-feedback">Este valor es obligatorio.</div>
	</div>
	<div class="form-group question">
		<label for="alumnotipodocumento">Tipo de Documento</label>
		<select class="custom-select" id="alumnotipodocumento" name="alumnotipodocumento" required>
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="form-group question">
		<label for="alumnonumerodocumento">Número de Documento</label>
		<input type="text" class="form-control" id="alumnonumerodocumento" name="alumnonumerodocumento" required>
		<div class="invalid-feedback">Este valor es obligatorio.</div>
	</div>
	<div class="form-group question">
		<label for="alumnocuil">CUIL</label>
		<input type="cuil" class="form-control" id="alumnocuil" name="alumnocuil" pattern="([0-9]{2})-([0-9]{8})-([0-9]{1})">
		<div class="invalid-feedback">Este valor es obligatorio y debe estar en formato 99-99999999-9</div>
	</div>
	<div class="form-group question">
		<label for="alumnosexo">Sexo (como figura en su documento)</label>
		<select class="custom-select" id="alumnosexo" name="alumnosexo" required>
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="form-group question">
		<label for="alumnoestadocivil">Estado Civil</label>
		<select class="custom-select" id="alumnoestadocivil" name="alumnoestadocivil" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="mb-12 question">
		<label for="discapacidad">¿Posee una dificultad severa o que genere una discapacidad?<br>(El dato es solo para garantizar una accesibilidad dentro de la Universidad)</label><br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" name="discapacidad"  value="SI" required data-dynamic-section="discapacidad" >
			<label for="" class="form-check-label">SI</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" name="discapacidad"  value="NO" required data-dynamic-section="discapacidad" >
			<label for="" class="form-check-label">NO</label>
		</div>
	</div>
	<br>
	<div class="discapacidad-block collapse" data-showon="SI">	
		<div class="form-group question">
			<label for="discapacidad">Cuál o Cuales?</label>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="auditiva">
				<label class="form-check-label" for="">Auditiva (necesita audífono, interprete, con implante)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="cardiaca">
				<label class="form-check-label" for="">Cardíaca (movilidad o capacidad laboral reducida)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="motora">
				<label class="form-check-label" for="">Motora (con o sin uso de silla o elemento, amputaciones)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="visual">
				<label class="form-check-label" for="">Visual (ceguera, visión reducida)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="neurologica">
				<label class="form-check-label" for="">Neurología (Epilepsia, Esclerosis múltiple, ACV, etc)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="psicologica">
				<label class="form-check-label" for="">Psicológica o psiquiátrica (por diversos trastornos como ansiedad, pánico, fobias, etc.)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="renal">
				<label class="form-check-label" for="">Renal (con o sin diálisis)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="respiratoria">
				<label class="form-check-label" for="">Respiratoria (con disminución de capacidad)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadtipo[]" value="lenguaje">
				<label class="form-check-label" for="">Trastornos del lenguaje (afasias, dislexias, tartamudez, etc.)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" name="discapacidadtipo[]" class="form-check-input" id="discapacidadtipootro" value="otro">
				<label class="form-check-label" for="">Otras </label>
				<input type="text" name="discapacidadtipootro" class="form-control collapse">
				<div class="invalid-feedback collapse">Debe especificar este valor.</div>
			</div>
		</div>
		<br>
		<div class="mb-12 question">
			<label for="discapacidadmedicacion">¿Requiere actualmente de medicación?</label><br>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" name="discapacidadmedicacion" value="SI">
				<label for="" class="form-check-label">SI</label>
			</div>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" name="discapacidadmedicacion" value="NO">
				<label for="" class="form-check-label">NO</label>
			</div>
		</div>
		<br>
		<div class="mb-12 question">
			<label for="discapacidadcertificado">¿Posee Certificado de Discapacidad Único?</label><br>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" name="discapacidadcertificado" value="SI">
				<label for="" class="form-check-label">SI</label>
			</div>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" name="discapacidadcertificado" value="NO">
				<label for="" class="form-check-label">NO</label>
			</div>
		</div>
		<br>
		<div class="mb-12 question">
			<label for="discapacidados">¿Posee Obra Social o Pre-paga?</label><br>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" name="discapacidados" value="SI" data-dynamic-section="discapacidadoscual">
				<label for="" class="form-check-label">SI</label>
			</div>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" name="discapacidados" value="NO" data-dynamic-section="discapacidadoscual">
				<label for="" class="form-check-label">NO</label>
			</div>
		</div>
		<div class="form-group discapacidadoscual-block collapse question" data-showon="SI">
			<label for="discapacidadoscual">¿Cuál?</label>
			<input type="text" class="form-control" name="discapacidadoscual" >
		</div>
		<br>
		<div class="form-group question">
			<label for="discapacidadbarreras">Barreras que enfrenta para estudiar</label>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadbarreras[]" value="transporte">
				<label class="form-check-label" for="">Trasporte hasta la facultad</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadbarreras[]" value="desplazarse">
				<label class="form-check-label" for="">Desplazarse, caminar, subir escaleras</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadbarreras[]" value="manipular">
				<label class="form-check-label" for="">Manipular objetos, escribir</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadbarreras[]" value="parado">
				<label class="form-check-label" for="">Permanecer parado o sentado</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadbarreras[]" value="oir">
				<label class="form-check-label" for="">Oír, distinguir palabras</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadbarreras[]" value="hablar">
				<label class="form-check-label" for="">Hablar</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadbarreras[]" value="leer">
				<label class="form-check-label" for="">Leer, aún con anteojos</label>
			</div>
			<div class="form-check">
				<input type="checkbox" name="discapacidadbarreras[]" class="form-check-input" value="otro">
				<label class="form-check-label" for="">Otras </label>
				<input type="text" name="discapacidadbarrerasotro" class="form-control collapse">
				<div class="invalid-feedback collapse">Debe especificar este valor.</div>
			</div>
		</div>
		<br>
		<div class="form-group question">
			<label for="discapacidadelementos">¿Utiliza habitualmente alguno de los siguientes elementos?</label>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="baston">
				<label class="form-check-label" for="">Bastón blanco o verde</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="lector">
				<label class="form-check-label" for="">Lector de texto (Jaws, NVDA)</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="muletas">
				<label class="form-check-label" for="">Bastones, andadores o muletas</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="audifonos">
				<label class="form-check-label" for="">Audífonos</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="protesis">
				<label class="form-check-label" for="">Otras prótesis u órtesis</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="braille">
				<label class="form-check-label" for="">Escritura Braille</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="ocular">
				<label class="form-check-label" for="">Prótesis ocular</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="silla">
				<label class="form-check-label" for="">Silla de ruedas</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="interprete">
				<label class="form-check-label" for="">Intérprete de señas</label>
			</div>
			<div class="form-check">
				<input type="checkbox" class="form-check-input" name="discapacidadelementos[]" value="programas">
				<label class="form-check-label" for="">Programas informáticos para leer/escribir</label>
			</div>
			<div class="form-check">
				<input type="checkbox" name="discapacidadelementos[]" class="form-check-input" value="otro">
				<label class="form-check-label" for="">Otras </label>
				<input type="text" name="discapacidadelementosotro" class="form-control collapse">
				<div class="invalid-feedback collapse">Debe especificar este valor.</div>
			</div>
		</div>
		<br>
		<div class="mb-12 question">
			<label for="discapacidadautismo">¿Presentas algún tipo de discapacidad o patología psicosocial/espectro autista que, a tu criterio, pueda interferir de alguna forma en el aprendizaje?</label><br>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" name="discapacidadautismo" value="SI" data-dynamic-section="discapacidadautismocual">
				<label for="" class="form-check-label">SI</label>
			</div>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" name="discapacidadautismo" value="NO" data-dynamic-section="discapacidadautismocual">
				<label for="" class="form-check-label">NO</label>
			</div>
		</div>
		<div class="form-group discapacidadautismocual-block collapse question" data-showon="SI">
			<label for="discapacidadautismocual">¿Cuál o cuáles?</label>
			<input type="text" class="form-control" name="discapacidadautismocual" >
		</div>
		<div class="form-group discapacidadresponsable question">
			<label for="discapacidadresponsable">¿A quién recurrir en caso de que lo necesites? (profesional/familiar)</label>
			<input type="text" class="form-control" name="discapacidadresponsable" >
		</div>

	</div>
</section>
<section>
	<h2>Nacimiento</h2>
	<div class="form-group question">
		<label for="nacfechanacimiento">Fecha Nacimiento</label>
		<input type="date" class="form-control" id="nacfechanacimiento" name="nacfechanacimiento" min="1920-01-01" max="2005-01-01" required>
		<div class="invalid-feedback">La fecha está fuera de rango, verifique el año</div>
	</div>
	<div class="form-group question">
		<label for="nacnacionalidad">Nacionalidad</label>
		<select class="custom-select" id="nacnacionalidad" name="nacnacionalidad" required>
			<option value="">--Seleccione--</option>
		</select>
		<div class="invalid-feedback">Debe seleccionar una opción</div>
	</div>

	<div class="form-group collapse question">
		<label for="nacvencdni">Fecha de Vencimiento del DNI</label>
		<input type="date" class="form-control" id="nacvencdni" name="nacvencdni"  >
	</div>

	<div class="form-group question">
		<label for="nacpais">País</label>
		<input type="text" class="form-control" id="nacpais" name="nacpais" required >
	</div>
	<div class="form-group question">
		<label for="nacprovincia">Provincia</label>
		<input type="text" class="form-control" id="nacprovincia" name="nacprovincia" required >
	</div>
	<div class="form-group question">
		<label for="naclocalidad">Localidad</label>
		<input type="text" class="form-control" id="naclocalidad" name="naclocalidad" required >
	</div>
	<div class="form-group question">
		<label for="nacpartidodepartamento">Partido/Departamento</label>
		<input type="text" class="form-control" id="nacpartidodepartamento" name="nacpartidodepartamento"  >
	</div>
	<div class="form-group question">
		<label for="nacgruposanguineo">Grupo Sanguíneo</label>
		<select class="custom-select" id="nacgruposanguineo" name="nacgruposanguineo">
			<option value="">--Seleccione--</option>
		</select>
	</div>
</section>
<section>
	<h2>Domicilio Actual</h2>
	<div class="form-group question">
		<label for="domiciliocalle">Calle</label>
		<input type="text" class="form-control" id="domiciliocalle" name="domiciliocalle" required >
	</div>
	<div class="form-group question">
		<label for="domicilionumero">Número</label>
		<input type="text" class="form-control" id="domicilionumero" name="domicilionumero" required >
	</div>
	<div class="form-group question">
		<label for="domiciliopiso">Piso</label>
		<input type="text" class="form-control" id="domiciliopiso" name="domiciliopiso"  >
	</div>
	<div class="form-group question">
		<label for="domiciliolocalidad">Localidad</label>
		<input type="text" class="form-control" id="domiciliolocalidad" name="domiciliolocalidad" required >
	</div>
	<div class="form-group question">
		<label for="domiciliopartido">Partido</label>
		<input type="text" class="form-control" id="domiciliopartido" name="domiciliopartido"  >
	</div>
	<div class="form-group question">
		<label for="domicilioprovincia">Provincia / Estado / Departamento</label>
		<input type="text" class="form-control" id="domicilioprovincia" name="domicilioprovincia" required >
	</div>
	<div class="form-group question">
		<label for="domiciliocp">Código Postal</label>
		<input type="text" class="form-control" id="domiciliocp" name="domiciliocp" required >
	</div>
</section>
<section>
	<h2>Contacto</h2>
	<div class="form-group telefono question">
		<label for="contactotelefonofijo">Teléfono Fijo</label>

		<div class="input-group">
			<div class="input-group-prepend">
				<span class="input-group-text"><i class="fa fa-phone"></i></span>
			</div>
			<input type="phone" pattern="\d*" name="contactotelefonofijo" maxlength="5" class="form-control prefix" placeholder="Ingrese el código de área" required>
			<div class="input-group-prepend">
				<span class="input-group-text"> - </span>
			</div>
			<input type="phone" pattern="\d*" maxlength="8" class="form-control nbr" placeholder="Ingrese el número de teléfono" required>
		</div>

		<input type="hidden" id="contactotelefonofijo" name="contactotelefonofijo">
		<div class="invalid-feedback">Debe ingresar al menos un teléfono.</div>
	</div>
	<div class="form-group telefono question">
		<label for="contactotelefonomovil">Teléfono Móvil</label>
				<div class="input-group">
			<div class="input-group-prepend">
				<span class="input-group-text"><i class="fa fa-phone"></i></span>
			</div>
			<input type="phone" pattern="\d*" name="contactotelefonomovil" maxlength="5" class="form-control prefix" placeholder="Ingrese el código de área" required>
			<div class="input-group-prepend">
				<span class="input-group-text"> - 15 - </span>
			</div>
			<input type="phone" pattern="\d*" maxlength="8" class="form-control nbr" placeholder="Ingrese el número de teléfono" required>
		</div>

		<input type="hidden" class="form-control" id="contactotelefonomovil" name="contactotelefonomovil">
		<div class="invalid-feedback">Debe ingresar al menos un teléfono.</div>
	</div>
	<div class="form-group question">
		<label for="contactoemail">Correo Electrónico</label>
		<input type="email" class="form-control" id="contactoemail" name="contactoemail" readonly="true" required>
		<div class="invalid-feedback">Este valor es obligatorio.</div>
	</div>
	<div class="form-group question">
		<label for="contactoemailalternativo">Correo Electrónico Alternativo</label>
		<input type="email" class="form-control" id="contactoemailalternativo" name="contactoemailalternativo">
	</div>
</section>
<section>
	<h2>Secundario</h2>
	<div class="mb-12 question">
		<label for="secundarioegreso">Secundario Completo</label><br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="secundarioegreso" name="secundarioegreso" value="SI" data-dynamic-section="secundarioegreso" required>
			<label for="" class="form-check-label">SI</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="secundarioegreso" name="secundarioegreso" value="NO" data-dynamic-section="secundarioegreso" required>
			<label for="" class="form-check-label">NO</label>
		</div>
		<label class="invalid collapse">La finalización del secundario es obligatoria para la carrera seleccionada.</label>
	</div>
	<br>
	<div class="secundarioegreso-block collapse" data-showon="NO">
		<div class="form-group question">
			<label for="secundarioestado">Estado <span style="color:red">*</span></label>
			<select class="custom-select" id="secundarioestado" name="secundarioestado" data-required="required">
				<option value="">--Seleccione--</option>
			</select>
			<div class="invalid-feedback">Debe seleccionar una opción</div>

		</div>
	</div>
	<div class="secundarioegreso-block collapse" data-showon="SI">	
		<div class="form-group question">
			<label for="secundarioanioegreso">Año Egreso</label>
			<input type="text" class="form-control" id="secundarioanioegreso" name="secundarioanioegreso"  >
		</div>
	</div>
	<div class="form-group question">
		<label for="secundariotituladoen">Nombre del título secundario obtenido o a obtener</label>
		<input type="text" class="form-control" id="secundariotituladoen" name="secundariotituladoen" required >
	</div>
	<div class="mb-12 question">
		<label for="secundariotecnico">Secundario Técnico?</label><br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="secundariotecnico" name="secundariotecnico" value="2" required>
			<label for="" class="form-check-label">SI</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="secundariotecnico" name="secundariotecnico" value="1" required>
			<label for="" class="form-check-label">NO</label>
		</div>
	</div>
	<br>
	<div class="form-group question">
		<label for="secundarioanalitico">Constancia Analítico</label>
		<select class="custom-select" id="secundarioanalitico" name="secundarioanalitico" required>
			<option value="">--Seleccione--</option>
		</select>
	</div>

	<div class="form-group question">
		<label for="secundariocue">CUE del Colegio</label>
		<input type="text" class="form-control" id="secundariocue" name="secundariocue" required>
	</div>
	<div class="form-group question">
		<label for="secundarioinstitucion">Nombre Colegio</label>
		<input type="text" class="form-control" id="secundarioinstitucion" name="secundarioinstitucion" disabled >
	</div>
	<div class="form-group question">
		<label for="secundariolocalidad">Localidad</label>
		<input type="text" class="form-control" id="secundariolocalidad" name="secundariolocalidad" disabled >
	</div>
	<div class="form-group question">
		<label for="secundarioprovincia">Provincia</label>
		<input type="text" class="form-control" id="secundarioprovincia" name="secundarioprovincia" disabled >
	</div>
	<div class="form-group question">
		<label for="secundariodependede">Depende de</label>
		<select class="custom-select" id="secundariodependede" name="secundariodependede" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
</section>
<section>
	<h2>Estudios Universitarios o Superiores Previos</h2>
	<div class="form-group question">
		<label for="titulounivnombre">Titulo Universitario o Superior obtenido o a obtener (tal como figura en el diploma)</label>
		<input type="text" class="form-control" id="titulounivnombre" name="titulounivnombre" required >
	</div>
	<div class="mb-12 question">
		<label for="titulouniventramite">T&iacute;tulo en tr&aacute;mite</label><br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="titulouniventramite" name="titulouniventramite" value="2" required>
			<label for="" class="form-check-label">SI (s&oacute;lo para egresados de esta Instituci&oacute;n)</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="titulouniventramite" name="titulouniventramite" value="1" required>
			<label for="" class="form-check-label">NO</label>
		</div>
	</div>
	<br>
	<div class="form-group question">
		<label for="titulounivanioegreso">Año Egreso</label>
		<input type="text" class="form-control" id="titulounivanioegreso" name="titulounivanioegreso"  >
	</div>
	<div class="form-group question">
		<label for="titulounivcue">CUE de la Institución</label>
		<input type="text" class="form-control" id="titulounivcue" name="titulounivcue" required>
	</div>
	<div class="form-group question">
		<label for="titulounivinstitucion">Nombre de la Institución</label>
		<input type="text" class="form-control" id="titulounivinstitucion" name="titulounivinstitucion" disabled >
	</div>
	<div class="form-group question">
		<label for="titulounivlocalidad">Localidad</label>
		<input type="text" class="form-control" id="titulounivlocalidad" name="titulounivlocalidad" disabled >
	</div>
	<div class="form-group question">
		<label for="titulounivprovincia">Provincia</label>
		<input type="text" class="form-control" id="titulounivprovincia" name="titulounivprovincia" disabled >
	</div>

</section>
<section>
	<h2>Otros Estudios</h2>
	<div class="form-group question">
		<label for="otrosestudiostipo">Tipo</label>
		<select class="custom-select" id="otrosestudiostipo" name="otrosestudiostipo" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="form-group question">
		<label for="otrosestudioscarrera">Carrera</label>
		<input type="text" class="form-control" id="otrosestudioscarrera" name="otrosestudioscarrera"  >
	</div>
	<div class="form-group question">
		<label for="otrosestudiosinstitucion">Institución</label>
		<input type="text" class="form-control" id="otrosestudiosinstitucion" name="otrosestudiosinstitucion"  >
	</div>
	<div class="form-group question">
		<label for="otrosestudiosmateriasaprobadas">Cantidad de Materias Aprobadas</label>
		<input type="text" class="form-control" id="otrosestudiosmateriasaprobadas" name="otrosestudiosmateriasaprobadas"  >
	</div>
	<div class="form-group question">
		<label for="otrosestudiosestado">Estado</label>
		<select class="custom-select" id="otrosestudiosestado" name="otrosestudiosestado" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
</section>
<section>
	<h2>Trabajo</h2>
	<div class="mb-12 question">
		<label for="trabajotrabajas">Trabajas?</label><br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="trabajotrabajas" name="trabajotrabajas" value="SI" required>
			<label for="" class="form-check-label">SI</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="trabajotrabajas" name="trabajotrabajas" value="NO" required>
			<label for="" class="form-check-label">NO</label>
		</div>
	</div>
	<br>
	<div class="form-group question">
		<label for="situacionlaboral">Situación Laboral</label>
		<select class="custom-select" id="situacionlaboral" name="situacionlaboral" data-dynamic-section="trabajotrabajas" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="trabajotrabajas-block collapse" data-showon="1|4">
		<div class="form-group question">
			<label for="trabajoocupacion">Tipo de Trabajo</label>
			<select class="custom-select" id="trabajoocupacion" name="trabajoocupacion" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
	</div>
	<div class="trabajotrabajas-block collapse" data-showon="2">
		<div class="form-group question">
			<label for="tipotrabajo">Tipo de Trabajo</label>
			<select class="custom-select" id="tipotrabajo" name="tipotrabajo" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
		<div class="form-group question">
			<label for="tipoocupacion">Tipo de Ocupación</label>
			<select class="custom-select" id="tipoocupacion" name="tipoocupacion" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
		<div class="form-group question">
			<label for="trabajoenque">Ocupación/Cargo</label>
			<input type="text" class="form-control" id="trabajoenque" name="trabajoenque"  >
		</div>
		<div class="form-group question">
			<label for="trabajohoras">Cantidad de horas semanales</label>
			<select class="custom-select" id="trabajohoras" name="trabajohoras" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
		<div class="form-group question">
			<label for="trabajorelcarrera">Relación del trabajo con la carrera</label>
			<select class="custom-select" id="trabajorelcarrera" name="trabajorelcarrera" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
		<div class="form-group question">
			<label for="trabajoempresa">Nombre de la Empresa</label>
			<input type="text" class="form-control" id="trabajoempresa" name="trabajoempresa" >
		</div>
		<div class="form-group question">
			<label for="trabajodireccion">Dirección</label>
			<input type="text" class="form-control" id="trabajodireccion" name="trabajodireccion" >
		</div>
		<div class="form-group question">
			<label for="trabajotelefono">Teléfono</label>
			<input type="text" class="form-control" id="trabajotelefono" name="trabajotelefono" >
		</div>
	</div>
</section>
<section>
	<h2>Deporte</h2>
	<div class="form-group question">
		<label for="deporte">Qué practicas?</label>
		<input type="text" class="form-control" id="deporte" name="deporte"  >
	</div>
</section>
<section>
	<h2>Tecnología</h2>
	<div class="mb-12 question">
		<label for="tecnotienepc">Tiene acceso a una computadora?</label><br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="tecnotienepc" name="tecnotienepc"  value="SI" >
			<label for="" class="form-check-label">SI</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="tecnotienepc" name="tecnotienepc"  value="NO" >
			<label for="" class="form-check-label">NO</label>
		</div>
	</div>
	<br>

	<div class="form-group question">
		<label for="tecnodondepc">Desde donde?</label>
		<select class="custom-select" name="tecnodondepc" id="tecnodondepc">
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="form-group question">
		<label for="tecnocelular">Cuantos celulares hay en su hogar?</label>
		<input type="number" step="1" min="0" class="form-control" id="tecnocelular" name="tecnocelular" >
	</div>
	<div class="mb-12 question">
		<label for="tecnotieneinternet">Tiene acceso a Internet?</label><br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="tecnotieneinternet" name="tecnotieneinternet"  value="SI" >
			<label for="" class="form-check-label">SI</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="tecnotieneinternet" name="tecnotieneinternet"  value="NO" >
			<label for="" class="form-check-label">NO</label>
		</div>
	</div>
	<br>
	<div class="form-group question">
		<label for="tecnointernet">Desde donde accede a Internet?</label>
		<select class="custom-select" name="tecnointernet" id="tecnointernet">
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="form-group question">
		<label for="tecnousointernet">Utiliza internet para</label>
		<select class="custom-select" name="tecnousointernet" id="tecnousointernet">
			<option value="">--Seleccione--</option>
		</select>
	</div>
</section>
<section>
	<h2>Familia</h2>
	<div class="form-group question">
		<label for="familiaacargo">Cantidad de hijos y familiares a cargo</label>
		<select class="custom-select" id="familiaacargo" name="familiaacargo" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
</section>
<section>
	<h3>Padre</h3>
	<div class="form-group question">
		<label for="padreapellido">Apellido</label>
		<input type="text" class="form-control" id="padreapellido" name="padreapellido"  >
	</div>
	<div class="form-group question">
		<label for="padrenombre">Nombre</label>
		<input type="text" class="form-control" id="padrenombre" name="padrenombre"  >
	</div>
	<div class="form-group question">
		<label for="padrefechanac">Fecha de Nacimiento</label>
		<input type="date" class="form-control" id="padrefechanac" name="padrefechanac" min="1900-01-01" max="2005-01-01" >
	</div>
	<div class="mb-12 question" >
		<label for="padrevive">Vive?</label>
		<br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="padrevive" name="padrevive" value="SI" data-dynamic-section="padrevive">
			<label for="" class="form-check-label">SI</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="padrevive" name="padrevive" value="NO" data-dynamic-section="padrevive">
			<label for="" class="form-check-label">NO</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="padrevive" name="padrevive" value="desconoce" data-dynamic-section="padrevive">
			<label for="" class="form-check-label">Desconoce</label>
		</div>
	</div>
	<br> 
	<div class="padrevive-block collapse" data-showon="SI">
		<div class="form-group question">
			<label for="padreestudios">Nivel de estudios alcanzados</label>
			<select class="custom-select" id="padreestudios" name="padreestudios" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
		<div class="form-group question">
			<label for="padretrabajo">Trabajo/actividad</label>
			<input type="text" class="form-control" id="padretrabajo" name="padretrabajo"  >
		</div>
		<div class="form-group question">
			<label for="padresituacionlaboral">Situación Laboral</label>
			<select class="custom-select" id="padresituacionlaboral" name="padresituacionlaboral" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
		<div class="mb-12 question">
			<label for="padreobrasocial">Obra Social</label>
			<br>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" id="padreobrasocial" name="padreobrasocial"  value="SI" >
				<label for="" class="form-check-label">SI</label>
			</div>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" id="padreobrasocial" name="padreobrasocial"  value="NO" >
				<label for="" class="form-check-label">NO</label>
			</div>
		</div>
		<br> 
	</div>
</section>
<section>
	<h3>Madre</h3>
	<div class="form-group question">
		<label for="madreapellido">Apellido</label>
		<input type="text" class="form-control" id="madreapellido" name="madreapellido"  >
	</div>
	<div class="form-group question">
		<label for="madrenombre">Nombre</label>
		<input type="text" class="form-control" id="madrenombre" name="madrenombre"  >
	</div>
	<div class="form-group question">
		<label for="madrefechanac">Fecha de Nacimiento</label>
		<input type="date" class="form-control" id="madrefechanac" name="madrefechanac" min="1900-01-01" max="2005-01-01" >
	</div>
	<div class="mb-12 dynamic-section question">
		<label for="madrevive">Vive?</label>
		<br>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="madrevive" name="madrevive" value="SI" data-dynamic-section="madrevive">
			<label for="" class="form-check-label">SI</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="madrevive" name="madrevive" value="NO" data-dynamic-section="madrevive">
			<label for="" class="form-check-label">NO</label>
		</div>
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="madrevive" name="madrevive" value="desconoce" data-dynamic-section="madrevive">
			<label for="" class="form-check-label">Desconoce</label>
		</div>
	</div>
	<br> 
	<div class="madrevive-block collapse" data-showon="SI">
		<div class="form-group question">
			<label for="madreestudios">Nivel de estudios alcanzados</label>
			<select class="custom-select" id="madreestudios" name="madreestudios" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
		<div class="form-group question">
			<label for="madretrabajo">Trabajo/actividad</label>
			<input type="text" class="form-control" id="madretrabajo" name="madretrabajo"  >
		</div>
		<div class="form-group question">
			<label for="madresituacionlaboral">Situación Laboral</label>
			<select class="custom-select" id="madresituacionlaboral" name="madresituacionlaboral" >
				<option value="">--Seleccione--</option>
			</select>
		</div>
		<div class="mb-12 question">
			<label for="madreobrasocial">Obra Social</label>
			<br>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" id="madreobrasocial" name="madreobrasocial"  value="SI" >
				<label for="" class="form-check-label">SI</label>
			</div>
			<div class="form-check form-check-inline">
				<input type="radio" class="form-check-input" id="madreobrasocial" name="madreobrasocial"  value="NO" >
				<label for="" class="form-check-label">NO</label>
			</div>
		</div>
		<br>
	</div>
</section>
<section>
	<h3>Hermanos</h3>
	<div class="form-group question">
		<label for="hermanoscantidad">Cantidad</label>
		<input type="number" step="1" class="form-control" id="hermanoscantidad" name="hermanoscantidad"  >
	</div>
	<div class="form-group question">
		<label for="hermanosedades">Edades (separar por comas si son varios)</label>
		<input type="text" class="form-control" id="hermanosedades" name="hermanosedades"  >
	</div>
	<div class="form-group question">
		<label for="hermanosactividades">Actividades (separar por comas si son varias)</label>
		<input type="text" class="form-control" id="hermanosactividades" name="hermanosactividades"  >
	</div>
</section>
<section>
	<h3>Casa</h3>
	<div class="form-group question">
		<label for="casatipo">Tipo de Vivienda</label>
		<select class="custom-select" id="casatipo" name="casatipo" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="form-group question">
		<label for="casacondicion">Condición</label>
		<select class="custom-select" id="casacondicion" name="casacondicion" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
	<div class="form-group question">
		<label for="casamediotraslado">Cómo se trasladará a su lugar de estudios?</label>
		<select class="custom-select" id="casamediotraslado" name="casamediotraslado" >
			<option value="">--Seleccione--</option>
		</select>
	</div>
</section>
