<?php
require_once '../Modells/Util.php';
require_once '../Modells/Data.php';
require_once '../Modells/emailer.php';

$password = Util::randomPassword();
//save data
if ( !Data::saveUser($_POST['username'], $password, $_POST['email'], $_POST['role'] ) ) 
{
    echo 'Se produjo un error al guardar el usuario.';
} 
else 
{
    //send notification
    if( Emailer::enviarPassword($_POST['username'], $password, $_POST['email'], $_POST['role']) == 'success' )
    {
        echo '['.$_POST['username'].','.$_POST['email'].','.$_POST['role'].']';
    }
}
