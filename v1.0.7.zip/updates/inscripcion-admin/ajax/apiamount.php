<?php

require_once('../Modells/Data.php');

echo json_encode( Data::fetchAPIInscriptionsAmount() );
?>
