#!/bin/sh

if [ ! -f updates/update.zip ]; then
    echo "El archivo de actualización no es correcto."
    exit 1
fi

unzip updates/update.zip

mkdir bkp
# resguardo la configuración
cp Modells/Config.php updates/bkp/Config.php

# copio archivos de inscripción
mv updates/inscripcion-frd/* ..
mv updates/inscripcion-frd/.[!.]* ..
rmdir updates/inscripcion-frd
rm -f ../Modells/Config.php
cp updates/bkp/Config.php ../Modells/Config.php

# copio archivos de admin
mv updates/inscripcion-admin/* .
mv updates/inscripcion-admin/.[!.]* .
rmdir updates/inscripcion-admin
rm -f Modells/Config.php
cp updates/bkp/Config.php Modells/Config.php

# copio archivos de admin
mv updates/inscripcion-api/* ../api
mv updates/inscripcion-api/.[!.]* ../api
rmdir updates/inscripcion-api
rm -f ../api/Modells/Config.php
cp updates/bkp/Config.php ../api/Modells/Config.php

# verifico si actualizo la base de datos
if [ -f updates/update.sql ]; then
    dbuser=$(sed -n '/$dbuser = / s/.*\= '"'"'*//p' updates/bkp/Config.php | cut -d\' -f 1)
    dbpass=$(sed -n '/$dbpass = / s/.*\= '"'"'*//p' updates/bkp/Config.php | cut -d\' -f 1)
    dbname=$(sed -n '/$dbname = / s/.*\= '"'"'*//p' updates/bkp/Config.php | cut -d\' -f 1)
    dbhost=$(sed -n '/$dbhost = / s/.*\= '"'"'*//p' updates/bkp/Config.php | cut -d\' -f 1)

    echo '
    [client]
    user='$dbuser'
    password='$dbpass'

    ' > xn

    for f in *.sql
    do
        mysql --defaults-extra-file=xn < f
    done

    rm *.sql
    rm xn

fi

