<?php 
require_once('../Modells/Data.php');

if( Data::changeuserpassword($_POST["user_id"],$_POST["oldpass"],$_POST["newpass"]) ){
    echo "Contraseña cambiada correctamente.";
}else{
    echo "Error, no se pudo cambiar la contraseña.";
}
?>