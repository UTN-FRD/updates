<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["field"])) {
    $id = $_POST["id"];
    $user = $_POST["user"];
    $field = $_POST["field"];
    $value = $_POST["value"];
    echo json_encode( Data::saveFieldValue($id, $user, $field, $value) );
} 
?>