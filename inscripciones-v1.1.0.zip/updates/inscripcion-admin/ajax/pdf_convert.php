<?php
require( '../vendor/fpdf.php' );
require_once('../Modells/Data.php');

$destination_dir=dirname(__FILE__).'/../../inscripcion-frd/documents/';
$results = Data::fetchInscriptionDocuments();
$fields = array('documentacionanalitico', 'documentacioncuil', 'documentacioncv', 'documentacionnacimiento', 'documentaciontitulogrado');

foreach($results as $row) {
	$id = $row['id'];
	$msg='';

	foreach ($fields as $field) {
		$ext = pathinfo($row[$field], PATHINFO_EXTENSION);

		if( $row[$field] && $ext!='pdf' ){
			try{
				$msg = $msg." - ".$field." - ".$row[$field]." - ".$ext;	   		

				$image = $destination_dir.DIRECTORY_SEPARATOR.$row['id'].DIRECTORY_SEPARATOR.$row[$field];
				$pdf = new FPDF();
				$pdf->AddPage();
				$data = getimagesize($image);
				$width = $data[0]/170;

				$pdf->Image($image,20,20,$data[0]/$width,$data[1]/$width);
				$filename=pathinfo($row[$field], PATHINFO_FILENAME).".pdf";
				$filenamepdf=$destination_dir.DIRECTORY_SEPARATOR.$row['id'].DIRECTORY_SEPARATOR.$filename;
				$pdf->Output($filenamepdf,'F');
				Data::updateInscriptionField($row['id'], $field, $filename);
			}catch(Exception $e) {
				$msg = $msg.'Excepción capturada: '. $e->getMessage();
			}
	   }
	}

	//'documentaciondni', 'documentaciondniback', 

	if( $row['documentaciondni'] ){
		$ext = pathinfo($row['documentaciondni'], PATHINFO_EXTENSION);
		if( $ext!='pdf' ){
			try{
				$pdf = new FPDF();
		   		$msg = $msg." - DNI: ".$row['documentaciondni']." - ".$row['documentaciondniback'];

				$image = $destination_dir.DIRECTORY_SEPARATOR.$row['id'].DIRECTORY_SEPARATOR.$row['documentaciondni'];
				$pdf->AddPage();
				$data = getimagesize($image);
				$width = $data[0]/170;

				$pdf->Image($image,20,20,$data[0]/$width,$data[1]/$width);			

				if( $row['documentaciondniback'] ){
					$image = $destination_dir.DIRECTORY_SEPARATOR.$row['id'].DIRECTORY_SEPARATOR.$row['documentaciondniback'];
					$pdf->AddPage();
					$data = getimagesize($image);
					$width = $data[0]/170;

					$pdf->Image($image,20,20,$data[0]/$width,$data[1]/$width);					
				}

				$filename=pathinfo($row['documentaciondni'], PATHINFO_FILENAME);
				$filenamepdf=$destination_dir.DIRECTORY_SEPARATOR.$row['id'].DIRECTORY_SEPARATOR.$filename.".pdf";

				$pdf->Output($filenamepdf,'F');
				Data::updateInscriptionField($row['id'], 'documentaciondni', $filename.".pdf");
			}catch(Exception $e) {
				$msg = $msg.'Excepción capturada: '. $e->getMessage();
			}
		}

	}



	echo $row['id'].$msg."<br>";
	
}

