<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["field"])) {
	echo json_encode( Data::fetchDynamicQuestionValues( $_POST["field"] ) );
} 
?>