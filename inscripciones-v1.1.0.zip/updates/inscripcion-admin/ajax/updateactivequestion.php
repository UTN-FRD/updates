<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["a"])) {
	Data::saveConfiguration( 'X_QUESTION', $_POST["a"] );
} else {
	echo "Error, no se puede guardar";
}

?>
