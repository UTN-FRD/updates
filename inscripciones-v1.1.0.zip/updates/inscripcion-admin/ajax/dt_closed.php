<?php
$table = 'closed_inscriptions';
$primaryKey = 'id';
 
$col = 0;
$columns = array(
    array( 'db' => 'alumnoapellido',  'dt' => $col++ ),
    array( 'db' => 'alumnonombres', 'dt' => $col++ ),
    array( 'db' => 'alumnonumerodocumento',  'dt' => $col++ ),
    array( 'db' => 'carreradesc',   'dt' => $col++ ),
    array( 'db' => 'lugarcursado',     'dt' => $col++ ),
    array( 'db' => 'state', 'dt' => $col++ ),

    array( 'db' => 'id', 'dt' => $col++ )
);
 
require( '../vendor/ssp.class.php' );
require( '../Modells/Config.php' );
 
echo json_encode(
    SSP::simple( $_GET, $GLOBALS['sql_details'], $table, $primaryKey, $columns )
);