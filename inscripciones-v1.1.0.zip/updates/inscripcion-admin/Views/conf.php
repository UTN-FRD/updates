<?php
require_once('Controllers/Controller.php');

$controller = new Controller();
$config = $controller->getConfigurations();

?>
<h2>Inscripci&oacute;n</h2>
<div class="row">
	<div class="col">
		<!-- FORM_OPEN -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
			return $v['id'] == "FORM_OPEN";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="custom-control custom-switch">
		<input type="checkbox" class="custom-control-input" id="formopen" <?= $row['value']=='true'?"checked":"" ?>>
		<label class="custom-control-label" for="formopen">Inscripciones Abiertas</label>
		<small class="form-text text-muted"><?= $row['description'] ?></small>
		</div>
		<script>
			$("#formopen").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=FORM_OPEN&value='+$(this).prop('checked'),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
	<div class="col">
		<!-- DATA_DOMI -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "DATA_DOMI";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="DATA_DOMI">Título de la sección domicilio</label>
			<select id="DATA_DOMI" class="custom-select">
			  <option value="Domicilio Actual" <?= $row['value']=='Domicilio Actual'?"selected":"" ?>>Domicilio Actual</option>
			  <option value="Domicilio (como figura en su documento)" <?= $row['value']=='Domicilio (como figura en su documento)'?"selected":"" ?>>Domicilio (como figura en su documento)</option>
			</select>
		    <small class="form-text text-muted"><?= $row['description'] ?></small>
		</div>
		<script>
			$("#DATA_DOMI").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=DATA_DOMI&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
</div>
<br>
<div class="row">
	<div class="col">
		<!-- FORM_ADMIN -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "FORM_ADMIN";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="custom-control custom-switch">
		  <input type="checkbox" class="custom-control-input" id="formadmin" <?= $row['value']=='true'?"checked":"" ?>>
		  <label class="custom-control-label" for="formadmin">Código de Admisión</label>
		  <small class="form-text text-muted"><?= $row['description'] ?></small>
		</div>
		<script>
			$("#formadmin").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=FORM_ADMIN&value='+$(this).prop('checked'),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
	<div class="col">
		<!-- FORM_CODE -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "FORM_CODE";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="FORM_CODE">Codigo usado para admisión</label>
			<select id="FORM_CODE" class="custom-select">
			  <option value="ID" <?= $row['value']=='ID'?"selected":"" ?>>ID de la carrera</option>
			  <option value="2021" <?= $row['value']=='2021'?"selected":"" ?>>2021</option>
			</select>
		    <small class="form-text text-muted"><?= $row['description'] ?></small>
		</div>
		<script>
			$("#FORM_CODE").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=FORM_CODE&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
</div>
<hr>
<h2>Migraci&oacute;n al SysAcad</h2>
<div class="row">
	<div class="col">
		<!-- SA_CARRERA -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "SA_CARRERA";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<label for="SA_CARRERA"><?= $row['description'] ?></label>
		<?php
		$carrerasSeleccionadas = explode(',',$row['value']);
		foreach ($controller->getAllCarreras() as $carr) {
		?>
		<div class="custom-control custom-checkbox">
		  <input type="checkbox" name="SA_CARRERA" value="<?= $carr['value'] ?>" id="<?= $carr['value'] ?>" class="custom-control-input" <?= in_array($carr['value'],$carrerasSeleccionadas)?"checked":"" ?>>
		  <label class="custom-control-label" for="<?= $carr['value'] ?>"><?= $carr['display'] ?></label>
		</div>
		<?php
		}
		?>
		<script>
			$("input[name='SA_CARRERA']").change(function(){
				var favorite = [];
	            $.each($("input[name='SA_CARRERA']:checked"), function(){
	                favorite.push($(this).val());
	            });
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=SA_CARRERA&value='+favorite.join(","),
					success: function(data){
					}
				});					
			});
		</script>
	</div>
	<div class="col">
		<!-- SA_STATE -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "SA_STATE";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="SA_STATE"><?= $row['description'] ?></label>
			<select id="SA_STATE" class="custom-select">
			  <option value="pendiente" <?= $row['value']=='pendiente'?"selected":"" ?>>Pendiente</option>
			  <option value="aprobado" <?= $row['value']=='aprobado'?"selected":"" ?>>Aprobado</option>
			</select>
		</div>
		<script>
			$("#SA_STATE").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=SA_STATE&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>	
</div>
<br>
<div class="row">
	<div class="col">
		<!-- I_MATERIA -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "I_MATERIA";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="I_MATERIA"><?= $row['id'] ?></label>
		    <input type="text" id="I_MATERIA" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#I_MATERIA").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=I_MATERIA&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
	<div class="col">
		<!-- I_COMISION -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "I_COMISION";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="I_COMISION"><?= $row['id'] ?></label>
		    <input type="text" id="I_COMISION" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#I_COMISION").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=I_COMISION&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>		
	</div>	
</div>
<hr>
<h2>Correos Electrónicos</h2>
<div class="row">
	<div class="col">
		<!-- EMAIL_SEND -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_SEND";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_SEND"><?= $row['id'] ?></label>
		    <input type="text" id="EMAIL_SEND" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_SEND").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_SEND&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>		
	</div>
	<div class="col">
		<!-- EMAIL_SUBJ -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_SUBJ";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_SUBJ"><?= $row['id'] ?></label>
		    <input type="text" id="EMAIL_SUBJ" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_SUBJ").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_SUBJ&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>		
	</div>	
</div>
<div class="row">
	<div class="col">
		<!-- EMAIL_URL -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_URL";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_URL"><?= $row['id'] ?></label>
		    <input type="text" id="EMAIL_URL" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_URL").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_URL&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
	<div class="col">
		<!-- EMAIL_SIGN -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_SIGN";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_SIGN"><?= $row['id'] ?></label>
		    <input type="text" id="EMAIL_SIGN" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_SIGN").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_SIGN&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>		
	</div>	
</div>
<div class="row">
	<div class="col">
		<!-- EMAIL_CLOS -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_CLOS";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_CLOS"><?= $row['id'] ?></label>
		    <textarea id="EMAIL_CLOS" class="form-control" rows="5" name="<?=  $row['id'] ?>"><?=  $row['value'] ?></textarea>
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_CLOS").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_CLOS&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
</div>
<hr>
<h2>Otras Configuraciones</h2>
<div class="row">
	<div class="col">
		<!-- DOCUM_URL -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "DOCUM_URL";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="DOCUM_URL"><?= $row['id'] ?></label>
		    <input type="text" id="DOCUM_URL" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#DOCUM_URL").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=DOCUM_URL&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
</div>
<style>
input.success{
color: green;
border-color: green;
}
</style>