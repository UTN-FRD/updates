<?php
require_once('Controllers/Controller.php');

$controller = new Controller();
$questions = $controller->getQuestions();
$allQuestions = $controller->getAllQuestions();
$results = $controller->getActiveQuestions();
$activeQuestions = explode('|',$results);
?>
<p>Las preguntas marcadas son las que se muestran en el formulario de inscripción</p>
<form id="question">
    <?php foreach ($allQuestions as $q) { ?>
	<div class="form-check">

	    <input type="checkbox" class="question form-check-input" value="<?=$q[0]?>" id="<?=$q[0]?>" <?= in_array($q[0],$activeQuestions)?'checked':'' ?>>
	    <label class="form-check-label" for="<?=$q[0]?>"><?=$q[0]?></label>
	</div>
	<?php } ?>
</form>

<div style="display:none">
	<form method="POST" id="inscription-form" class="needs-validation" novalidate autocomplete="off">
	    <h2>Preguntas del formulario</h2>
	    <div class="form-group">
	        <label for="preguntas">Pregunta</label>
			<select class="custom-select" id="preguntas">

				<option value="">--Seleccione--</option>
	        <?php foreach ($questions as $q) { ?>
				<option value="<?=$q['field']?>"><?=$q['field']?></option>
			<?php } ?>
	        </select>
	        <small id="alumnoapellidoHelpBlock" class="form-text text-muted">Seleccione una pregunta para ver el detalle de la misma.</small>
	    </div>
	</form>

	<div>
		<div class="row">
			<div class="col-8">
			</div>
			<div class="col-4">
				<label>Campo Relacionado</label>
				<select class="custom-select">
					<option value="">Ninguno</option>
				<?php foreach ($questions as $q) { ?>
					<option value="<?=$q['field']?>"><?=$q['field']?></option>
				<?php } ?>
				</select>
			</div>
		</div>

		<div class="row">
			<div class="col-2">Texto</div>
			<div class="col-2">Valor</div>
			<div class="col-1">Orden</div>
			<div class="col-3">Comentarios</div>
			<div class="col-4">Valores Relacionados</div>
		</div>
		<div class="form-inline">
			<input class="form-control col-2" value="delta">
			<input class="form-control col-2" value="Delta">
			<input class="form-control col-1" value="1">
			<input class="form-control col-3" value="">
			<div class="col-4 form-control">
				<span class="badge badge-pill badge-info">sistemas</span>
				<span class="badge badge-pill badge-info">electrica</span>
				<span class="badge badge-pill badge-info">quimica</span>	
			</div>
		</div>
		<div class="form-inline">
			<input class="form-control col-2" value="escobar">
			<input class="form-control col-2" value="Escobar">
			<input class="form-control col-1" value="2">
			<input class="form-control col-3" value="">
			<div class="col-4 form-control">
				<span class="badge badge-pill badge-info">mantenimiento</span>
				<span class="badge badge-pill badge-info">procesos</span>
				<span class="badge badge-pill badge-info">programacion</span>	
			</div>
		</div>	
		<div class="form-inline">
			<input class="form-control col-2" value="pilar">
			<input class="form-control col-2" value="Pilar">
			<input class="form-control col-1" value="3">
			<input class="form-control col-3" value="">
			<div class="col-4 form-control">
				<span class="badge badge-pill badge-info">mantenimiento</span>
				<span class="badge badge-pill badge-info">logistica</span>
			</div>
		</div>	
	</div>
</div>
<script>
$(document).ready(function(){
	$(".question").change(function(){
		var elem = $(this);
		var ids = [];
		$('.question:checked').each(function(i, e) {
		    ids.push($(this).val());
		});
		$.ajax({
			type: 'POST',
			url: './ajax/updateactivequestion.php',
			data:'a='+ids.join('|'),
			dataType: "json",
			success: function(data){
				if(data)
					alert(data);
			}
		});
	});
	$("#preguntas").change(function(){
		var elem = $(this);
		$.ajax({
			type: 'POST',
			url: './ajax/getquestionvalues.php',
			data:'field='+elem.val(),
			dataType: "json",
			success: function(data){
				alert(data);
			}
		});
	});
});
</script>