<p>Se muestran todas las inscripciones que se encuentran en el sistema, en cualquier <a data-toggle="collapse" href="#collapseEstados" role="button" aria-expanded="false" aria-controls="collapseEstados">estado (ver estados)</a> y de cualquier fecha.</p>
<div class="collapse" id="collapseEstados">
    <div class="card card-body">
        <img class="card-img" src="img/inscripcionfrd-estados.jpg"/>
    </div>
</div>

<table id="example" class="display" >
    <thead>
        <tr>
            <th>Apellido</th>
            <th>Nombre</th>
            <th>Nro Documento</th>
            <th>Correo</th>
            <th>Carrera</th>
            <th>Sede</th>
            <th>Estado</th>
            <th>Tiene Legajo</th>
            <th>Error SysAcad</th>
            <th></th>
        </tr>
    </thead>
</table>

<script>
<?php
require_once('Modells/Data.php');
?>
var carreras = jQuery.parseJSON(JSON.stringify(<?= json_encode(array_filter(Data::fetchCarreras())); ?>));
var sedes = jQuery.parseJSON(JSON.stringify(<?= json_encode(array_filter(Data::fetchSedes())); ?>));
var estados = jQuery.parseJSON(JSON.stringify(<?= json_encode(array_filter(Data::fetchEstados())); ?>));



$(document).ready(function() {
    var table = $('#example').DataTable( {
        'processing': true,
        'serverSide': true,
        'search': { 'regex': true },
        'ajax': './ajax/dt_all.php',
        'columnDefs': [ 
            {
                'targets': -1,
                'data': null,
                'defaultContent': '<button class="btn btn-success">Ver detalle</button>'
            }
        ],
        'createdRow': function( row, data, dataIndex){
            var className ='';
            switch(data[6]){
                case "aprobado": className = 'table-success'; break;
                case "pendiente": className = 'table-warning'; break;
                case "rechazado": className = 'table-danger'; break;
            }
            $(row).addClass( className );
        }
    } );

    yadcf.init(table, [
        {column_number : 4, data: carreras, column_data_type: "html", html_data_type: "text", filter_default_label: "Todos"},
        {column_number : 5, data:sedes, column_data_type: "html", html_data_type: "text", filter_default_label: "Todos"},
        {column_number : 6, data:estados, column_data_type: "html", html_data_type: "text", filter_default_label: "Todos"},
        {column_number : 7, data:['SI','NO'], column_data_type: "html", html_data_type: "text", filter_default_label: "Todos"},
        {column_number : 8, data:['SI','NO'], column_data_type: "html", html_data_type: "text", filter_default_label: "Todos"}
        ]);

    $('#example tbody').on( 'click', 'button', function () {
        var data = table.row( $(this).parents('tr') ).data();
        window.location = 'index.php?action=inscription-form&id='+data[ 9 ]; 
    } );

} );
</script>
<style>
.yadcf-filter{max-width:260px}
</style>
