<?php
require_once('Controllers/Controller.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <nav class="navbar sticky-top navbar-light bg-light" style="background-color: white!important;">
        <a class="navbar-brand" href="https://www.frd.utn.edu.ar/">
            <img src="https://www.frd.utn.edu.ar/wp-content/uploads/2019/11/Logo-web-01.png" width="250" alt="">
        </a>
        <ul class="navbar-nav">
            <li class="nav-item"><a href="logout"><span style="padding:15px">Salir</span></a></li>
        </ul>
    </nav>
    <div class="content">
        <div class="row">
            <div class="mx-auto" style="width: 50%;text-align: center;">
                <h1>Administración de Inscripciones<br>UTN-FRD</h1>
            </div>
        </div>
        <?php 
        if(isset($_GET['msg'])){
        ?>
        <div class="row">
            <div class="mx-auto" style="width: 50%;text-align: center;">
                <div class="alert alert-danger">
                    <?= $_GET['msg'] ?>
                </div>
            </div>
        </div>
        <?php 
        }
        ?>
        <div class="row">
            <div class="col"></div>
            <div class="col">
                <form method="post">
                    <div class="form-group has-feedback">
                        <input name="user" type="text" class="form-control" placeholder="Usuario">
                    </div>
                    
                    <div class="form-group has-feedback">
                        <input name= "pass" type="password" class="form-control" placeholder="Contraseña">
                    </div>

                    <div class="row">
                        <div class="mx-auto">
                            <button type="submit" class="btn btn-primary btn-block btn-flat">Entrar</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col"></div>
        </div>
    </div>
</body>
</html>

<?php
    $controller= new Controller();

    $controller -> login();
?>