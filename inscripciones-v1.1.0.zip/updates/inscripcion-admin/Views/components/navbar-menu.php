<nav class="navbar sticky-top navbar-light bg-light" style="background-color: white!important;">
	<a class="navbar-brand" href="#"><img src="https://www.frd.utn.edu.ar/wp-content/uploads/2019/11/Logo-web-01.png" width="250" alt=""></a>
	<ul class="navbar-item dropdown">
		<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?= $_SESSION['user'] ?></a>
		<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
			<a class="dropdown-item" data-toggle="modal" data-target="#userProfileModal" href="#">Ver Perfil</a>
			<div class="dropdown-divider"></div>
			<a class="dropdown-item" href="logout">Salir</a>
		</div>
	</ul>
</nav>


<!-- Modal -->
<div class="modal fade" id="userProfileModal" tabindex="-1" aria-labelledby="userProfileModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="userProfileModalLabel">Perfil de usuario</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	  <div class="row">
			<div class="col-6">
				<div class="form-group" style="margin-bottom: 0 !important">
					<label for="userProfileNick" class="col-form-label">Nombre de usuario:</label>
					<input type="text" class="form-control" id="userProfileNick">
				</div>
			</div>
			<div class="col-6">
				<div class="form-group" style="margin-bottom: 0 !important">
					<label for="userProfileName" class="col-form-label">Nombre:</label>
					<input type="text" class="form-control" id="userProfileName" value="<?= $_SESSION['user'] ?>">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-6">
				<div class="form-group" style="margin-bottom: 0 !important">
					<label for="userProfileEmail" class="col-form-label">Correo electrónico:</label>
					<input type="email" class="form-control" id="userProfileEmail">
				</div>
			</div>
			<div class="col-6">
				<div class="form-group" style="margin-bottom: 0 !important">
					<label for="userProfileRole" class="col-form-label">Rol:</label>
					<input type="text" class="form-control" id="userProfileRole" value="<?= $_SESSION['rol'] ?>" readonly>
				</div>
			</div>
		</div>
		<hr>
		<h4>Cambiar Contraseña:</h4>
		<div class="form-group">
			<label for="userProfilePass" class="col-form-label">Contraseña actual:</label>
			<input type="password" class="form-control" id="userProfilePass">
		</div>
		<div class="form-group">
			<label for="userProfileNewPass" class="col-form-label">Nueva contraseña:</label>
			<input type="password" class="form-control" id="userProfileNewPass">
		</div>
		<div class="form-group">
			<label for="userProfileNewPassRepeat" class="col-form-label">Repetir Nueva contraseña:</label>
			<input type="password" class="form-control" id="userProfileNewPassRepeat">
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" id="userProfileChangePass">Cambiar contraseña</button>
      </div>
    </div>
  </div>
</div>
<script>
$('#userProfileModal').on('show.bs.modal', function (event) {
	$.ajax({
		url: 'ajax/userprofile.php',
		method: 'POST',
		data: 'user_id=<?=$_SESSION['user_id']?>',
		success: function(data){
			var usr = JSON.parse(data);
			$("#userProfileNick").val(usr['username']);
			$("#userProfileEmail").val(usr['email']);
		}
	});
})
$('#userProfileChangePass').click(function () {
	if($("#userProfilePass").val()=='' || $("#userProfileNewPass").val()==''){
		alert("Debe ingresar la contraseña actual y la nueva");
		return;
	}
	if($("#userProfileNewPassRepeat").val()!=$("#userProfileNewPass").val()){
		alert("Nueva contraseña y Repetir nueva contraseña son diferentes.");
		return;
	}
	$('#userProfileChangePass').prop('disabled', true);
	$.ajax({
		url: 'ajax/userpasswordchange.php',
		method: 'POST',
		data: 'user_id=<?=$_SESSION['user_id']?>&oldpass='+$("#userProfilePass").val()+'&newpass='+$("#userProfileNewPass").val(),
		success: function(data){
			alert(data);
			$("#userProfileModal").modal("hide");
			$('#userProfileChangePass').prop('disabled', false);			
		}
	});
})
</script>