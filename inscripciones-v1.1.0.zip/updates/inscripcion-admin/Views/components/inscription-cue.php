<div class="modal fade" id="CUEModal" tabindex="-1" role="dialog" aria-labelledby="CUEModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="CUEModalLabel">Buscar CUE de institución educativa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="form-inline row">
			<label class="sr-only" for="searchCUEnombre">Nombre</label>
			<input type="text" class="form-control col-md" id="searchCUEnombre" name="searchCUEnombre" placeholder="Nombre del colegio">
		</div>
      	<div class="form-inline row">
			<label class="sr-only" for="searchCUEpais">Pa&iacute;s</label>
			<select type="text" class="form-control col-md" id="searchCUEpais" name="searchCUEpais">
				<option value="">--Seleccione Pais--</option>
			</select>
			<label class="sr-only" for="searchCUEprovincia">Provincia</label>
			<select type="text" class="form-control col-md" id="searchCUEprovincia" name="searchCUEprovincia">
				<option value="">--Seleccione Provincia--</option>
			</select>
			<label class="sr-only" for="searchCUEciudad">Ciudad</label>
			<select type="text" class="form-control col-md" id="searchCUEciudad" name="searchCUEciudad">
				<option value="">--Seleccione Ciudad--</option>
			</select>
			<a class="btn btn-primary col-md" id="searchCUEbtn">Buscar</a>
		</div>
		<hr>
		<div class="row">
			<div class="col">
				<h5 class="modal-title">Resultados</h5>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<ul id="searchCUEresults"></ul>
			</div>
		</div>
      </div>
      <div class="modal-footer">
		<button type="button" id="searchCUEnotfound" class="btn btn-warning" style="display:none">No encuentro mi Instituto Educativo. Lo ingreso manualmente</button>
      </div>
    </div>
  </div>
<script>
var sectionCUEModal;
$('#CUEModal').on('show.bs.modal',function(e){
	sectionCUEModal = $(e.relatedTarget).data('section');
	updateSearchCUE($('#searchCUEpais'));
});
$('#searchCUEpais').change(function(){
	updateSearchCUE($('#searchCUEprovincia'));
});
$('#searchCUEprovincia').change(function(){
	updateSearchCUE($('#searchCUEciudad'));
});

$('#searchCUEbtn').click(function(){
	$.ajax({
		url: './ajax/cue.php',
		data: 'nombre='+$('#searchCUEnombre').val()+'&pais='+$('#searchCUEpais').val()+'&provincia='+$('#searchCUEprovincia').val()+'&ciudad='+$('#searchCUEciudad').val(),
		type: 'POST',
		dataType: 'json',
		success: function(data){
			$('#searchCUEresults').html('');
			data.map(function(obj) {
			    $('#searchCUEresults').append($('<li/>',{'data-cue':obj.cue,html:'<b>'+obj.nombre+'</b> '+obj.facultad+'<br>'+obj.direccion+', '+obj.localidad+'<br>'+obj.provincia+', '+obj.pais}));
			});
			$('#searchCUEresults li').click(function(){
				$('#'+sectionCUEModal+'cue').val($(this).data('cue'));
				$('#'+sectionCUEModal+'cue').trigger('change');
				$('#CUEModal').modal('hide');
				$('#searchCUEpais').val('');
				$('#searchCUEciudad').val('');
				$('#searchCUEprovincia').val('');
				$('#searchCUEresults').html('');
			});
			$('#searchCUEnotfound').show();
		}
	});
});
$('#searchCUEnotfound').click(function(){
	$('#CUEModal').modal('hide');
	$('#searchCUEpais').val('');
	$('#searchCUEciudad').val('');
	$('#searchCUEprovincia').val('');
	$('#searchCUEresults').html('');
	$('#'+sectionCUEModal+'cue').val('');
	$('#'+sectionCUEModal+'cue').trigger('change');
	$('#'+sectionCUEModal+'cue').prop('required',false);
	$('#'+sectionCUEModal+'institucion').val('');
	$('#'+sectionCUEModal+'institucion').trigger('change');
	$('#'+sectionCUEModal+'localidad').val('');
	$('#'+sectionCUEModal+'localidad').trigger('change');
	$('#'+sectionCUEModal+'provincia').val('');
	$('#'+sectionCUEModal+'provincia').trigger('change');

	clearInstitucion();	
});
</script>
<style>
#searchCUEresults li:hover{
	background: #ccc;
	cursor:pointer;
}
</style>
</div>
