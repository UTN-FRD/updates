<?php
require_once('Connection.php');

class Data extends Connection{

    public function checkUser($user){
        $stmt = Connection::connect()->prepare("SELECT * FROM users WHERE username = :username AND password = md5(:password) ");
        $stmt->bindParam(':username', $user['username'], PDO::PARAM_STR);
        $stmt->bindParam(':password', $user['password'], PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function fetchInscriptions(){
        $db = Connection::connect();
        $stmt = $db->prepare("SELECT value FROM `configuration` WHERE id='SA_CARRERA'");
        $stmt->execute();
        $carreras = $stmt->fetchColumn();
        if($carreras && !empty(trim($carreras))){
            $carreras=' carrera in ('.$carreras.') and ';
        }

        $stmt = $db->prepare("SELECT `id` as id, `alumnonumerodocumento` as numero_documento, `alumnotipodocumento` as tipo_documento FROM `inscriptions`, (SELECT value FROM `configuration` WHERE id='SA_STATE') ss where ".$carreras." state=ss.value and (legajo_sysacad is null or legajo_sysacad = '')");

        $stmt->execute();
        $r = array();
        $r = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public function fetchInscription($id){
        $stmt = Connection::connect()->prepare("SELECT `id` as id,
         `alumnoapellido` as apellidos,
         `alumnonombres` as nombres, 
         `alumnotipodocumento` as tipo_documento, 
         `alumnonumerodocumento` as numero_documento, 
         `alumnocuil` as cuil, 
         `alumnosexo` as sexo, 
         `alumnoestadocivil` as id_estado_civil, 
         `contactoemail` as email, 
         `contactoemailalternativo` as email_alternativo, 
         `contactotelefonofijo` as telefono, 
         `contactotelefonomovil` as celular, 
         `carrera` as id_carrera, 
         `lugarcursado` as extensiona, 
         `formaingreso` as id_forma_ingreso, 
         `tipocursado` as tipo_cursado, 
         `introductoriointensivo` as curso_intensivo,
         `nacfechanacimiento` as fecha_nacimiento, 
         `nacnacionalidad` as nacionalidad, 
         `nacvencdni` as vencimiento_dni, 
         `nacpais` as pais_nacimiento, 
         `nacprovincia` as provincia_nacimiento, 
         `naclocalidad` as localidad_nacimiento, 
         `nacpartidodepartamento` as partido_nacimiento, 
         `nacgruposanguineo` as grupo_sanguineo, 
         `domiciliocalle` as domicilio_calle, 
         `domicilionumero` as domicilio_numero, 
         `domiciliopiso` as domicilio_piso, 
         `domiciliolocalidad` as domicilio_localidad, 
         `domiciliopartido` as domicilio_partido, 
         `domicilioprovincia` as domicilio_provincia, 
         `domiciliocp` as domicilio_cp, 
         `discapacidad` as discapacidad, 
         `discapacidadtipo[]` as tipo_discapacidad, 
         `discapacidadtipootro` as tipo_discapacidad_otro, 
         `discapacidadmedicacion` as medicacion, 
         `discapacidadcertificado` as certificado_discapacidad, 
         `discapacidados` as obra_social, 
         `discapacidadoscual` as obra_social_desc, 
         `discapacidadbarreras[]` as barreras, 
         `discapacidadbarrerasotro` as barreras_otro, 
         `discapacidadelementos[]` as elementos, 
         `discapacidadelementosotro` as elementos_otro, 
         `secundarioegreso` as secundario_egreso, 
         `secundarioestado` as secundario_estado, 
         `secundarioanioegreso` as secundario_anio_egreso, 
         `secundariotituladoen` as secundario_titulo, 
         `secundariotecnico` as id_secundario_tecnico, 
         `secundarioanalitico` as id_titulo_sec,
         `secundariolocalidad` as secundario_localidad,
         `secundarioinstitucion` as secundario_colegio,
         `secundarioprovincia` as secundario_provincia,
         if(locate('secundariocue',(SELECT value FROM configuration where id='X_QUESTION'))>0, secundariocue, titulounivcue) as cue_entidad_educativa,
         `titulounivanioegreso` as titulo_anio_egreso,
         `titulouniventramite` as titulo_en_tramite,
         `titulounivinstitucion` as titulo_institucion,
         `titulounivlocalidad` as titulo_localidad,
         `titulounivnombre` as titulo_anterior,
         `titulounivprovincia` as titulo_provincia,
         `otrosestudiostipo` as otros_estudios, 
         `otrosestudioscarrera` as otra_carrera, 
         `otrosestudiosinstitucion` as otra_institucion, 
         `otrosestudiosmateriasaprobadas` as otra_aprobadas, 
         `otrosestudiosestado` as otra_estado, 
         `trabajotrabajas` as trabajo,
         `situacionlaboral` as id_situacion_laboral,
         `tipotrabajo` as id_tipo_trabajo,
         `trabajoocupacion` as id_ocupacion,
         `tipoocupacion` as id_tipo_ocupacion,
         `trabajoenque` as trabajo_cargo, 
         `trabajohoras` as id_trabajo_horas, 
         `trabajoempresa` as trabajo_empresa, 
         `trabajodireccion` as trabajo_direccion, 
         `trabajotelefono` as trabajo_telefono, 
         `trabajorelcarrera` as id_trabajo_relacion_carrera,
         `deporte` as deporte, 
         `tecnotienepc` as pc, 
         `tecnodondepc` as pc_acceso, 
         `tecnocelular` as cantidad_celulares, 
         `tecnotieneinternet` as tiene_internet, 
         `tecnointernet` as acceso_internet,
         `tecnousointernet` as uso_internet, 
         `familiaacargo` as id_familia_a_cargo,
         `padreapellido` as padre_apellidos, 
         `padrenombre` as padre_nombres, 
         `padrefechanac` as padre_fecha_nac, 
         `padrevive` as padre_vive, 
         `padreestudios` as id_instruccion_padre, 
         `padretrabajo` as padre_trabajo, 
         `padresituacionlaboral` as id_situacion_laboral_padre,
         `padreobrasocial` as padre_obra_social, 
         `madreapellido` as madre_apellidos, 
         `madrenombre` as madre_nombres, 
         `madrefechanac` as madre_fecha_nac, 
         `madrevive` as madre_vive, 
         `madreestudios` as id_instruccion_madre, 
         `madretrabajo` as madre_trabajo, 
         `madresituacionlaboral` as id_situacion_laboral_madre,
         `madreobrasocial` as madre_obra_social, 
         `hermanoscantidad` as hermanos_cantidad, 
         `hermanosedades` as hermanos_edades, 
         `hermanosactividades` as hermanos_actividades, 
         `casatipo` as casa_tipo, 
         `casacondicion` as casa_condicion, 
         `casamediotraslado` as traslado,
         `documentacionanalitico`,
         `documentacioncuil`,
         `documentacioncv`,
         `documentaciondni`,
         `documentacionnacimiento`,
         `documentaciontitulogrado`
         FROM `inscriptions` WHERE id=:id and state = (SELECT value FROM `configuration` WHERE id='SA_STATE')");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateSysAcadData($id, $legajo, $error){
        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET state_messages = concat(state_messages, concat(now(), '[SysAcad] legajo: ".$legajo." - error: ".$error."\n')), legajo_sysacad = :legajo, error_sysacad = :error, fecha_sysacad = NOW() where id = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':legajo', $legajo, PDO::PARAM_STR);
        $stmt->bindParam(':error', $error, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public function fetchDocumentsIds(){
        $stmt = Connection::connect()->prepare("SELECT * FROM requisitosacad where related_field is not null");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function fetchConfiguration($id){
        $stmt = Connection::connect()->prepare("SELECT value FROM configuration where id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        
        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public function fetchInscriptionConfiguration(){
        $stmt = Connection::connect()->prepare("SELECT id, value FROM configuration where id IN ('I_MATERIA','I_COMISION') order by 1 asc");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

}
?>