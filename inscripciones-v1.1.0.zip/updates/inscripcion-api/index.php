<?php
require_once('Controllers/Controller.php');

$controller = new Controller();
$controller->loadLayout();
?>