<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>RESTful</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<h1>API REST</h1>
	<p>Para exportar las inscripciones al SysAcad se debe ejecutar en el SysAcad lo siguiente:</p>
	<p>Configuración de la API</p>

	<p>Archivo->Supervisión->Importación de aspirantes WEB</p>
	<p>Archivo->Académico->Alumnos->Alumnos</p>
	<p>Registro->Procesos->Importar Aspirante WEB</p>
	<table border="1" width="100%">
		<caption>Métodos disponibles</caption>
		<thead>
			<tr>
				<th>URL</th>
				<th>Método</th>
				<th>Parámetros</th>
				<th>Resultado</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>https://lsi.frd.utn.edu.ar/inscripcion-api/rest/inscripciones</td>
				<td>GET</td>
				<td>N/A</td>
				<td>JSON Array [{"id":"1","numero_documento":"40400400","tipo_documento":"1"},{"id":"2","numero_documento":"41401401","tipo_documento":"1"}]</td>
				<td></td>
			</tr>
			<tr>
				<td>https://lsi.frd.utn.edu.ar/inscripcion-api/rest/inscripciones/1</td>
				<td>GET</td>
				<td>N/A</td>
				<td></td>
				<td>JSON Object {"id":"2","apellidos":"Perales","nombres":"Ana\u00ed","tipo_documento":"1","numero_documento":"41401401","cuil":"99-41401401-9","sexo":"F","id_estado_civil":"1","email":"sergioviera@gmail.com","email_alternativo":null,"telefono":"(3487) 46664444","celular":null,"id_carrera":"5","sede":"delta","id_forma_ingreso":"introductorio","tipo_cursado":"vm","curso_intensivo":"SI","fecha_nacimiento":"2001-07-07","nacionalidad":"1","vencimiento_dni":null,"pais_nacimiento":"Argentina","provincia_nacimiento":"Buenos Aires","localidad_nacimiento":"Z\u00e1rate","partido_nacimiento":"Z\u00e1rate","grupo_sanguineo":"8","domicilio_calle":"Rawson","domicilio_numero":"884","domicilio_piso":null,"domicilio_localidad":"Z\u00e1rate","domicilio_partido":"Z\u00e1rate","domicilio_provincia":"Buenos Aires","domicilio_cp":"2800","discapacidad":"NO","tipo_discapacidad":null,"tipo_discapacidad_otro":null,"medicacion":null,"certificado_discapacidad":"","obra_social":"","obra_social_desc":"","barreras":"","barreras_otro":"","elementos":"","elementos_otro":"","secundario_egreso":"NO","secundario_estado":"ultimoanio","secundario_anio_egreso":null,"secundario_titulo":"Mercantil","id_secundario_tecnico":"1","id_titulo_sec":"4","cue_entidad_educativa":null,"otros_estudios":null,"otra_carrera":null,"otra_institucion":null,"otra_aprobadas":null,"otra_estado":null,"trabajo":"NO","id_situacion_laboral":null,"id_tipo_trabajo":null,"id_ocupacion":null,"id_tipo_ocupacion":null,"trabajo_cargo":null,"id_trabajo_horas":null,"trabajo_empresa":null,"trabajo_direccion":null,"trabajo_telefono":null,"id_trabajo_relacion_carrera":null,"deporte":"Voley","pc":"SI","pc_acceso":"Casa","cantidad_celulares":"2","tiene_internet":"SI","acceso_internet":"Casa","uso_internet":"Varios","id_familia_a_cargo":null,"padre_apellidos":"Perales","padre_nombres":"Antonio","padre_fecha_nac":"1972-12-27","padre_vive":"SI","id_instruccion_padre":"4","padre_trabajo":"Empresario","id_situacion_laboral_padre":null,"padre_obra_social":"SI","madre_apellidos":"Maidana","madre_nombres":"Graciela","madre_fecha_nac":"1980-06-01","madre_vive":"SI","id_instruccion_madre":"4","madre_trabajo":"Empleada","id_situacion_laboral_madre":null,"madre_obra_social":"SI","hermanos_cantidad":"1","hermanos_edades":"16","hermanos_actividades":"estudiante","casa_tipo":"Departamento","casa_condicion":"Alquilada","traslado":"Autom\u00f3vil"}</td>
				<td>
Campo						| Detalle
============================|=================================================
id_forma_ingreso			| forma de ingreso según los valores del sysacad
id_instruccion_padre		| instruccion de padre según sysacad 
id_instruccion_madre		| instruccion de madre según sysacad
id_situacion_laboral		| situacion laboral de alumno/madre/padre
id_situacion_laboral_padre	| situacion laboral de alumno/madre/padre
id_situacion_laboral_madre	| situacion laboral de alumno/madre/padre
id_tipo_trabajo				| tipo de trabajo
id_ocupacion				| trabajoocupacion (si no trabaja)
id_tipo_ocupacion			| tipoocupacion
id_trabajo_horas			| trabajohoras
id_trabajo_relacion_carrera	| relacion con la carrera
id_familia_a_cargo			| familiaacargo
id_estado_civil				| alumnoestadocivil * tabla dbo.Estcivil
id_secundario_tecnico		| secundariotecnico * tabla dbo.Estudio
id_carrera 					| * carrera * tabla dbo.especial
cue_entidad_educativa		| campo CUE de la tabla dbo.EntidadesEducativas
id_titulo_sec				| id de la tabla dbo.titulosec
============================|================================================
				</td>
			</tr>
			<tr>
				<td>https://lsi.frd.utn.edu.ar/inscripcion-api/rest/inscripciones/1</td>
				<td>PUT</td>
				<td>JSON Object {"legajo":"99-9999999", "error":"no hay errores"}</td>
				<td>N/A</td>
				<td></td>
			</tr>
		</tbody>
	</table>
</body>
</html>