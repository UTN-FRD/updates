UPDATE `configuration` SET `value`='1.1.0' WHERE `id`='VERSION';
