<?php
require_once('Connection.php');

class Data extends Connection{

    //Funcion que compara si existe el usuario que intenta logearse, pasandole los datos a traves de un objeto y ademas el nombre de la tabla,
    //Asi como se convierte a la contraseña con la funcion MD5 para que se compare correctamente con la almacenada en la base de datos
    public static function validarUsuario($datos){

        $stmt = Connection::connect()->prepare("SELECT * FROM usuarios WHERE correo = :correo AND contrasena = md5(:contra) ");

        $stmt->bindParam(':correo', $datos['correo'], PDO::PARAM_STR);
        $stmt->bindParam(':contra', $datos['contrasena'], PDO::PARAM_STR);

        $stmt->execute();

        $r = array();

        $r = $stmt->fetch(PDO::FETCH_ASSOC);

        return $r;

    }

    /** Verifica si se ha enviado un mensaje en los últimos minutos. Si es así, guarda y bloquea el envío. Sino guarda el mensaje. **/
    public static function saveContactMessage($correo, $tel, $msg){
        $response = array();

        $stmt = Connection::connect()->prepare("select * from contacts where DATE_ADD(creation_date, INTERVAL 10 MINUTE) >= NOW() and (email=:email OR phone=:phone)");

        $stmt->bindParam(':email', $correo, PDO::PARAM_STR);
        $stmt->bindParam(':phone', $tel, PDO::PARAM_STR);

        $stmt->execute();

        $r = $stmt->fetchAll();

        $stmt2 = Connection::connect()->prepare("INSERT INTO contacts (email, phone, message) VALUES (:email, :phone, :message)");
        $stmt2->bindParam(':email', $correo, PDO::PARAM_STR);
        $stmt2->bindParam(':phone', $tel, PDO::PARAM_STR);

        if( !empty($r) ){
            $stmt2->bindParam(':message', '[BLOQUEADO]'.$msg, PDO::PARAM_STR);

            $response = array('blocked' => 'Ya se ha enviado un mensaje en los últimos minutos. Vuelva a intentar mas tarde.');
        }else{
            $stmt2->bindParam(':message', $msg, PDO::PARAM_STR);
        }

        if($stmt2.execute() && empty($response)){
            return array('success'=>'success');
        }else{
            if(empty($response)){
                $response = array('error'=>'Error al guardar el mensaje.');
            }
            return $response;
        }

    }

    public static function fetchConfigParams($id, $token){
        $stmt = Connection::connect()->prepare("SELECT cp.field, cp.display, cp.value FROM config_params cp WHERE related_field is NULL ORDER BY cp.sort_criteria");

        $stmt->execute();
        $r = array();
        $r = $stmt->fetchAll();

        //find related fields to check if were saved
        $stmt2 = Connection::connect()->prepare("SELECT DISTINCT cp.field FROM config_params cp WHERE related_field is not NULL");
        $stmt2->execute();

        foreach ($stmt2->fetchAll() as $row) {
            $stmt3 = Connection::connect()->prepare("SELECT cp.field, cp.display, cp.value FROM config_params cp WHERE cp.field='".$row['field']."' and cp.value = (select ".$row['field']." from inscriptions WHERE id = :id AND access_token = md5(:token) AND ".$row['field']." is not NULL)");
            $stmt3->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt3->bindParam(':token', $token, PDO::PARAM_STR);
            $stmt3->execute();
            $r = array_merge($r, $stmt3->fetchAll());
        }



        return $r;
    }


    public static function fetchConfigParamsRelated($field, $value){

        $stmt = Connection::connect()->prepare("SELECT cp.display, cp.value, cp.field FROM config_params cp WHERE related_values rlike '^".$value." | ".$value." | ".$value."$' and related_field=:field ORDER BY cp.sort_criteria");

        $stmt->bindParam(':field', $field, PDO::PARAM_STR);

        $stmt->execute();

        $r = array();

        $r = $stmt->fetchAll();

        return $r;

    }

    public static function hasInscription($alumnonumerodocumento){
        $db = Connection::connect();
        $stmt = $db->prepare("SELECT count(1) from inscriptions WHERE alumnonumerodocumento=:dni and state<>'cargando' and state<>'rechazado'");

        $stmt->bindParam(':dni', $alumnonumerodocumento, PDO::PARAM_STR);

        $stmt->execute();

        return !($stmt->fetchColumn()==0);
    }

    public static function registerInscription($alumnonumerodocumento, $contactoemail, $carrera){
        $db = Connection::connect();

        $stmt = $db->prepare("INSERT INTO inscriptions (alumnonumerodocumento, contactoemail, access_token, carrera, carrera_preseteada) VALUES (:dni, :email, md5(:token), :carrera, :carrera_preseteada)");

        $token = bin2hex(random_bytes(20));

        $carrera_preseteada = isset($carrera)&&$carrera<>''?1:0;

        $stmt->bindParam(':dni', $alumnonumerodocumento, PDO::PARAM_STR);
        $stmt->bindParam(':email', $contactoemail, PDO::PARAM_STR);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->bindParam(':carrera', $carrera, PDO::PARAM_STR);
        $stmt->bindParam(':carrera_preseteada', $carrera_preseteada, PDO::PARAM_BOOL);

        if($stmt->execute()){
            return array('token' => $token, 'id' => $db->lastInsertId());
        } else {
            return array('error' => 'error');
        }

    }

    public static function closeInscription($id, $token){
        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET fecha_cierre = NOW(), state_messages = IF(state='rechazado',concat(state_messages,concat(now(),' Corregido por el interesado.\n')), concat(now(),' Fin de la carga.\n')), state = IF(state='rechazado','corregido','pendiente') where id = :id and access_token = md5(:token)");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public static function getInscriptionState($id){
        $stmt = Connection::connect()->prepare("SELECT state FROM inscriptions WHERE id = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchColumn();        
    }

    public static function checkRegistration($id, $token){
        $db = Connection::connect();
        // verifico que el token sea válido
        $stmt = $db->prepare("SELECT count(1) FROM inscriptions WHERE id = :id AND access_token = md5(:token) AND fecha_cierre IS NULL ");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->execute();

        // verifico que no tenga una inscripción cerrada
        $stmt2 = $db->prepare("SELECT count(1) from inscriptions where alumnonumerodocumento in (SELECT ss.alumnonumerodocumento from inscriptions ss WHERE ss.id=:id) and state<>'cargando' and state<>'rechazado'");
        $stmt2->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt2->execute();

        // verifico si está abierta la inscripción
        // si es rechazado lo dejo pasar
        $stmt3 = $db->prepare("SELECT not(i.state='cargando' and value='false') FROM `inscriptions` i, configuration c WHERE i.id=:id and c.id='FORM_OPEN'");
        $stmt3->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt3->execute();

        return (!($stmt->fetchColumn()==0) && $stmt2->fetchColumn()==0 && $stmt3->fetchColumn()==1);
    }

    public static function fetchSavedValues($id, $token){
        $stmt = Connection::connect()->prepare("SELECT * FROM inscriptions WHERE id = :id AND access_token = md5(:token) ");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function saveFieldValue($id, $token, $field, $value){
        if($value=='SI' || $value=='NO' ||  substr( $field, 0, 8 ) === "document"){
            $stmt = Connection::connect()->prepare("UPDATE inscriptions SET `".$field."`= :val where id = :id and access_token = md5(:token)");
        }else{
            $stmt = Connection::connect()->prepare("UPDATE inscriptions SET `".$field."`= IF((select count(1) from config_params where field='".$field."')>1, :val,initcap(:val)) where id = :id and access_token = md5(:token)");
        }
        $stmt->bindParam(':val', $value, PDO::PARAM_STR);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);

        if($stmt->execute()){
            return "success";
        } else {
            return "error";
        }
    }

    public static function fetchCareer($id){
        $stmt = Connection::connect()->prepare("SELECT display FROM config_params WHERE field='carrera' and value = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchValueConfiguration($id){
        $stmt = Connection::connect()->prepare("SELECT value FROM configuration WHERE id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchEmailConfiguration(){
        $stmt = Connection::connect()->prepare("SELECT id,value FROM configuration WHERE id like 'EMAIL_%'");

        $stmt->execute();

        $result = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $result[$row['id']] = $row['value'];
        }
        return $result;
    }

    public static function fetchConfiguration($id){
        $stmt = Connection::connect()->prepare("SELECT value FROM configuration where id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        
        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchCUE($id){
        $stmt = Connection::connect()->prepare("SELECT * FROM entidades_educativas WHERE cue = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);        
    }

    public static function searchCUE($name,$country,$province,$city){
        $where = '';
        if( !empty($name) ){
            $where = $where.' nombre like :name';
        }

        if( !empty($country) ){
            if(strlen($where)>0){
                $where = $where.' and';
            }
            $where = $where.' pais = :country';
        }

        if( !empty($province) ){
            if(strlen($where)>0){
                $where = $where.' and';
            }
            $where = $where.' provincia = :province';
        }

        if( !empty($city) ){
            if(strlen($where)>0){
                $where = $where.' and';
            }
            $where = $where.' localidad = :city';
        }

        $stmt = Connection::connect()->prepare("SELECT * FROM entidades_educativas WHERE ".$where." order by nombre");

        if( !empty($name) ){
            $nameFilter = '%'.$name.'%';
            $stmt->bindParam(':name', $nameFilter, PDO::PARAM_STR);
        }
        if( !empty($country) ){
            $stmt->bindParam(':country', $country, PDO::PARAM_STR);
        }
        if( !empty($province) ){
            $stmt->bindParam(':province', $province, PDO::PARAM_STR);
        }
        if( !empty($city) ){
            $stmt->bindParam(':city', $city, PDO::PARAM_STR);
        }

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);        
    }

    public static function searchCUEfilterValues($country,$province){
        $field = 'pais';
        $where = '';

        if( !empty($country) ) {
            $where = $where.'WHERE pais = :country';
            $field = 'provincia';
            if( !empty($province) ){
                $where = $where.' and provincia = :province';
                $field = 'localidad';
            }
        }
        $stmt = Connection::connect()->prepare("SELECT ".$field." as item FROM entidades_educativas ".$where." group by 1 order by 1");

        if( !empty($country) ){
            $stmt->bindParam(':country', $country, PDO::PARAM_STR);
        }
        if( !empty($province) ){
            $stmt->bindParam(':province', $province, PDO::PARAM_STR);
        }

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);        
    }

    public static function checkAdmissionCode($code){
        $stmt = Connection::connect()->prepare("SELECT display FROM `config_params` WHERE field='carrera' and value=:code");

        $stmt->bindParam(':code', $code, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchColumn();
    }

}
?>