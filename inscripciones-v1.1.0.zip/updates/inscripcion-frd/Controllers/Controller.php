<?php
require_once('Modells/Data.php');
require_once('Modells/Redirection.php');
require_once('Modells/emailer.php');

class Controller
{

    private $pagina = '';

    //Llamar a la plantilla
    public function loadLayout()
    {
        session_start();
        //Include se utiliza para invocar el arhivo que contiene el codigo HTML
        
        if( isset($_SESSION['iniciada']) ){
            include 'Views/layout.php';
        }else{
            //include 'login.php';
            //include 'Views/formulario-inscripcion.php';
            include 'Views/layout.php';
        }
        
    }

    //Interacción con el usuario
    public function showPage()
    {
        //Trabajar con los enlaces de las páginas
        //Validamos si la variable "action" viene vacia, es decir cuando se abre la pagina por primera vez se debe cargar la vista index.php
/*
        if(isset($_GET['action'])){
            //guardar el valor de la variable action en views/modules/navegacion.php en el cual se recibe mediante el metodo get esa variable
            $enlace = $_GET['action'];
        }else{
            //Si viene vacio inicializo con el dashboard dependiendo del tipo de usuario loggeado
            if($_SESSION['tipoUsuario'] == 'Tutor'){
                $enlace = 'dashboard_tutor';
            }else{
                $enlace = 'inscription-form';
            }
        }
*/
        if(isset($_GET['action'])){
            if( $_GET['action'] === 'inscription'){
                if(isset($_GET['id']) && isset($_GET['token']) && Data::checkRegistration($_GET['id'], $_GET['token']) ){
                    $enlace = 'inscription-form';
                }else{
                    if(Data::fetchValueConfiguration('FORM_OPEN')=='true'){
                        $enlace = 'inscription-error';
                    }else{
                        $enlace = 'inscription-out';
                    }
                }
            }else{
                $enlace = $_GET['action'];
            }
        }else{
            if(Data::fetchValueConfiguration('FORM_OPEN')=='true'){
                $enlace = 'registration-form';
            }else{
                $enlace = 'inscription-out';
            }
        }
        include Redirection::mostrarPagina($enlace);
    }

    public function iniciarSesion()
    {

        if( isset($_POST['correo']) && isset( $_POST['contrasena'] ) )
        {

            $datos = array( 'correo'      => $_POST['correo'],
                            'contrasena'  => $_POST['contrasena'] );
            
            $respuesta = Data::validarUsuario($datos, 'tutores');

            if( $respuesta ) {
                $aceptacion = $respuesta['aceptacion'];
                $tipoUsuario = 'Tutor';
                $idUsuario = $respuesta['numero_empleado'];
            }else{
                $respuesta = Data::validarUsuario($datos, 'usuarios');
                $tipoUsuario = 'Administrador';
                $idUsuario = $respuesta['usuario_id'];
            }


            if( $respuesta )
            {
                session_start();
                $_SESSION['iniciada'] = true;
                $_SESSION['nombre'] = $respuesta['nombre'];
                $_SESSION['tipoUsuario'] = $tipoUsuario;
                $_SESSION['idUsuario'] = $idUsuario;
                if(isset($aceptacion) && !$aceptacion){
                    $_SESSION['aceptacion'] = $aceptacion;
                }

                header("location:index.php?action=dashboard");
                //echo 'Bienvenido al sistema';
            }else
            {
                header("location:login.php?msg=Correo o contraseña incorrectos");
                //echo 'Correo o contraseña incorrecto';
            }

        }
        
    }

    public function fetchEmailConfiguration(){
        return Data::fetchEmailConfiguration();
    }
    public function registerInscription() {
        if ( isset($_POST['alumnonumerodocumento']) && isset($_POST['contactoemail']) ) {
            $token = $_POST['token'];
            $action = $_POST['action'];
            // call curl to POST request
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('secret' => '6LenGNgZAAAAABdElnRDexxe_LnE3kTSk5LR5GyH', 'response' => $token)));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            $arrResponse = json_decode($response, true);
             
            // verify the response
            if($arrResponse["success"] == '1' && $arrResponse["action"] == $action && $arrResponse["score"] >= 0.5) {

                if(Data::hasInscription($_POST['alumnonumerodocumento'])){
                    echo "<script>$('input[name=carrera]').val('".$_POST['carrera']."');inscripto()</script>";
                }else{
                    $token = Data::registerInscription($_POST['alumnonumerodocumento'], $_POST['contactoemail'], $_POST['carrera']);

                    if(array_key_exists('error',$token)){
                        echo "<script>$('input[name=carrera]').val('".$_POST['carrera']."');error('no se pudo guardar')</script>";
                    }else{
                        Emailer::enviarURL($_POST['contactoemail'], $token['id'], $token['token']);
                        echo "<script>success('Hemos enviado un correo electrónico a ".$_POST['contactoemail']." con las indicaciones para continuar con su inscripción.')</script>";
                    }
                }

            } else {
                echo "<script>error('no se pudo comprobar el captcha')</script>";
            }

        }
    }

    public function closeInscription() {
        if(Data::hasInscription($_POST['alumnonumerodocumento'])){
            echo '<script>alert("Ocurrió un error al cerrar la inscripción. Ya hay una inscripción cerrada para este número de documento.")</script>';
        }else{
            if(Data::closeInscription($_POST['id'],$_POST['token'])){
                if(Data::getInscriptionState($_POST['id'])=='pendiente'){
                    Emailer::enviarConfirmacion($_POST['contactoemail'], $_POST['id']);
                }else{
                    Emailer::enviarConfirmacionCorreccion($_POST['contactoemail'], $_POST['id']);
                }
                echo '<script>window.location.href = "?action=inscription-closed";</script>';
            }else{
                echo '<script>alert("Ocurrió un error al cerrar la inscripción.")</script>';
            }
        }
    }

    public function getConfigParams() {
        return Data::fetchConfigParams($_GET['id'],$_GET['token']);
    }

    public function getSavedValues(){
        $savedValues = array();
        $savedValues = Data::fetchSavedValues($_GET['id'],$_GET['token']);
        return $savedValues;
    }

    public function getActiveQuestions(){
        return Data::fetchConfiguration('X_QUESTION');
    }

    public function getCareer($id) {
        return Data::fetchCareer($id);
    }

    public function needAdmissionCode(){
        return Data::fetchConfiguration('FORM_ADMIN')=='true';
    }

    public function getDomicilioTitle(){
        return Data::fetchConfiguration('DATA_DOMI');
    }

}
?>