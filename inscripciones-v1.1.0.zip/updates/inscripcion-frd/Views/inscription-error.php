<br>
<div class="row">
	<div class="col-md-12">
		<center>
			<div class="alert alert-warning">La inscripción a la cual desea acceder ya fué cerrada.<br>No dude en comunicarse con nosotros en caso de algún problema.</div>
			<a href="." class="btn btn-info">Volver</a>
		</center>
	</div>
</div>