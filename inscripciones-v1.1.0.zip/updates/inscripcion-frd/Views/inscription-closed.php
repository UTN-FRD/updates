<br>
<div class="row">
	<div class="col-md-12">
		<center>
			<div class="alert alert-success">Se realizó la inscripción correctamente.</div>
			<a href="https://www.frd.utn.edu.ar/ingresantes/" class="btn btn-info">Volver</a>	
		</center>
	</div>
</div>