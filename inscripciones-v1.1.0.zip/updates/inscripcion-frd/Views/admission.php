<div class="modal fade" id="admissionModal" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="admissionModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="admissionModalLabel">Código de Admisión</h5>
      </div>
      <div class="modal-body">
      	<div class="row">
			<div class="col">
				<div id="admission-alert" class="alert alert-danger collapse">El código ingresado no es válido.</div>
				<div class="form-group">
					<label for="formadmissioncode">Ingrese el código de admisión que recibió en la entrevista.</label>
					<input type="text" class="form-control" id="formadmissioncode" name="formadmissioncode" >
					<div class="invalid-feedback">Es necesario ingresar el Código de admisión para inscribirse. Este código es generado e informado en la entrevista de admisión.</div>
				</div>
			</div>
		</div>
      </div>
      <div class="modal-footer">
		<button type="button" id="formadmissionosend" class="btn btn-info"><span class="collapse"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span><span>Loading...</span></span><span>Aceptar</span></button>
      </div>
    </div>
  </div>
</div>
<script>
$(document).ready(function(){
	$('#admissionModal').modal('show');
});

$('#formadmissioncode').keypress(function(e){
	$('#formadmissioncode').siblings('.invalid-feedback').hide();
	if(e.which == 13) {
        verificarCodigo();
    }
});
$('#formadmissionosend').click(function(){
	verificarCodigo();
});
function verificarCodigo(){
	var valid = true;
	if( $('#formadmissioncode').val()=='' ){
		$('#formadmissioncode').siblings('.invalid-feedback').show();
		valid = false;
	}
	if(!valid) return;
	$('button#formadmissionosend>span:nth-child(1)').removeClass('collapse');
	$('button#formadmissionosend>span:nth-child(2)').addClass('collapse');
	$('button#formadmissionosend').attr('disabled', true);
	$.ajax({
		type: 'POST',
		url: './ajax/checkadmissioncode.php',
		data:'code='+$('#formadmissioncode').val(),
		success: function(data){
			if(data==''){
				$('#admission-alert').show();
				setTimeout(function(){
					$('button#formadmissionosend>span:nth-child(1)').addClass('collapse');
					$('button#formadmissionosend>span:nth-child(2)').removeClass('collapse');
					$('button#formadmissionosend').attr('disabled', false);
				},1000);
			}else{
				$('input[name=carrera]').val($('#formadmissioncode').val());
				$('#c-name').html('Inscripci&oacute;n a la carrera '+data);
				$('#formadmissioncode').val('');
				$('#admissionModal').modal('hide');
			}

		}
	});
}
</script>



