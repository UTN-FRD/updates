<?php 
require_once('../Modells/Data.php');

$result = Data::searchCUEfilterValues($_POST["pais"],$_POST["provincia"]);

echo json_encode($result);

?>