<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["related_field"])) {
    $field = $_POST["related_field"];
    $value = "{$_POST["related_value"]}";
    $params = Data::fetchConfigParamsRelated($field, $value);

echo json_encode($params);
} 
?>