var reFileExt = /(?:\.([^.]+))?$/;
var tecnicaturas = ['41','515','58','34','141'];
$.fn.isValid = function(){
  return this[0].checkValidity()
}
$(document).ready(function(){
	$('*[name]').each(function(){
		if($(this).attr('type')!='hidden' && !activeQuestions.includes( $(this).attr('name') )){
			$(this).parents('.question').remove();
		}
	});
	/*** Delete empty sections ***/
	$('section').each(function(){
		if($(this).find('.question').length==0){$(this).remove();}
	});

	/*** Form validation ***/
	$('.needs-validation').submit(function(event){
		var validData = true;
		var failFields = ': ';
		
		if($('#contactotelefonofijo').val()=='' && $('#contactotelefonomovil').val()==''){
			$("#contactotelefonofijo, #contactotelefonomovil").siblings().find('input').addClass('is-invalid');
			validData = false;
			failFields = failFields+' teléfono,';
		}

		if ($("[name=discapacidad]:checked").val()=='SI' && $("[name='discapacidadtipo[]']:checked").length == 0) {
			validData = false;
			failFields = failFields+' tipo de discapacidad,';
		}

		$.each( $('.discapacidad-block input[type=checkbox][value=otro]:checked') , function (i, val) {
			$(val).siblings('input').attr('required', $('input[name=discapacidad]:checked').val()=='SI' );
		});

		if( esExtranjero() ){
			$('#documentacioncuil').prop('required',false);
		}else{
			if($('#documentacioncuil').val()=='' && savedValues['documentacioncuil']==''){
				validData = false;
				failFields = failFields+' Adjuntar CUIL,';
			}
		}


		$('input,select').each(function(e){
			if($(this).isValid()===false){
				failFields = failFields + ' ' + $(this).parents('.question').find('label').text().replaceAll(/\s/g,'') + ',';
			}
		});

		if (this.checkValidity() === false || validData === false) {
          event.preventDefault();
          event.stopPropagation();
          alert('Los siguientes valores faltan completar o tienen errores'+failFields+' ingrese los mismos y vuelva a intentar.');
        }else if(!confirm("Esta seguro que desea terminar la inscripción?")){
          event.preventDefault();
          event.stopPropagation();
        }
        $(this).addClass('was-validated');
        
	});

	/*** Special Valitations ***/
	$(".telefono input").keypress(function(e){
		$(".telefono input").removeClass('is-invalid');
	});

	$('#alumnonumerodocumento').keypress(function (e) {
		if( $('#alumnotipodocumento').val() === '1' ){
			if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				return false;
			}
		}
	});

	$('#nacnacionalidad').change(function(){
		if($(this).val()==="1"){
			$('#nacpais').val('Argentina');
			saveFieldValues($('#nacpais'));
			$('#nacpais').prop('disabled',true);
		}else{
			$('#nacpais').prop('disabled',false);
		}
	});
	
	$('*[name=secundarioegreso], #formaingreso, #nacnacionalidad, #alumnotipodocumento, #titulouniventramite').change(function(){
		updateValidations();
	});

	$('*[name=tecnotienepc]').change(function(){
		if($(this).val()==="NO"){
			$('#tecnodondepc').prop('disabled',true);
		}else{
			$('#tecnodondepc').prop('disabled',false);
		}
	});

	$('#nacnacionalidad').change(function(){
		if($(this).val()=='5'){ //extranjero temporal
			$('#nacvencdni').parent().show();
		} else {
			$('#nacvencdni').parent().hide();
		}
	});

	$('input[type=checkbox][value=otro]').change(function(){
		if($(this).prop('checked')){ 
			$(this).siblings('input').attr('disabled',false);
			$(this).siblings('input').attr('required',true);
			$(this).siblings('input, .invalid-feedback').show();
			var txt = $(this).siblings('label').text();
			$(this).siblings('label').html(txt+'<span style="color:red">*</span>');
		} else {
			$(this).siblings('input').attr('disabled',true);
			$(this).siblings('input').attr('required',false);
			$(this).siblings('input, .invalid-feedback').hide();
			$(this).siblings('label').children('span').remove();
		}
	});
	$('input[name=discapacidad]').change(function(){
		$.each( $('.discapacidad-block input[type=checkbox][value=otro]:checked') , function (i, val) {
			$(val).siblings('input').attr('required', $('input[name=discapacidad]').val()=='SI' );
		});
	});

	/*** Manage conditional hidden sections ***/
	$('*[data-dynamic-section]').change(function(){
		var elem = '.'+$(this).data('dynamic-section')+'-block';
		var checked = $(this).val();

		$.each($(elem), function (i, val) {
			if( $(val).data("showon").toString().split("|").includes(checked) ){
				$(val).show(200);
				$(val).children('input[data-required]').prop('required',true);
			}else{
				$(val).hide(200);
				$(val).children('input[data-required]').prop('required',false);
			}
		});
	});

	/*** disabled related fields ***/
	$.each($('select[data-related]').data('related').split(/\|/), function (i, val) {
		$('#'+val).prop('disabled','disabled');
	});

	/*** contact fields ***/
	$('#contactotelefonofijo').change(function(){
		if( $(this).val() ){
			$('#contactotelefonomovil').prop('required',false);
		}
	});
	$('#contactotelefonomovil').change(function(){
		if( $(this).val() ){
			$('#contactotelefonofijo').prop('required',false);
		}
	});

	/*** job fields ***/
	$('*[name=trabajotrabajas]').change(function(){
		if( $(this).val()=='SI' ){
			$('#trabajoenque').prop('required',true);
		}else{
			$('#trabajoenque').prop('required',false);
		}
	});
	
	/*** fetch data to related fields ***/
	$('select[data-related]').change(function(){
		if( $(this).val()=='' ){
			$.each($(this).data('related').split(/\|/), function (i, val) {
				$('#'+val).html('<option>--Seleccione--</option>');
				$('#'+val).prop('disabled',true);
				saveFieldValues($('#'+val));
			});
		}else{
			$.each($(this).data('related').split(/\|/), function (i, val) {
				$('#'+val).html('<option>--Seleccione--</option>');
			});
			getFieldRelatedValues($(this));
		}
	});

	$('#inscription-form select, #inscription-form input[type=text], #inscription-form input[type=radio], #inscription-form input[type=cuil], #inscription-form input[type=date], #inscription-form input[type=email], #inscription-form input[type=number]').change(function(){
		saveFieldValues($(this));
	});

	$('#inscription-form input[type=checkbox]').change(function(){
		saveArrayFieldValue( $('[name="'+$(this).attr('name')+'"]') );
	});

	$('input[type=phone]').change(function (e) {
		var r = $(this).closest('.telefono');
		r.children('input[type=hidden]').val('('+r.find('.prefix').val()+') '+r.find('.nbr').val());
		if(r.find('.prefix').val() && r.find('.nbr').val()){
			$('#contactotelefonofijo, #contactotelefonomovil').siblings().find('input').prop('required',false);
		}else{
			$('#contactotelefonofijo, #contactotelefonomovil').siblings().find('input').prop('required',true);
		}
		saveFieldValues(r.find('input[type=hidden]'));
	});

	$('#secundariocue,#titulounivcue').change(function(){
		buscarCUE($(this).val(), function(data){
				if(data!==false){
					setInstitucion(data);
				}else{
					alert('El CUE ingresado no corresponde a ninguna institución.');
					clearInstitucion();
				}
			});
	});

	/*** fetch option values to each select ***/
	Object.keys(configParams).forEach(function(key){
		$('#'+configParams[key]["field"]).append('<option value="'+configParams[key]["value"]+'">'+configParams[key]["display"]+'</option>');
	});

	/*** fetch saved values to each responde ***/
	var savedValuesCounter = 0;
	Object.keys(savedValues).forEach(function(key){
		var selector = '*[name="'+key+'"]';
		$(selector).prop('disabled',false);
		$(selector).addClass('is-valid');
		if( $(selector).attr('type')=='radio'){
			$(selector+'[value='+savedValues[key]+']').attr('checked',true);
		}else if( $(selector).attr('type')=='checkbox'){
			var vals = savedValues[key].split(' ');
			for (i = 0; i < vals.length; i++) {
				$(selector+'[value="'+vals[i]+'"]').attr('checked', true);
			}
		}else if( $(selector).attr('type')=='file'){
			$(selector).prop('required',false);
			if(['doc','docx'].indexOf(reFileExt.exec(savedValues[key])[1])>-1){
				$('#'+key+'-subido').prop('src','./img/word.png');
			}else if(['pdf'].indexOf(reFileExt.exec(savedValues[key])[1])>-1){
				$('#'+key+'-subido').prop('src','./img/pdf.png');
			}else if(['jpeg','jpg','png'].indexOf(reFileExt.exec(savedValues[key])[1])>-1){
				$('#'+key+'-subido').prop('src','./documents/'+$('#id').val()+'/'+savedValues[key]);
			}else{
				$('#'+key+'-subido').prop('src','./img/file.png');
			}
			$('#'+key+'-subido').parent().addClass('valid');
		}else if(key=='contactotelefonofijo' || key=='contactotelefonomovil'){
			$(selector).val(savedValues[key]);
			var phone = savedValues[key].split(')');
			$(selector).siblings().find('input.prefix').val(phone[0].substring(1));
			$(selector).siblings().find('input.nbr').val(phone[1].trim());
			$('#contactotelefonofijo, #contactotelefonomovil').siblings().find('input').prop('required',false);
		}else{
			$(selector).val(savedValues[key]);
		}
		$(selector).show();

		if( $(selector).data('related') ){
			getFieldRelatedValues($(selector));
		}

		var elem = '.'+$(selector).data('dynamic-section')+'-block';
		$.each($(elem), function (i, val) {
			if( $(val).data("showon").toString().split("|").includes(savedValues[key]) ){
				$(val).show(200);
			}
		});
		savedValuesCounter++;
		if(savedValuesCounter>=Object.keys(savedValues).length){
			updateValidations();
		}
	});
	$('*[name="carrera"]').prop('disabled',savedValues['carrera_preseteada']=='1');
	
	/*** Upload files ***/
	$('input[type=file]').change(function(){
        var image_extension = $( this )[0].files[0].name.split('.').pop().toLowerCase();
        if( image_extension!='pdf'){
			alert("Sólo puede subir archivos PDF.");
			return;
        }

		var formData = new FormData();
		var file_name=$(this).val();
		var fieldName = $(this).attr('id');
		$('label[for='+fieldName+']>.spinner-border').show();
		formData.append('fileupload',$( this )[0].files[0], file_name);

		$.ajax({
			url: './ajax/upload.php?id='+$('#id').val()+'&token='+$('#token').val()+'&field='+fieldName,
			data: formData,
			processData: false,
			contentType: false,
			type: 'POST',
			success: function(data){
				if(['doc','docx'].indexOf(reFileExt.exec(data)[1])>-1){
					$('#'+fieldName+'-subido').prop('src','./img/word.png');
				}else if(['pdf'].indexOf(reFileExt.exec(data)[1])>-1){
					$('#'+fieldName+'-subido').prop('src','./img/pdf.png');
				}else if(['jpeg','jpg','png'].indexOf(reFileExt.exec(data)[1])>-1){
					$('#'+fieldName+'-subido').prop('src','./documents/'+$('#id').val()+'/'+data);
				}else{
					$('#'+fieldName+'-subido').prop('src','./img/file.png');
				}
				$('#'+fieldName+'-subido').parent().addClass('valid');
				$('label[for='+fieldName+']>.spinner-border').hide();
			}
		});
	});

});

/*** fetch related data ***/
function getFieldRelatedValues(elem) {
	$.ajax({
		type: 'POST',
		url: './ajax/getfieldvalues.php',
		data:'related_field='+elem.attr('id')+'&related_value='+elem.val(),
		dataType: "json",
		success: function(data){
			var fieldsToReset = [];
			data.map(function(d){
				var singleVal = false;
				if(data.filter(function(o){return o.field==d.field}).reduce((cant,o)=>cant+1,0)==1){
					$('#'+d.field).html('');
					singleVal=true;
				}else{
					if(fieldsToReset.indexOf(d.field)==-1){
						fieldsToReset.push(d.field);
					}
				}
				$('#'+d.field).append($('<option/>',{'value':d.value,'text':d.display}));
				if(singleVal){
					$('#'+d.field).prop('disabled',true);
					saveFieldValues($('#'+d.field));
				}else{
					$('#'+d.field).prop('disabled',false);
				}
			});
			for(var i in fieldsToReset){
				saveFieldValues($('#'+fieldsToReset[i]));
				var elem = '.'+$('#'+fieldsToReset[i]+'[data-dynamic-section]').data('dynamic-section')+'-block';
				var checked = $('#'+fieldsToReset[i]+'[data-dynamic-section]').val();

				$.each($(elem), function (i, val) {
					if( $(val).data("showon").toString().split("|").includes(checked) ){
						$(val).show(200);
						$(val).children('input[data-required]').prop('required',true);
					}else{
						$(val).hide(200);
						$(val).children('input[data-required]').prop('required',false);
					}
				});
			}
		}
	});
}

/*** save field ***/
function saveFieldValues(elem) {
	var value = elem.val()=='--Seleccione--'?'':elem.val();
	$.ajax({
		type: 'POST',
		url: './ajax/savefieldvalues.php',
		data:'field='+elem.attr('name')+'&value='+value+'&id='+$('#id').val()+'&token='+$('#token').val(),
		dataType: "json",
		success: function(data){
			if(data=='success'){
				elem.addClass('is-valid');
			}else{
				elem.addClass('is-invalid');
			}
		}
	});
}

function saveArrayFieldValue(elem) {
	var field = elem.attr('name');
	var value = '';
	elem.serializeArray().map(function(obj) {
	    value=value+obj.value+' ';
	});
	value = value.substr(0,value.length-1);

	$.ajax({
		type: 'POST',
		url: './ajax/savefieldvalues.php',
		data:'field='+field+'&value='+value+'&id='+$('#id').val()+'&token='+$('#token').val(),
		dataType: "json",
		success: function(data){
			if(data=='success'){
				elem.addClass('is-valid');
			}else{
				elem.addClass('is-invalid');
			}
		}
	});
}

function updateValidations(){

	if( $('#alumnotipodocumento').val() === '1' ){
		var nbr = $('#alumnonumerodocumento').val();
		$('#alumnonumerodocumento').val( nbr.replace(/[^0-9]/g, '') );
		saveFieldValues($('#alumnonumerodocumento'));
	}

	if( $('#formaingreso').val() == 'art7'){
		$('label[for=documentacionanalitico]>span.description').text('Certificado de estudios (si posee alguno).');
		$('#documentacionanalitico').prop('required',false);
		$('#secundariotituladoen').prop('required',false);
		$('#secundarioanalitico').prop('required',false);
		$('input[name=secundariotecnico]').prop('required',false);
		$('#secundariocue').prop('required',false);
	}else{
		if( $('*[name=secundarioegreso]:checked').val()=='NO' ){
			$('label[for=documentacionanalitico]>span.description').text('Constancia alumno regular');
			if( tecnicaturas.includes($('#carrera').val()) ){
				$('*[name=secundarioegreso]').parent().siblings('.invalid').show();
			}
		}else{
			if( esExtranjero() ){
				$('label[for=documentacionanalitico]>span.description').text('Convalidación del título por el Ministerio de Educación Argentino.');
			}else{
				$('label[for=documentacionanalitico]>span.description').text('Certificado analítico de estudios secundarios o constancia de título en trámite.');
			}
			$('*[name=secundarioegreso]').parent().siblings('.invalid').hide();			
		}
		$('#documentacionanalitico').prop('required',true);
	}

	if( $('#alumnotipodocumento').val()==1 ){ //DNI
		$('label[for=documentaciondni]>span.description').text('DNI (frente y reverso)');
	}else if( $('#alumnotipodocumento').val()==2 ){ //Pasaporte
		$('label[for=documentaciondni]>span.description').text('Pasaporte');
	}else{ //otro
		$('label[for=documentaciondni]>span.description').text('Documento que identifique identidad');
	}

	if( $('#titulouniventramite:checked').val()==2 ){
		$('#documentacioncertmaterias').parents('.question').show();
		$('#documentacioncertmaterias').prop('required',true);
		$('#documentaciontitulogrado').parents('.question').hide();
		$('#documentaciontitulogrado').prop('required',false);
	}else{
		$('#documentacioncertmaterias').parents('.question').hide();
		$('#documentacioncertmaterias').prop('required',false);
		$('#documentaciontitulogrado').parents('.question').show();
		$('#documentaciontitulogrado').prop('required',true);
	}
}

function esExtranjero(){
	return $('#nacnacionalidad').val() == 4 || $('#nacnacionalidad').val() == 5;
}

function setInstitucion(data){
	// {"cue":"104","nombre":"LICEO N\u00b0 1 INSTITUTO POLIT\u00c9CNICO OSIMANI Y LLERENA ","direccion":" ","localidad":" ","provincia":" ","pais":"REP\u00daBLICA ORIENTAL DEL URUGUAY ","facultad":" "}
	$('#'+sectionCUEModal+'institucion').val(data.nombre+' '+data.facultad);
	$('#'+sectionCUEModal+'institucion').prop('disabled',true);
	$('#'+sectionCUEModal+'institucion').trigger('change');
	//$('#').val(data.direccion);
	$('#'+sectionCUEModal+'localidad').val(data.localidad);
	$('#'+sectionCUEModal+'localidad').prop('disabled',true);
	$('#'+sectionCUEModal+'localidad').trigger('change');
	$('#'+sectionCUEModal+'provincia').val(data.provincia);
	$('#'+sectionCUEModal+'provincia').prop('disabled',true);
	$('#'+sectionCUEModal+'provincia').trigger('change');
	//$('#').val(data.pais);
}

function clearInstitucion(){
	$('#'+sectionCUEModal+'institucion').val('');
	$('#'+sectionCUEModal+'institucion').prop('disabled',false);
	$('#'+sectionCUEModal+'institucion').trigger('change');
	//$('#').val(data.direccion);
	$('#'+sectionCUEModal+'localidad').val('');
	$('#'+sectionCUEModal+'localidad').prop('disabled',false);
	$('#'+sectionCUEModal+'localidad').trigger('change');
	$('#'+sectionCUEModal+'provincia').val('');
	$('#'+sectionCUEModal+'provincia').prop('disabled',false);
	$('#'+sectionCUEModal+'provincia').trigger('change');
	//$('#').val(data.pais);
}

function updateSearchCUE( elem ){
	$.ajax({
		url:'./ajax/cuefiltervalues.php',
		data:'pais='+$('#searchCUEpais').val()+'&provincia='+$('#searchCUEprovincia').val(),
		type:'POST',
		dataType:'json',
		success: function(data){
			data.map(function(obj){
				elem.append($('<option/>',{value:obj.item,text:obj.item}));
			});
		}
	});
}
function buscarCUE(cue, callback){
	$.ajax({
		url: './ajax/cue.php',
		data: 'id='+cue,
		type: 'POST',
		dataType: 'json',
		success: callback
	});
}