<?php
require_once('Modells/Data.php');

$controller = new Controller();
date_default_timezone_set('America/Argentina/Buenos_Aires');
$inscripciones = Data::getInscriptionCountByCareer();
?>
<div class="container">
	<?php
	if(sizeof($inscripciones)==0){
	?>
	<div class="row">
		<div class="col-12">
			<h2>No hay inscripciones para exportar</h2>
		</div>
	</div>
	<?php
	}else{
	?>
	<form id="export-data" action="ajax/exportCampus.php" method="get" accept-charset="utf-8">
	<div class="row">
		<div class="col-12">
			<h2>Generar archivo con las siguientes carreras</h2>
			<?php
			foreach (Data::getInscriptionCountByCareer() as $key => $value) {
				echo '<div class="form-check"><input class="form-check-input" type="checkbox" value="'.$value['carrera_id'].'" name="carreras[]"><label class="form-check-label">'.$value['carrera'].' ('.$value['inscripciones'].' inscripciones)</label></div>';
			}
			?>
		</div>
	</div>
	<hr>
	<div class="row">
		<div class="col-12">
			<div class="form-check">
				<input class="form-check-input" type="checkbox" value="1" name="incluyecarrera">
				<label class="form-check-label">Incluir Carrera</label>
			</div>
			<div class="form-check">
				<input class="form-check-input" type="checkbox" value="1" name="incluyecomision">
				<label class="form-check-label">Incluir Comisión</label>
			</div>
			<div class="form-check">
				<input class="form-check-input" type="checkbox" value="1" name="incluyesede">
				<label class="form-check-label">Incluir Sede</label>
			</div>

			<input type="hidden" name="generate" value="1">
			<button class="btn btn-success">Generar y descargar archivo</button>
		</div>
	</div>
	</form>
	<?php
	}
	?>
</div>
<style>
th{text-align: center}
td{text-align: right;}
td:first-child{text-align: left;}
tr:last-child{font-weight: bolder;}
</style>

<script>
$(document).ready(function(){
    $('#export-data').on('submit', function(e){
        e.preventDefault();
		var hayCarreras = $('input[name="carreras[]"]').is(':checked');
        if (!hayCarreras) {
			alert("Debe seleccionar al menos una carrera.");
		}else{
            this.submit();
        }
    });
});
</script>
