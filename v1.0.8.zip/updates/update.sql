UPDATE `configuration` SET `value`='1.0.8' WHERE `id`='VERSION';
ALTER TABLE `inscriptions` ADD `hijosacargo` VARCHAR(100) NULL AFTER `tecnousointernet`;
INSERT INTO `config_params` (`field`, `value`, `display`, `sort_criteria`) VALUES ('hijosacargo', '0', 'No tiene', 0), ('hijosacargo', '1', '1', 1), ('hijosacargo', '2', '2', 2), ('hijosacargo', '3', 'Más de 2', 3);

ALTER TABLE `inscriptions` ADD `emergenciacontacto` VARCHAR(100) NULL AFTER `contactotelefonomovil`;
ALTER TABLE `inscriptions` ADD `emergenciatelefono` VARCHAR(100) NULL AFTER `emergenciacontacto`;
