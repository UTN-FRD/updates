<?php
require( 'Config.php' );

class Connection{
    public static function connect(){
        $pdo = new PDO("mysql:host=".$GLOBALS['dbhost'].";dbname=".$GLOBALS['dbname'].";charset=utf8", $GLOBALS['dbuser'], $GLOBALS['dbpass']);
        return $pdo;
    }

}