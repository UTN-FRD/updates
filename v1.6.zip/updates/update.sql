update `configuration` set `value`='1.6' where `id`='VERSION';

ALTER TABLE `inscriptions` ADD `alumnogenero` VARCHAR(50) NULL AFTER `alumnosexo`, ADD `alumnogenerodet` VARCHAR(255) NULL AFTER `alumnogenero`;

INSERT INTO `config_params` (`field`, `value`, `display`) VALUES 
('alumnogenero','0','Sin Informacion'),
('alumnogenero','1','Mujer'),
('alumnogenero','2','Mujer Trans'),
('alumnogenero','3','Lesbiana'),
('alumnogenero','4','Travesti'),
('alumnogenero','5','Transexual'),
('alumnogenero','6','Transgénero'),
('alumnogenero','7','Varón'),
('alumnogenero','8','Varón Trans'),
('alumnogenero','9','Gay'),
('alumnogenero','10','Bisexual'),
('alumnogenero','11','No binarie'),
('alumnogenero','12','Género Fluído'),
('alumnogenero','13','Ninguno Anterior'),
('alumnogenero','14','No Responde');

UPDATE `configuration` SET `description`='ID de la extensión áulica a enviar al SysAcad (vacio para todas)' WHERE `id`='I_SEDE';
UPDATE `configuration` SET `description`='ID de la comisión en la que se inscribe en el SysAcad' WHERE `id`='I_COMISION';
UPDATE `configuration` SET `description`='Materias del plan 2016 en las que se inscribe en el SysAcad (separadas por coma)' WHERE `id`='I_MATERIA';
UPDATE `configuration` SET `description`='Estado en el cual la inscripción se enviará al SysAcad (usualmente pendiente o aprobado)' WHERE `id`='SA_STATE';

