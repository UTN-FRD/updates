<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["id"])) {
	echo json_encode( Data::changeFacultad( $_POST["id"] ) );
} 
?>