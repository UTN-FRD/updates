<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["id"])) {
    $id = $_POST["id"];
    $result = Data::fetchCarreraDetail($id);

echo json_encode($result);
} 
?>