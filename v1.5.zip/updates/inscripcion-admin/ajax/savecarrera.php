<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["id"]) && !empty($_POST["nombre"]) && !empty($_POST["mode"])) {
	if($_POST["mode"]=="edit"){
		echo Data::updateCarrera( $_POST["id"], $_POST["nombre"], $_POST["sedes"], $_POST["ingresos"] );
	}
	if($_POST["mode"]=="new"){
		echo Data::addCarrera( $_POST["id"], $_POST["nombre"], $_POST["sedes"], $_POST["ingresos"] );
	}
} 
?>