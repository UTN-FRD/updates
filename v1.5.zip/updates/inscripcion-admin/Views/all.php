<p>Se muestran todas las inscripciones que se encuentran en el sistema, en cualquier <a data-toggle="collapse" href="#collapseEstados" role="button" aria-expanded="false" aria-controls="collapseEstados">estado (ver estados)</a> y de cualquier fecha.</p>
<div class="collapse" id="collapseEstados">
    <div class="card card-body">
        <img class="card-img" src="img/inscripcionfrd-estados.jpg"/>
    </div>
</div>

<table id="example" class="display" >
    <thead>
        <tr>
            <th>Apellido</th>
            <th>Nombre</th>
            <th>Nro Documento</th>
            <th>Correo</th>
            <th>Carrera</th>
            <th>Sede</th>
            <th>Estado</th>
            <th>A&ntilde;o</th>
            <th></th>
        </tr>
    </thead>
</table>

<script>
<?php
require_once('Modells/Data.php');

if( $_SESSION['rol']=='Admin'){
    $carreras = json_encode(array_filter(Data::fetchCarreras()));
    $sedes = json_encode(array_filter(Data::fetchSedes()));
    $estados = json_encode(array_filter(Data::fetchEstados()));
    $anios = json_encode(array_filter(Data::fetchAniosIngreso()));
    $prefilter = "";
}else if( $_SESSION['rol']=='Supervisor'){
    $anio = Data::fetchConfiguration('ANIO_INSC');
    $anios = json_encode(array($anio));
    $sedeshabilitadas = explode(" ", Data::fetchSedesFor($_SESSION['user_id']));
    $sedes = json_encode(array_filter( $sedeshabilitadas ));
    $carreras = json_encode(array_filter( Data::fetchCarrerasFor($_SESSION['user_id'])));
    $estados = '["pendiente","rechazado","corregido","aprobado"]';
    $prefilter = "yadcf.exFilterColumn(table, [ [5, '".$sedeshabilitadas[0]."'] ]);
    yadcf.exFilterColumn(table, [ [6, 'pendiente'] ]);
    yadcf.exFilterColumn(table, [ [7, '".$anio."'] ]);
    $('#yadcf-filter--example-7').prop('disabled', 'disabled');
    $('#yadcf-filter--example-7-reset').prop('disabled', 'disabled');
    ";
    if( count($sedeshabilitadas)>0 ){
        $prefilter = $prefilter ."$('#yadcf-filter--example-5').prop('disabled', 'disabled');
        $('#yadcf-filter--example-5-reset').prop('disabled', 'disabled');";
    }
}
?>

var carreras = jQuery.parseJSON(JSON.stringify(<?= $carreras ?>));
var sedes = jQuery.parseJSON(JSON.stringify(<?= $sedes ?>));
var estados = jQuery.parseJSON(JSON.stringify(<?= $estados ?>));
var anios = jQuery.parseJSON(JSON.stringify(<?= $anios ?>));



$(document).ready(function() {
    var table = $('#example').DataTable( {
        'processing': true,
        'serverSide': true,
        'search': { 'regex': true },
        'ajax': './ajax/dt_all.php',
        'columnDefs': [ 
            {
                'targets': -1,
                'data': null,
                'defaultContent': '<button class="btn btn-success">Ver detalle</button>'
            }
        ],
        'createdRow': function( row, data, dataIndex){
            var className ='';
            switch(data[6]){
                case "aprobado": className = 'table-success'; break;
                case "pendiente": className = 'table-warning'; break;
                case "rechazado": className = 'table-danger'; break;
            }
            $(row).addClass( className );
        }
    } );

    yadcf.init(table, [
        {column_number : 4, data:carreras, column_data_type: "html", html_data_type: "text", filter_default_label: 'Todos'},
        {column_number : 5, data:sedes, column_data_type: "html", html_data_type: "text", filter_default_label: 'Todos'},
        {column_number : 6, data:estados, column_data_type: "html", html_data_type: "text", filter_default_label: 'Todos'},
        {column_number : 7, data:anios, column_data_type: "html", html_data_type: "text", filter_default_label: 'Todos'}
        ]);
    <?= $prefilter ?>

    $('#example tbody').on( 'click', 'button', function () {
        var data = table.row( $(this).parents('tr') ).data();
        window.location = 'index.php?action=inscription-form&id='+data[ 8 ]; 
    } );

} );
</script>
<style>
.yadcf-filter{max-width:260px}
<?php
if( $_SESSION['rol']=='Supervisor'){
?>
td:nth-child(6), th:nth-child(6), td:nth-child(8), th:nth-child(8) {
  display: none
}
<?php
}
?>
</style>
