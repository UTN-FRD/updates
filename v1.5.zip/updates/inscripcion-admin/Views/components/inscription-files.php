<section>
	<h2>Documentación</h2>
	<br><br>
	<div id="documentacion" class="row">
		<div class="col-12 question">
			<h3>DNI (ambos lados) o Pasaporte</h3>
			<label for="documentaciondni">
				<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
			</label>
			<input name="documentaciondni" type="file">
			<div id="documentaciondni"></div>
		</div>
		<div class="col-12 question">
			<h3>CUIL</h3>
			<label for="documentacioncuil">
				<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
			</label>
			<input name="documentacioncuil" type="file">
			<div id="documentacioncuil"></div>
		</div>
		<div class="col-12 question">
			<h3>Partida de Nacimiento</h3>
			<label for="documentacionnacimiento">
				<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
			</label>
			<input name="documentacionnacimiento" type="file">
			<div id="documentacionnacimiento"></div>
		</div>
		<div class="col-12 question">
			<h3>Analítico o Certificado de Secundario</h3>
			<label for="documentacionanalitico">
				<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
			</label>
			<input name="documentacionanalitico" type="file">
			<div id="documentacionanalitico"></div>
		</div>
		<div class="col-12 question">
			<h3>Título de grado</h3>
			<label for="documentaciontitulogrado">
				<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
			</label>
			<input name="documentaciontitulogrado" type="file">
			<div id="documentaciontitulogrado"></div>
		</div>
		<div class="col-12 question">
			<h3>CV</h3>
			<label for="documentacioncv">
				<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
			</label>
			<input name="documentacioncv" type="file">
			<div id="documentacioncv"></div>
		</div>
		<div class="col-12 question">
			<h3>Certificado de T&iacute;tulo en tr&aacute;mite</h3>
			<label for="documentacioncertmaterias">
				<div class="spinner-border collapse" style="position:relative;left:110px;" role="status" aria-hidden="true"></div>
			</label>
			<input name="documentacioncertmaterias" type="file">
			<div id="documentacioncertmaterias"></div>
		</div>
	</div>
</section>
<script src="js/pdfjs/build/pdf.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#documentacion>div>div").each(function(){
		if(savedValues[$(this).attr('id')]){
			var file = savedValues[$(this).attr('id')];
			var url = '<?= $controller->getDocumentsUrl()?>/'+savedValues['id']+'/'+file;
			if(file.endsWith('pdf')){
				$(this).html($('<a/>',{'href':url,'text':'Descargar PDF','target':'_documents'}));
				$(this).append($('<canvas/>',{'id':$(this).attr('id')+'canvas'}))
				showPDF( url, $(this).attr('id')+'canvas' );
			}else{
				$(this).html($('<a/>',{'href':url,'text':'Descargar Imagen','target':'_documents'}));
				$(this).append($('<img/>',{'width':'100%','src':url}));
			}
		}
	});

});
function updateDocumentFile(fieldName, fileName){
	var url = '<?= $controller->getDocumentsUrl() ?>/'+$('#id').val()+'/'+fileName;
	$("#"+fieldName).html($('<a/>',{'href':url,'text':'Descargar PDF','target':'_documents'}));
	$("#"+fieldName).append($('<canvas/>',{'id':fieldName+'canvas'}))
	showPDF( url, fieldName+'canvas' );
}
</script>
<style>
#documentacion canvas,#documentacion img{border:solid 1px;width:100%}
#documentacion>div>div{align-content:center}
</style>
