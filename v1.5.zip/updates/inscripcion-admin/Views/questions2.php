<section>
	<h2>Carrera</h2>
	<div class="form-check question">
		<?php $field='carrera' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="carrera">Carrera </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='lugarcursado' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="lugarcursado">Lugar cursado  </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='formaingreso' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="formaingreso">Forma ingreso </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="formaingreso-block " data-showon="introductorio">
		<div class="form-check question">
			<?php $field='tipocursado' ?>
			<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="tipocursado">Modalidad de cursado </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		</div>
		<div class="form-check question">
			<?php $field='introductoriointensivo' ?>
			<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="introductoriointensivo">Desea realizar el curso intensivo de verano? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i><br>
		</div>
	</div>
</section>
<section>
	<h2>Alumno</h2>
	<div class="form-check question">
		<?php $field='alumnoapellido' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="alumnoapellido">Apellido </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='alumnonombres' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="alumnonombres">Nombres </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='alumnotipodocumento' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="alumnotipodocumento">Tipo de Documento </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='alumnonumerodocumento' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="alumnonumerodocumento">Número de Documento </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
	<?php $field='alumnocuil' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="alumnocuil">CUIL </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
	<?php $field='alumnosexo' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="alumnosexo">Sexo (como figura en su documento) </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
	<?php $field='alumnoestadocivil' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="alumnoestadocivil">Estado Civil </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
</section>
<section>
	<h2>Nacimiento</h2>
	<div class="form-check question">
		<?php $field='nacfechanacimiento' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="nacfechanacimiento">Fecha Nacimiento </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='nacnacionalidad' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="nacnacionalidad">Nacionalidad </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>

	<div class="form-check   question">
		<?php $field='nacvencdni' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="nacvencdni">Fecha de Vencimiento del DNI </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>

	<div class="form-check question">
		<?php $field='nacpais' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="nacpais">País </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='nacprovincia' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="nacprovincia">Provincia </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='naclocalidad' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="naclocalidad">Localidad </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='nacpartidodepartamento' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="nacpartidodepartamento">Partido/Departamento </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='nacgruposanguineo' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="nacgruposanguineo">Grupo Sanguíneo </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
</section>
<section>
	<!-- DATA_DOMI -->
	<?php 
	$row = array_values(array_filter($config,function($v,$k) {
		return $v['id'] == "DATA_DOMI";
	}, ARRAY_FILTER_USE_BOTH))[0];
	?>
	<h2>
		<select id="DATA_DOMI" class="">
			<option value="Domicilio Actual" <?= $row['value']=='Domicilio Actual'?"selected":"" ?>>Domicilio Actual</option>
			<option value="Domicilio (como figura en su documento)" <?= $row['value']=='Domicilio (como figura en su documento)'?"selected":"" ?>>Domicilio (como figura en su documento)</option>
		</select>
	</h2>
	<script>
		$("#DATA_DOMI").change(function(){
			$.ajax({
				type: 'POST',
				url: './ajax/saveconfig.php',
				data:'id=DATA_DOMI&value='+$(this).val(),
				success: function(data){
					$(this).addClass("btn-success");
					setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
				}
			});
		});
	</script>

	<div class="form-check question">
		<?php $field='domiciliocalle' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="domiciliocalle">Calle </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='domicilionumero' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="domicilionumero">Número </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='domiciliopiso' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="domiciliopiso">Piso </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
	<?php $field='domiciliolocalidad' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="domiciliolocalidad">Localidad </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
	<?php $field='domiciliopartido' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="domiciliopartido">Partido </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
	<?php $field='domicilioprovincia' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="domicilioprovincia">Provincia / Estado / Departamento </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
	<?php $field='domiciliocp' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="domiciliocp">Código Postal </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
</section>
<section>
	<h2>Contacto</h2>
	<div class="form-check telefono question">
		<?php $field='contactotelefonofijo' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="contactotelefonofijo">Teléfono Fijo </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check telefono question">
		<?php $field='contactotelefonomovil' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="contactotelefonomovil">Teléfono Móvil </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='contactoemail' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="contactoemail">Correo Electrónico </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='contactoemailalternativo' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="contactoemailalternativo">Correo Electrónico Alternativo </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
</section>
<section>
	<h2>¿A quién recurrir en caso de que lo necesites?</h2>
	<div class="form-check question">
		<?php $field='emergenciacontacto' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="emergenciacontacto">Contacto </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='emergenciatelefono' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="emergenciatelefono">Tel&eacute;fono (incluir característica) </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
</section>
<section>
	<h2>Secundario</h2>
	<div class="form-check question">
		<?php $field='secundarioegreso' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundarioegreso">Secundario Completo </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i><br>
	</div>
	<br>
	<div class="secundarioegreso-block  " data-showon="NO">
		<div class="form-check question">
			<?php $field='secundarioestado' ?>
			<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="secundarioestado">Estado <span style="color:red">*</span> </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		</div>
	</div>
	<div class="secundarioegreso-block  " data-showon="SI">	
		<div class="form-check question">
			<?php $field='secundarioanioegreso' ?>
			<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="secundarioanioegreso">Año Egreso </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		</div>
	</div>
	<div class="form-check question">
		<?php $field='secundariotituladoen' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundariotituladoen">Nombre del título secundario obtenido o a obtener </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='secundariotecnico' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundariotecnico">Secundario Técnico? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i><br>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<br>
	<div class="form-check question">
		<?php $field='secundarioanalitico' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundarioanalitico">Constancia Analítico </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>

	<div class="form-check question">
		<?php $field='secundariocue' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundariocue">CUE del Colegio </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='secundarioinstitucion' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundarioinstitucion">Nombre Colegio </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='secundariolocalidad' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundariolocalidad">Localidad </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='secundarioprovincia' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundarioprovincia">Provincia </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='secundariodependede' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="secundariodependede">Depende de </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
</section>
<section>
	<h2>Estudios Universitarios o Superiores Previos</h2>
	<div class="form-check question">
		<?php $field='titulounivnombre' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="titulounivnombre">Titulo Universitario o Superior obtenido o a obtener (tal como figura en el diploma) </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='titulouniventramite' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="titulouniventramite">T&iacute;tulo en tr&aacute;mite </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i><br>
	</div>
	<br>
	<div class="form-check question">
		<?php $field='titulounivanioegreso' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="titulounivanioegreso">Año Egreso </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='titulounivcue' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="titulounivcue">CUE de la Institución </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='titulounivinstitucion' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="titulounivinstitucion">Nombre de la Institución </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='titulounivlocalidad' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="titulounivlocalidad">Localidad </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='titulounivprovincia' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="titulounivprovincia">Provincia </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>

</section>
<section>
	<h2>Otros Estudios</h2>
	<div class="form-check question">
		<?php $field='otrosestudiostipo' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="otrosestudiostipo">Tipo </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='otrosestudioscarrera' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="otrosestudioscarrera">Carrera </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='otrosestudiosinstitucion' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="otrosestudiosinstitucion">Institución </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='otrosestudiosmateriasaprobadas' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="otrosestudiosmateriasaprobadas">Cantidad de Materias Aprobadas </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='otrosestudiosestado' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="otrosestudiosestado">Estado </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
</section>
<section>
	<h2>Trabajo</h2>
	<div class="form-check question">
		<?php $field='trabajotrabajas' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="trabajotrabajas">Trabajas? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i><br>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<br>
	<div class="form-check question">
		<?php $field='situacionlaboral' ?>
		<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="situacionlaboral">Situación Laboral </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="trabajotrabajas-block  " data-showon="1|4">
		<div class="form-check question">
			<?php $field='trabajoocupacion' ?>
			<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="trabajoocupacion">Tipo de Trabajo </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
	</div>
	<div class="trabajotrabajas-block  " data-showon="2">
		<div class="form-check question">
			<?php $field='tipotrabajo' ?>
			<input type="checkbox" class="question form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="tipotrabajo">Tipo de Trabajo </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='tipoocupacion' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="tipoocupacion">Tipo de Ocupación </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		</div>
		<div class="form-check question">
			<?php $field='trabajoenque' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="trabajoenque">Ocupación/Cargo </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		</div>
		<div class="form-check question">
			<?php $field='trabajohoras' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="trabajohoras">Cantidad de horas semanales </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='trabajorelcarrera' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="trabajorelcarrera">Relación del trabajo con la carrera </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		</div>
		<div class="form-check question">
			<?php $field='trabajoempresa' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="trabajoempresa">Nombre de la Empresa </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='trabajodireccion' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="trabajodireccion">Dirección </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='trabajotelefono' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="trabajotelefono">Teléfono </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
	</div>
</section>
<section>
	<h2>Deporte</h2>
	<div class="form-check question">
		<?php $field='deporte' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="deporte">Qué practicas? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
</section>
<section>
	<h2>Tecnología</h2>
	<div class="form-check question">
		<?php $field='tecnotienepc' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="tecnotienepc">Tiene acceso a una computadora? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i><br>
	</div>
	<br>

	<div class="form-check question">
		<?php $field='tecnodondepc' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="tecnodondepc">Desde donde? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='tecnocelular' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="tecnocelular">Cuantos celulares hay en su hogar? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='tecnotieneinternet' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="tecnotieneinternet">Tiene acceso a Internet? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i><br>
	</div>
	<br>
	<div class="form-check question">
		<?php $field='tecnointernet' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="tecnointernet">Desde donde accede a Internet? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='tecnousointernet' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="tecnousointernet">Utiliza internet para </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
</section>
<section>
	<h2>Familia</h2>
	<div class="form-check question">
		<?php $field='hijosacargo' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="hijosacargo">Cantidad de hijos a cargo </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='familiaacargo' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="familiaacargo">Cantidad de familiares a cargo (sin contar los hijos)</label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
</section>
<section>
	<h3>Padre</h3>
	<div class="form-check question">
		<?php $field='padreapellido' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="padreapellido">Apellido </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='padrenombre' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="padrenombre">Nombre </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='padrefechanac' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="padrefechanac">Fecha de Nacimiento </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question" >
		<?php $field='padrevive' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="padrevive">Vive? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<br> 
	<div class="padrevive-block  " data-showon="SI">
		<div class="form-check question">
			<?php $field='padreestudios' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="padreestudios">Nivel de estudios alcanzados </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='padretrabajo' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="padretrabajo">Trabajo/actividad </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='padresituacionlaboral' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="padresituacionlaboral">Situación Laboral </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='padreobrasocial' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="padreobrasocial">Obra Social </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		</div>
		<br> 
	</div>
</section>
<section>
	<h3>Madre</h3>
	<div class="form-check question">
		<?php $field='madreapellido' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="madreapellido">Apellido </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='madrenombre' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="madrenombre">Nombre </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='madrefechanac' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="madrefechanac">Fecha de Nacimiento </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check dynamic-section question">
		<?php $field='madrevive' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="madrevive">Vive? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<br> 
	<div class="madrevive-block  " data-showon="SI">
		<div class="form-check question">
			<?php $field='madreestudios' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="madreestudios">Nivel de estudios alcanzados </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='madretrabajo' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="madretrabajo">Trabajo/actividad </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='madresituacionlaboral' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="madresituacionlaboral">Situación Laboral </label>
			<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
			<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
		</div>
		<div class="form-check question">
			<?php $field='madreobrasocial' ?>
			<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
			<label for="madreobrasocial">Obra Social </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		</div>
		<br>
	</div>
</section>
<section>
	<h3>Hermanos</h3>
	<div class="form-check question">
		<?php $field='hermanoscantidad' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="hermanoscantidad">Cantidad </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='hermanosedades' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="hermanosedades">Edades (separar por comas si son varios) </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='hermanosactividades' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="hermanosactividades">Actividades (separar por comas si son varias) </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
</section>
<section>
	<h3>Casa</h3>
	<div class="form-check question">
		<?php $field='casatipo' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="casatipo">Tipo de Vivienda </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='casacondicion' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="casacondicion">Condición </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='casamediotraslado' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="casamediotraslado">Cómo se trasladará a su lugar de estudios? </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
</section>
<section>
	<h2>Documentación</h2>
	<div class="form-check question">
		<?php $field='documentaciondni' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="documentaciondni">DNI </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='documentacioncuil' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="documentacioncuil">CUIL </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='documentacionnacimiento' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="documentacionnacimiento">Partida de Nacimiento </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='documentacionanalitico' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="documentacionanalitico">Analítico </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='documentaciontitulogrado' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="documentaciontitulogrado">Título de grado </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
	<div class="form-check question">
		<?php $field='documentacioncv' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="documentacioncv">CV </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
	</div>
	<div class="form-check question">
		<?php $field='documentacioncertmaterias' ?>
		<input type="checkbox" class="form-check-input" value="<?= $field ?>" id="<?= $field ?>" <?= in_array($field,$activeQuestions)?'checked':'' ?>>
		<label for="documentacioncertmaterias">Certificado de T&iacute;tulo en tr&aacute;mite </label>
		<i class="fa fa-info-circle btn-info" data-field="<?= $field ?>"></i>
		<i class="fa fa-share" alt="Enviado al SysAcad" title="Enviado al SysAcad"></i>
	</div>
</section>
