
$(document).ready(function(){
	/*** phone number format (in one field) ***/
	$('input[type=tel]').keypress(function (e) {
		if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			return false;
		}
		var curchr = this.value.length;
		var curval = $(this).val();

		if (curchr == 3 && curval.indexOf("(") <= -1) {
			$(this).val("(" + curval + ")" + "-");
		} else if (curchr == 4 && curval.indexOf("(") > -1) {
			$(this).val(curval + ") ");
		} else if (curchr == 5 && curval.indexOf(")") > -1) {
			$(this).val(curval + "-");
		} else if (curchr == 10) {
			$(this).val(curval + "-");
			$(this).attr('maxlength', '15');
		}
	});
	$('input[type=tel]').attr('maxlength', '15');

	/*** CUIL number format ***/
	$('input[type=cuil]').keypress(function (e) {
		if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			return false;
		}
		var curchr = this.value.length;
		var curval = $(this).val();

		if (curchr == 2 && curval.indexOf("-") <= -1) {
			$(this).val(curval + "-");
		} else if (curchr == 11) {
			$(this).val(curval + "-");
			$(this).attr('maxlength', '13');
		}
	});
	
	/*** Phone field input in two fields ***/
	$('input[type=phone]').keypress(function (e) {
		if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			return false;
		}
		var curchr = this.value.length;
		var curval = $(this).val();

		// argentinian prefix only starts with 0,1,2 or 3
		if ($(this).hasClass('prefix') && curchr == 0 && (e.keyCode < 48 || e.keyCode > 51)) {
			return false;
		}
	});



	/*** Add asterisk to each required field ***/
	$('*:required').each(function (idx){
		if($(this).attr('type')!='phone'){
			$(this).prev().append(' <span style="color:red">*</span>');
		}
	});
});

function showPDF( url, container ){
	// Loaded via <script> tag, create shortcut to access PDF.js exports.
	var pdfjsLib = window['pdfjs-dist/build/pdf'];

	// The workerSrc property shall be specified.
	pdfjsLib.GlobalWorkerOptions.workerSrc = 'js/pdfjs/build/pdf.worker.js';

	// Asynchronous download of PDF
	var loadingTask = pdfjsLib.getDocument(url);
	loadingTask.promise.then(function(pdf) {
		// Fetch the first page
		var pageNumber = 1;
		pdf.getPage(pageNumber).then(function(page) {
			var scale = 1;
			var viewport = page.getViewport({scale: scale});

			// Prepare canvas using PDF page dimensions
			var canvas = document.getElementById(container);
			var context = canvas.getContext('2d');
			canvas.height = viewport.height;
			canvas.width = viewport.width;

			// Render PDF page into canvas context
			var renderContext = {
				canvasContext: context,
				viewport: viewport
			};
			var renderTask = page.render(renderContext);
			renderTask.promise.then(function () {
			  console.log('Page rendered');
			});
		});
	}, function (reason) {
		// PDF loading error
		console.error(reason);
	});
}