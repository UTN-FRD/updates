<?php
require_once('Controllers/Controller.php');

$controller = new Controller();
$configParams = $controller->getConfigParams();
$savedValues = $controller->getSavedValues();
$activeQuestions = $controller->getActiveQuestions();
?>
<form method="POST" id="inscription-form" class="needs-validation" novalidate autocomplete="off">
	<?php include_once('components/inscription-questions.php') ?>
	<?php include_once('components/inscription-files.php') ?>
	<br><hr>
	<center>
		<button type="submit" class="btn btn-primary">Terminar Inscripción</button>
	</center>
	<br>
</form>
<?php include_once('components/inscription-cue.php') ?>

<script>
var savedValues = jQuery.parseJSON(JSON.stringify(<?= json_encode(array_filter($savedValues)); ?>));
var configParams = jQuery.parseJSON(JSON.stringify(<?= json_encode(array_filter($configParams)); ?>));
var activeQuestions = '<?= $activeQuestions; ?>'.split('|');
</script>
<script src="js/inscription-script.js"></script>
<?php
if(isset($_POST['id'])){ 
	$controller->closeInscription();
}
?>

