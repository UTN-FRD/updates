<?php
require_once('Controllers/Controller.php');
$controller = new Controller();
$useCaptcha = $controller->getUseCaptcha();
?>
<?php
if( $controller->needAdmissionCode() ) {
	include 'admission.php'; 
}
?>
<h2>INGRESO <?= Data::fetchConfiguration('ANIO_INSC') ?></h2>
<h2 id="c-name">

<?php if(isset($_GET['c'])){ ?>
	<?php if(Data::isCloseCarrer($_GET['c'])){ ?>
		<span style="color:red">El cupo de <?= $controller->getCareer($_GET['c']) ?> se encuentra completo</span>
		<script>
			$(document).ready(function(){
				$("button").html("Cupo Completo");
				$("button").prop("disabled", true);
			});
		</script>
	<?php } else {?>
		Inscripci&oacute;n a la Carrera: <?= $controller->getCareer($_GET['c']) ?>
	<?php } ?>
<?php } ?>
</h2>
<div class="row">
	<div class="col">
		<p>Para comenzar con la inscripción complete el siguiente formulario. Enviaremos un correo electrónico con las instrucciones para completar su inscripción.</p>
		<p>En caso de no recibir el correo electrónico o tener problemas con el proceso de inscripción, no dude en comunicarse con nosotros.</p>
	</div>
</div>

<div class="row">
	<div class="col">
		<div id="msg" class="alert collapse" role="alert"></div>
		<form id="registration-form" method="POST" class="needs-validation" novalidate autocomplete="off">
			<input type="hidden" value="<?= isset($_GET['c'])?$_GET['c']:'' ?>" name="carrera">
			<div class="form-group">
				<label for="alumnonumerodocumento">Número de Documento</label>
				<input type="text" class="form-control" id="alumnonumerodocumento" name="alumnonumerodocumento" required>
				<div class="invalid-feedback">Este valor es obligatorio.</div>
			</div>
			<div class="form-group">
				<label for="contactoemail">Ingrese su correo electrónico</label>
				<input type="email" class="form-control" id="contactoemail" name="contactoemail" required>
				<div class="invalid-feedback">Este valor es obligatorio y debe coincidir con la repetición del correo electrónico.</div>
			</div>
			<div class="form-group">
				<label for="contactoemailcheck">Repita su correo electrónico</label>
				<input type="email" class="form-control" id="contactoemailcheck" name="contactoemailcheck" required>
				<div class="invalid-feedback">Este valor es obligatorio y debe coincidir con el correo electrónico ingresado.</div>
			</div>
			<div id="validateemail" class="alert alert-danger collapse" role="alert">Las direcciones de correo no coinciden.</div>
			<br><hr>
			<center>
				<button type="submit" class="btn btn-info"><span class="collapse"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span><span>Loading...</span></span><span>Registrarse</span></button>
			</center>
			<br>
		</form>
	</div>
</div>
<?php 
if($useCaptcha=='true'){
?>
<script src="https://www.google.com/recaptcha/api.js?render=6LenGNgZAAAAAO07dCyLKL_qvMDRLzUyQmuT9V7R"></script>
<?php
}
?>
<script>
function error(msg){
	$( '#admissionModal' ).remove();
	$('#msg').addClass('alert-danger');
	$('#msg').html('Ocurrió un error al registrar la inscripción, '+msg+'.<br>Por favor intente más tarde o póngase en contacto con nosotros.');
	$('#msg').show(200);
}
function success(msg){
	$( '#admissionModal' ).remove();
	$('form').hide(200);
	$('#msg').addClass('alert-success');
	$('#msg').append(msg);
	$('#msg').show(200);
}
function inscripto(){
	$( '#admissionModal' ).remove();
	$('#msg').addClass('alert-warning');
	$('#msg').html('Ya existe una inscripci&oacute;n previa para este documento.<br>Póngase en contacto con nosotros ante cualquier inconveniente.');
	$('#msg').show(200);	
}
$(document).ready(function(){
	/*** Form validation ***/
	$('.needs-validation').submit(function(event){
		event.preventDefault();
        if($("#contactoemail").val()!==$("#contactoemailcheck").val()){
        	$("#contactoemail").addClass('is-invalid');
        	$("#contactoemailcheck").addClass('is-invalid');
        	$("#contactoemail").removeClass('is-valid');
        	$("#contactoemailcheck").removeClass('is-valid');
			$("#validateemail").removeClass('collapse');
        	event.stopPropagation();
        }else if (this.checkValidity() === false) {
          event.stopPropagation();
        }else{
        	$('button>span:nth-child(1)').removeClass('collapse');
        	$('button>span:nth-child(2)').addClass('collapse');
        	$('button').attr('disabled', true);
			<?php 
			if($useCaptcha=='true'){
			?>
	        grecaptcha.ready(function() {
	            grecaptcha.execute('6LenGNgZAAAAAO07dCyLKL_qvMDRLzUyQmuT9V7R', {action: 'registrar_inscripcion'}).then(function(token) {
	                $('#registration-form').prepend('<input type="hidden" name="token" value="' + token + '">');
	                $('#registration-form').prepend('<input type="hidden" name="action" value="registrar_inscripcion">');
	                $('#registration-form').unbind('submit').submit();
	            });;
	        });
			<?php
			}else{
			?>
			$('#registration-form').unbind('submit').submit();
			<?php
			}
			?>
        }
        $(this).addClass('was-validated');
	});
	$("#contactoemail, #contactoemailcheck").keypress(function(e){
		$("#validateemail").addClass('collapse');
	});
});
</script>
<?php
    $controller -> registerInscription();
?>

