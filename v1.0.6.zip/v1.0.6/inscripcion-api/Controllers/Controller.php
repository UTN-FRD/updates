<?php
require_once('Modells/Data.php');
class Controller {
    public function loadLayout() {
        session_start();
        if (!isset($_SERVER['PHP_AUTH_USER'])) {
			header('WWW-Authenticate: Basic realm="My Realm"');
			header('HTTP/1.0 401 Unauthorized');
			echo 'Acceso no autorizado';
			exit;
		} else {
			$user = array( 'username' => $_SERVER['PHP_AUTH_USER'],
                            'password' => $_SERVER['PHP_AUTH_PW'] );
            
            $respuesta = Data::checkUser($user);

            if( $respuesta ) {
            	include 'Views/inscriptions.php';
			} else {
				header('WWW-Authenticate: Basic realm="My Realm"');
				header('HTTP/1.0 401 Unauthorized');
				echo 'Acceso no autorizado';
				exit;
			}
        }
	}

	public function getInscriptionDetail($id){
		$result = Data::fetchInscription( $id );
		if(!$result) return new stdClass();

		// remove null fields
		// return array_filter($result);
		$doc_fields = array_filter($result, function($k) {
			    return substr( $k, 0, 8 ) === "document";
			}, ARRAY_FILTER_USE_KEY);

		$documentsSysAcadIds = Data::fetchDocumentsIds();
		$documentURL = Data::fetchConfiguration('DOCUM_URL');
		$relatedFields=array_column($documentsSysAcadIds, 'related_field');
		$documents = array();
		foreach ($doc_fields as $key => $value) {
			$sysAcadKey = array_search($key, $relatedFields);
			if($sysAcadKey!==False && $value){
				$sysAcadId = $documentsSysAcadIds[$sysAcadKey];
				array_push($documents, array('id'=>$sysAcadId['id'],'descripcion'=>$sysAcadId['description'],'url'=>$documentURL.$id.'/'.$value));
			}
			unset($result[$key]);
		}

		$result['documents']=$documents;

		// check configuration to inscription in commission
		$config = Data::fetchInscriptionConfiguration();
		$materiasComisiones = array();
		//materias
		foreach( explode(",",$config[1]['value']) as $idMateria ){
			foreach( explode(",",$config[0]['value']) as $idComision ){
				array_push($materiasComisiones, array('materia'=>$idMateria,'comision'=>$idComision));
			}
		}

		$result['alum_com']=$materiasComisiones;

		return $result;
	}
}
?>