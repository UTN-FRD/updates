INSERT INTO `configuration`(`id`, `description`, `value`) VALUES ('CAPTCHA','Habilitar el uso del Captcha en el registro. Para habilitar esta opción debe enviar la url del formulario a sviera@frd.utn.edu.ar','false');

UPDATE `configuration` SET `value`='1.0.6' WHERE `id`='VERSION';
