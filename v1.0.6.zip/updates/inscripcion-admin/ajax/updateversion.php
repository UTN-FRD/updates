<?php
//upload file
$files = $_FILES['fileupload'];
$tmp_name = $files['tmp_name'];
$name = $files['name'];
$destination_dir = dirname(__FILE__) . '/../updates/';
$destination = $destination_dir . '/' . $name;
$res = move_uploaded_file($tmp_name, $destination);

echo shell_exec($destination_dir.'../update.sh');