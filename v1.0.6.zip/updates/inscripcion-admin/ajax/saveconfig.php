<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["id"]) && !empty($_POST["value"])) {
	echo Data::saveConfiguration( $_POST["id"], $_POST["value"] );
} 
?>