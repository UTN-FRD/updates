<?php
$controller = new Controller();
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Ingresantes &#8211; UTN</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.css"/>
		<!-- https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css -->
		<link rel="stylesheet" type="text/css" href="css/styles.css">
		<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.js"></script>
		<script type="text/javascript" src="js/commons.js"></script>

		<script type="text/javascript" src="js/yadcf/jquery.dataTables.yadcf.js"></script>
		<link rel="stylesheet" type="text/css" href="js/yadcf/jquery.dataTables.yadcf.css">

		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=G-5XTL7WMTB6"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'G-');
		</script>
    </head>
    <body>
		<?php include 'components/navbar-menu.php' ?>
		<div class="container">
			<br>
			<div class="row">
				<div class="col">
				<?php
					$controller -> showPage();
				?>	
				</div>
			</div>
		</div>
	</body>
</html>

