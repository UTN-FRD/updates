<?php
require_once('Modells/Data.php');

$controller = new Controller();
date_default_timezone_set('America/Argentina/Buenos_Aires');
?>
<div class="container">
	<div class="row">
		<div class="col-12">
			<h2>Acerca de Inscripciones</h2>
			<h4><span id="version" class="badge bg-info text-dark">Version <?= Data::fetchConfiguration('VERSION') ?></span></h4>
			<p>Por consultas o soporte comunicarse con sviera@frd.utn.edu.ar</p>
		</div>
	</div>
	<hr>
	<div class="row">
		<div class="col-12">
			<form method="POST" id="updateversion" class="needs-validation" novalidate autocomplete="off">
				<div class="input-group">
					<div class="custom-file">
						<input type="file" class="custom-file-input" id="updateversionzip" name="updateversionzip" required>
						<label class="custom-file-label" for="updateversionzip">Seleccionar archivo</label>
					</div>
					<div class="input-group-append">
						<button class="btn btn-outline-secondary" type="submit" id="actualizarVersionBtn">
							<span class="collapse">
								<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
								<span>Procesando...</span>
							</span>
							<span>Actualizar</span>
						</button>
					</div>
				</div>
			</form>
				<div id="msgsuccess" class="alert alert-success collapse" role="alert"></div>
				<div id="msgerror" class="alert alert-danger collapse" role="alert"></div>
		</div>
	</div>
</div>
<style>
</style>
<script>
$(document).ready(function(){
	$(".custom-file-input").on("change", function() {
		var fileName = $(this).val().split("\\").pop();
		$(this).siblings(".custom-file-label").addClass("selected").html(fileName);
		$("#msgerror").html('');
		$("#msgerror").hide();
	});
	/* Form validation */
	$('form#updateversion').submit(function(event){
		var validData = true;
        var checkValid = this.checkValidity();

		if ( checkValid === false || validData === false) {
          event.preventDefault();
          event.stopPropagation();
          $("#msgerror").html('Debe agregar el archivo de actualización');
		  $("#msgerror").show();
        }else{
          event.preventDefault();
          event.stopPropagation();
          submitform();
        }
        $(this).addClass('was-validated');        
	});
    /* Submit */
	function submitform(){
		$('#actualizarVersionBtn>span:nth-child(1)').removeClass('collapse');
        $('#actualizarVersionBtn>span:nth-child(2)').addClass('collapse');
        $('#actualizarVersionBtn').attr('disabled', true);

		var formData = new FormData();
		var file_name=$('#updateversionzip').val();
        if(file_name && file_name!=''){
            formData.append('fileupload',$('#updateversionzip')[0].files[0], file_name);
        }
		$.ajax({
			url: './ajax/updateversion.php',
			data: formData,
			processData: false,
			contentType: false,
			type: 'POST',
			success: function(msg){
                if(msg.substring(1, 5)=='rror'){
					$("#msgerror").html('Ocurrió un error en la actualización: '+msg);
					$("#msgerror").show();
                }else{
					$("#version").html(msg);
					$("#msgsuccess").html('La actualización se realizó exitosamente: '+msg);
					$("#msgsuccess").show();
                }
                $("form#inscription").removeClass("was-validated")
                $('#actualizarVersionBtn>span:nth-child(1)').addClass('collapse');
                $('#actualizarVersionBtn>span:nth-child(2)').removeClass('collapse');
				$('#actualizarVersionBtn').attr('disabled', false);
			}
		});
    }
});

</script>
