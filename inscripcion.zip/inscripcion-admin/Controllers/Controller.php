<?php
require_once('Modells/Data.php');
require_once('Modells/Redirection.php');
require_once('Modells/emailer.php');
require_once('Modells/Config.php');

class Controller {
    public function loadLayout() {
        session_start();
        if( isset($_SESSION['started']) ){
            if( strpos($_SERVER['REQUEST_URI'], 'logout') ){
                Self::logout();
            }else{
                include 'Views/layout.php';
            }
        }else{
            include 'Views/login.php';            
        }
    }

    public function showPage() {
        $action = 'unauthorized';
        if(isset($_GET['action'])){
            $action = $_GET['action'];
        }

        if($_SESSION['rol'] == 'Admin'){
            if( isset($_POST['id']) ){
                if( isset($_POST['aprobado']) ){
                    Self::acceptInscription();
                }
                if( isset($_POST['rechazado']) ){
                    Self::rejectInscription();
                }
            }
        }

        include Redirection::showPage($action);
    }

    public function login() {
        if( isset($_POST['user']) && isset( $_POST['pass'] ) ){
            $user = array( 'username' => $_POST['user'],
                            'password' => $_POST['pass'] );
            
            $respuesta = Data::checkUser($user);

            if( $respuesta ) {
                session_start();
                $_SESSION['started'] = true;
                $_SESSION['user'] = $respuesta['name'];
                $_SESSION['rol'] = $respuesta['role'];
                $_SESSION['user_id'] = $respuesta['id'];

                header("location:index.php?action=all");
            }else{
                header("location:login.php?msg=Usuario o contraseña incorrectos");
            }
        }
    }

    public function logout() {
        session_start();
        unset($_SESSION['started']);
        unset($_SESSION['user']);
        unset($_SESSION['rol']);
        unset($_SESSION['user_id']);
        header("Location: index.php");
    }

    public function registerInscription() {
        if ( isset($_POST['alumnonumerodocumento']) && isset($_POST['contactoemail']) ) {
            if(Data::hasInscription($_POST['alumnonumerodocumento'])){
                echo "<script>$('input[name=carrera]').val('".$_POST['carrera']."');inscripto()</script>";
            }else{
                $token = Data::registerInscription($_POST['alumnonumerodocumento'], $_POST['contactoemail'], $_POST['carrera']);

                if(array_key_exists('error',$token)){
                    echo "<script>$('input[name=carrera]').val('".$_POST['carrera']."');error('no se pudo guardar')</script>";
                }else{
                    Emailer::enviarURL($_POST['contactoemail'], $token['id'], $token['token']);
                    echo "<script>success('Hemos enviado un correo electrónico a ".$_POST['contactoemail']." con las indicaciones para continuar con su inscripción.')</script>";
                }
            }
        }
    }


    public function getConfigParams() {
        return Data::fetchConfigParams($_GET['id']);
    }

    public function getSavedValues(){
        $savedValues = array();
        $savedValues = Data::fetchSavedValues($_GET['id']);
        return $savedValues;
    }

    public function getInscriptionCount(){
        return Data::getInscriptionCount();
    }
    public function getInscriptionCurrentCount(){
        return Data::getInscriptionCurrentCount();
    }
    public function getInscriptionCloseCount(){
        return Data::getInscriptionCloseCount();
    }

    public function getQuestions(){
        return Data::fetchDynamicQuestions();
    }

    public function getAllQuestions(){
        return Data::fetchInscriptionQuestions();
    }

    public function getActiveQuestions(){
        return Data::fetchConfiguration('X_QUESTION');
    }

    public function changeStateInscription(){

        $reopen = false;
        if(isset($_POST['reopen']) && $_POST['reopen']=='SI'){
            $reopen=true;
        }

        $msg = isset($_POST['statemessage'])?$_POST['statemessage']:'';

        $state;
        if(isset($_POST['aprobar'])){
            $state = 'Aprobado';
            Data::saveAcceptance($_POST['id'], $msg);
        }else{
            $state = 'Rechazado';
            Data::saveRejection($_POST['id'], $msg, $reopen);
        }
        if(isset($_POST['notifychanges']) && $_POST['notifychanges']=='SI'){
            $sendTo = Data::getEmailAddressForInscription($_POST['id']);

            if($reopen && $state=='Rechazado'){
                $token = Data::resetToken($_POST['id']);
                if($token=="error"){
                    $error = "Error al generar el token para reabrir la inscripción";
                }else{
                    Emailer::sendNotificationReopen($sendTo, $_POST['id'], $token, $msg);                    
                }
            }else{
                Emailer::sendNotificationApprobed($sendTo, $msg);
            }
        }

        if( isset($error) ){
            echo "<script>alert('".$error."')</script>";
        }else{
            echo "<script>window.location='index.php'</script>";
        }
    }

    public function getDocumentsUrl(){
        // relative path to inscription project
        $documentURL = Data::fetchConfiguration('DOCUM_URL');
        if( substr($documentURL, -1)=='/' ){
			$documentURL = substr_replace($documentURL ,"",-1);
		}
        return $documentURL;
    }

    public function getConfigurations(){
        return Data::fetchConfigurations();
    }

    public function getFacultades(){
        return Data::fetchFacultades();
    }

    public function getAllCarreras(){
        return Data::fetchAllCarreras();
    }
}
?>