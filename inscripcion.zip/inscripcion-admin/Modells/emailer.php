<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once(dirname(__FILE__).'/../vendor/autoload.php');
require_once('Data.php');

class Emailer {
	static $baseurl = '';
	static $replyTo = '';
	static $marca = '';

	static $signature = '';

	public static function fetchEmailParams(){
		$config = Data::fetchEmailConfiguration();
		Self::$replyTo = $config['EMAIL_SEND'];
		Self::$marca = $config['EMAIL_SUBJ'];
		Self::$baseurl = $config['EMAIL_URL'];
		Self::$signature = $config['EMAIL_SIGN'];
	}

	public static function enviar($destinatario, $replyTo, $asunto, $mensaje, $id) {
		$idCorreo = Data::saveCorreo($destinatario, $GLOBALS['emailAdmin'], $asunto, $mensaje, $id);
		$mail = new PHPMailer(true);

		try {
			$mail->SMTPDebug = 0; //https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting#enabling-debug-output
			$mail->isSMTP();
			$mail->Timeout    = 60;
			$mail->Host       = 'smtp.gmail.com';
			$mail->SMTPAuth   = true;
			$mail->Username   = $GLOBALS['emailAdmin'];
			$mail->Password   = $GLOBALS['emailPass'];
			$mail->SMTPSecure = 'ssl';
			$mail->Port       = 465;
 
			if( !empty($replyTo) ){
				$mail->addReplyTo($replyTo);
			}
			$mail->setFrom($GLOBALS['emailAdmin'],Self::$marca);
			$mail->addAddress($destinatario);
			// Content
			$mail->isHTML(true);
			$mail->Subject = $asunto;
			$mail->Body    = '<p>' . $mensaje . '</p>';
			$mail->AltBody = $mensaje;

			if(!$mail->send()) {
				$msgerr = "Error: $mail->ErrorInfo";
				if($idCorreo!='error'){
					Data::updateCorreoResultado($idCorreo, $msgerr);
				}
				return $msgerr;
			} else {
				return 'success';
			}
		} catch (Exception $e) {
			$msgerr = "Error: $mail->ErrorInfo";
			if($idCorreo!='error'){
				Data::updateCorreoResultado($idCorreo, $msgerr);
			}
			return $msgerr;
		}
	}

	public static function sendNotificationReopen($sendTo, $id, $token, $msg){
		Emailer::fetchEmailParams();
		return Emailer::enviar($sendTo, Self::$replyTo, Self::$marca, 'Hola,<br><br>Enviamos este correo para informar que su proceso de inscripción se encuentra con errores.<br><br>'.$msg.'<br><br>Su inscripci&oacute;n fue reabierta para que pueda modificar los valores solicitados.<br><br><a href="'.Self::$baseurl.'?action=inscription&id='.$id.'&token='.$token.'" style="background-color:#49bb97;color: #FFFFFF;padding:1rem;margin:2rem;border-radius:20px;">Continuar Inscripci&oacute;n</a><br><br><br> o bien copie y pegue la siguiente url en su navegador:<br>'.Self::$baseurl.'?action=inscription&id='.$id.'&token='.$token.'<br><br>Ante cualquier inquietud, no dude en comunicarse con nosotros a través de nuestra web o respondiendo este correo electrónico.<br>'.Self::$signature, $id);
	}

	public static function sendNotificationApprobed($sendTo, $msg, $id){
		Emailer::fetchEmailParams();
		Emailer::enviar($sendTo, Self::$replyTo, Self::$marca, 'Hola,<br><br>Enviamos este correo para informar que su proceso de inscripción fue revisado y tanto la documentaci&oacute;n como los datos están correctos.<br><br>'.$msg.'<br><br>Ante cualquier inquietud, no dude en comunicarse con nosotros a través de nuestra web o respondiendo este correo electrónico.<br>'.Self::$signature, $id);
	}

	public static function enviarURL($correo, $id, $token){
		Emailer::fetchEmailParams();
		Emailer::enviar($correo, Self::$replyTo, Self::$marca, 'Hola,<br><br>Enviamos este correo para continuar con su proceso de inscripci&oacute;n.<br><br>Conserve este mensaje hasta completar la inscripci&oacute;n. En caso de no completarla, podr&aacute; reutilizar el link adjunto para acceder cuantas veces sea necesario, los valores ya ingresados ser&aacute;n guardados en la medida que los vaya cargando.<br><br><br><a href="'.Self::$baseurl.'?action=inscription&id='.$id.'&token='.$token.'" style="background-color:#49bb97;color: #FFFFFF;padding:1rem;margin:2rem;border-radius:20px;">Continuar Inscripci&oacute;n</a><br><br><br> o bien copie y pegue la siguiente url en su navegador:<br>'.Self::$baseurl.'?action=inscription&id='.$id.'&token='.$token.'<br><br>Ante cualquier inquietud, no dude en comunicarse con nosotros a trav&eacute;s de nuestra web o respondiendo este correo electr&oacute;nico.<br>'.Self::$signature,$id);
	}

	public static function enviarPassword($username, $password, $email, $role){
        Emailer::fetchEmailParams();
		$msg = 'Se creó un nuevo usuario para Ud.<br>Ingrese a '.self::$baseurl.'admin/ con el usuario: '.$username.' y el password: '.$password;
        return Emailer::enviar($email, self::$replyTo, self::$marca, $msg, 0);
    }

	public static function reenviarCorreo($id){
		Emailer::fetchEmailParams();
		$correo = Data::fetchCorreo($id);
		return Emailer::enviar($correo['para'], self::$replyTo, $correo['asunto'], $correo['cuerpo'], $correo['inscripcion_id']);
	}

}
