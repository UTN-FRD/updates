<?php
// folder to export sql files
$documents_admin_base = '/var/www/inscripcion-admin/files/';

// Database credentials
$dbname = 'inscripcionfrd';
$dbuser = 'root';
$dbpass = '';
$dbhost = 'localhost';

// Datatables MySQL connection
$sql_details = array(
    'user' => $dbuser,
    'pass' => $dbpass,
    'db'   => $dbname,
    'host' => $dbhost
);

// Emailer credentials
$emailAdmin = 'utnfrdingreso@gmail.com';
$emailPass = '1ngr3s0frd';
