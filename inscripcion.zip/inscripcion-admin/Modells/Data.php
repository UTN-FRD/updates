<?php
require_once('Connection.php');

class Data extends Connection{

    public static function checkUser($user){
        $stmt = Connection::connect()->prepare("SELECT * FROM users WHERE username = :username AND password = md5(:password) ");
        $stmt->bindParam(':username', $user['username'], PDO::PARAM_STR);
        $stmt->bindParam(':password', $user['password'], PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function fetchUserProfile($user_id){
        $stmt = Connection::connect()->prepare("SELECT username,email FROM users WHERE id = :userid");
        $stmt->bindParam(':userid', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function saveUser($username, $password, $email, $role){
        $stmt = Connection::connect()->prepare("insert into users (username,password,email,name,role) values (:username,md5(:password),:email,:name,:role)");
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':name', $username, PDO::PARAM_STR);
        $stmt->bindParam(':role', $role, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public static function updateUser($id, $username, $email, $role, $carreras, $lugarcursado){
        $stmt = Connection::connect()->prepare("update users set username=:username,email=:email,role=:role,lugarcursado=:lugarcursado,carreras=:carreras where id=:id");
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':role', $role, PDO::PARAM_STR);
        $stmt->bindParam(':lugarcursado', $lugarcursado, PDO::PARAM_STR);
        $stmt->bindParam(':carreras', $carreras, PDO::PARAM_STR);
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public static function removeUser($userid){
        $con = Connection::connect();
        $stmt = $con->prepare("delete from users where id = :userid");
        $stmt->bindParam(':userid', $userid, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public static function changeuserpassword($user_id, $oldpass, $newpass){
        $stmt = Connection::connect()->prepare("UPDATE users SET password = md5(:newpass) where id = :id and password = md5(:oldpass)");

        $stmt->bindParam(':newpass', $newpass, PDO::PARAM_STR);
        $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':oldpass', $oldpass, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public static function fetchInscriptions(){
        $stmt = Connection::connect()->prepare("SELECT `id` as id, `alumnonumerodocumento` as numero_documento, `alumnotipodocumento` as tipo_documento FROM `inscriptions`");

        $stmt->execute();
        $r = array();
        $r = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public static function fetchInscription($id){
        $stmt = Connection::connect()->prepare("SELECT `id` as id,
         `alumnoapellido` as apellidos,
         `alumnonombres` as nombres, 
         `alumnotipodocumento` as tipo_documento, 
         `alumnonumerodocumento` as numero_documento, 
         `alumnocuil` as cuil, 
         `alumnosexo` as sexo, 
         `alumnoestadocivil` as estado_civil, 
         `contactoemail` as email, 
         `contactoemailalternativo` as email_alternativo, 
         `contactotelefonofijo` as telefono, 
         `contactotelefonomovil` as celular, 
         `carrera` as carrera, 
         `lugarcursado` as sede, 
         `formaingreso` as forma_ingreso, 
         `tipocursado` as tipo_cursado, 
         `introductoriointensivo` as curso_intensivo,
         `nacfechanacimiento` as fecha_nacimiento, 
         `nacnacionalidad` as nacionalidad, 
         `nacvencdni` as vencimiento_dni, 
         `nacpais` as pais_nacimiento, 
         `nacprovincia` as provincia_nacimiento, 
         `naclocalidad` as localidad_nacimiento, 
         `nacpartidodepartamento` as partido_nacimiento, 
         `nacgruposanguineo` as grupo_sanguineo, 
         `domiciliocalle` as domicilio_calle, 
         `domicilionumero` as domicilio_numero, 
         `domiciliopiso` as domicilio_piso, 
         `domiciliolocalidad` as domicilio_localidad, 
         `domiciliopartido` as domicilio_partido, 
         `domicilioprovincia` as domicilio_provincia, 
         `domiciliocp` as domicilio_cp, 
         `discapacidad` as discapacidad, 
         `discapacidadtipo[]` as tipo_discapacidad, 
         `discapacidadtipootro` as tipo_discapacidad_otro, 
         `discapacidadmedicacion` as medicacion, 
         `discapacidadcertificado` as certificado_discapacidad, 
         `discapacidados` as obra_social, 
         `discapacidadoscual` as obra_social_desc, 
         `discapacidadbarreras[]` as barreras, 
         `discapacidadbarrerasotro` as barreras_otro, 
         `discapacidadelementos[]` as elementos, 
         `discapacidadelementosotro` as elementos_otro, 
         `secundarioegreso` as secundario_egreso, 
         `secundarioestado` as secundario_estado, 
         `secundarioanioegreso` as secundario_anio_egreso, 
         `secundariotituladoen` as secundario_titulo, 
         `secundariotecnico` as secundario_tecnico, 
         `secundarioanalitico` as secundario_analitico, 
         `secundarionombrecolegio` as secundario_colegio, 
         `secundarioprovincia` as secundario_provincia, 
         `secundariolocalidad` as secundario_localidad, 
         `secundariodependede` as secundario_depende, 
         `otrosestudiostipo` as otros_estudios, 
         `otrosestudioscarrera` as otra_carrera, 
         `otrosestudiosinstitucion` as otra_institucion, 
         `otrosestudiosmateriasaprobadas` as otra_aprobadas, 
         `otrosestudiosestado` as otra_estado, 
         `trabajotrabajas` as trabajo, 
         `trabajoenque` as ocupacion, 
         `trabajohoras` as trabajo_horas, 
         `trabajoempresa` as trabajo_empresa, 
         `trabajodireccion` as trabajo_direccion, 
         `trabajotelefono` as trabajo_telefono, 
         `deporte` as deporte, 
         `tecnotienepc` as pc, 
         `tecnodondepc` as pc_acceso, 
         `tecnocelular` as cantidad_celulares, 
         `tecnotieneinternet` as tiene_internet, 
         `tecnointernet` as acceso_internet,
         `tecnousointernet` as uso_internet, 
         `padreapellido` as padre_apellidos, 
         `padrenombre` as padre_nombres, 
         `padrefechanac` as padre_fecha_nac, 
         `padrevive` as padre_vive, 
         `padreestudios` as padre_estudios, 
         `padretrabajo` as padre_trabajo, 
         `padreobrasocial` as padre_obra_social, 
         `madreapellido` as madre_apellidos, 
         `madrenombre` as madre_nombres, 
         `madrefechanac` as madre_fecha_nac, 
         `madrevive` as madre_vive, 
         `madreestudios` as madre_estudios, 
         `madretrabajo` as madre_trabajo, 
         `madreobrasocial` as madre_obra_social, 
         `hermanoscantidad` as hermanos_cantidad, 
         `hermanosedades` as hermanos_edades, 
         `hermanosactividades` as hermanos_actividades, 
         `casatipo` as casa_tipo, 
         `casacondicion` as casa_condicion, 
         `casamediotraslado` as traslado
         FROM `inscriptions` WHERE id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $r = array();
        $r = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public static function fetchConfigParamsRelated($field, $value){

        $stmt = Connection::connect()->prepare("SELECT cp.display, cp.value, cp.field FROM config_params cp WHERE related_values like :val and related_field=:field ORDER BY cp.sort_criteria");

        $stmt->bindParam(':val', $value, PDO::PARAM_STR);
        $stmt->bindParam(':field', $field, PDO::PARAM_STR);

        $stmt->execute();

        $r = array();

        $r = $stmt->fetchAll();

        return $r;

    }

    public static function hasInscription($alumnonumerodocumento){
        $db = Connection::connect();
        $stmt = $db->prepare("SELECT count(1) from inscriptions WHERE alumnonumerodocumento=:dni and state<>'cargando' and state<>'rechazado'");

        $stmt->bindParam(':dni', $alumnonumerodocumento, PDO::PARAM_STR);

        $stmt->execute();

        return !($stmt->fetchColumn()==0);
    }

    public static function registerInscription($alumnonumerodocumento, $contactoemail, $carrera){
        $db = Connection::connect();

        $stmt = $db->prepare("INSERT INTO inscriptions (alumnonumerodocumento, contactoemail, access_token, carrera, carrera_preseteada, anioingreso, state, state_messages) VALUES (:dni, :email, md5(:token), :carrera, :carrera_preseteada, (select value from configuration where id='ANIO_INSC'), 'rechazado', concat(now(),:state_messages))");

        $state_messages = ' ['.$_SESSION['user'].'] Inscripción por excepción ';

        $token = bin2hex(random_bytes(20));

        $carrera_preseteada = isset($carrera)&&$carrera<>''?1:0;

        $stmt->bindParam(':dni', $alumnonumerodocumento, PDO::PARAM_STR);
        $stmt->bindParam(':email', $contactoemail, PDO::PARAM_STR);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->bindParam(':carrera', $carrera, PDO::PARAM_STR);
        $stmt->bindParam(':carrera_preseteada', $carrera_preseteada, PDO::PARAM_BOOL);
        $stmt->bindParam(':state_messages', $state_messages, PDO::PARAM_STR);

        if($stmt->execute()){
            return array('token' => $token, 'id' => $db->lastInsertId());
        } else {
            return array('error' => 'error');
        }

    }

    public static function closeInscription($id, $token){
        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET fecha_cierre = NOW() where id = :id and access_token = md5(:token)");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public static function fetchConfigParams($id){
        $stmt = Connection::connect()->prepare("SELECT cp.field, cp.display, cp.value FROM config_params cp WHERE related_field is NULL ORDER BY cp.sort_criteria");

        $stmt->execute();
        $r = array();
        $r = $stmt->fetchAll();

        //carreras
        $stmt = Connection::connect()->prepare("select c.value FROM configuration c WHERE c.id='OPEN_CARRE'");
        $stmt->execute();
        $carreras = $stmt->fetchColumn();
        $stmt = Connection::connect()->prepare("select 'carrera' as field, e.nombre as display, e.id as value FROM especialidades e WHERE e.id IN (".$carreras.") order by e.nombre");
        $stmt->execute();
        $r = array_merge($r, $stmt->fetchAll());

        //find related fields to check if were saved
        $stmt2 = Connection::connect()->prepare("SELECT DISTINCT cp.field FROM config_params cp WHERE related_field is not NULL");
        $stmt2->execute();

        foreach ($stmt2->fetchAll() as $row) {
            $stmt3 = Connection::connect()->prepare("SELECT cp.field, cp.display, cp.value FROM config_params cp WHERE cp.field='".$row['field']."' and cp.value = (select ".$row['field']." from inscriptions WHERE id = :id AND ".$row['field']." is not NULL)");
            $stmt3->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt3->execute();
            $r = array_merge($r, $stmt3->fetchAll());
        }

        return $r;
    }

    public static function fetchSavedValues($id){
        $stmt = Connection::connect()->prepare("SELECT * FROM inscriptions WHERE id = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function saveFieldValue($id, $user, $field, $value){
        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET `".$field."`= :val, state_messages = concat(state_messages, concat(now(), concat(:message,'\n'))) where id = :id");

        $stmt->bindParam(':val', $value, PDO::PARAM_STR);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $m = ' ['.$user.'] Modifica: '.$field.' = '.$value;
        $stmt->bindParam(':message', $m, PDO::PARAM_STR);

        if($stmt->execute()){
            return "success";
        } else {
            return "error";
        }
    }

    public static function getInscriptionCount(){
        $stmt = Connection::connect()->prepare("SELECT count(1) FROM inscriptions WHERE carrera is not null");
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    public static function getInscriptionCurrentCount(){
        $stmt = Connection::connect()->prepare("SELECT count(1) FROM current_inscriptions");
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    public static function getInscriptionCloseCount(){
        $stmt = Connection::connect()->prepare("SELECT count(1) FROM closed_inscriptions");
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    public static function getCantidadesIntroductorio(){
        $stmt = Connection::connect()->prepare("SELECT * FROM cantidades_introductorio");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getInscriptionCountByCareer(){
        $a = $_SESSION["user_id"];
        $stmt = Connection::connect()->prepare("SELECT lugarcursado, substr( replace(carreras,' ',','), 1, length(carreras)-1 ) as carreras FROM `users` WHERE role='Supervisor' and id=:id");
        $stmt->bindParam(':id', $a, PDO::PARAM_INT);
        $stmt->execute();
        $supervisor = $stmt->fetch(PDO::FETCH_ASSOC);

        $filter='';
        if($supervisor){
            $filter=" and `i`.`carrera` in (".$supervisor['carreras'].") ";
            $filter=$filter." and `i`.`lugarcursado` in (".$supervisor['lugarcursado'].") ";
            $filter=$filter." and `i`.`anioingreso` = (select `value` from `configuration` where `id`='ANIO_INSC') ";
        }

        $stmt = Connection::connect()->prepare("SELECT `i`.`carrera` AS `carrera_id`, `e`.`nombre` AS `carrera`, count(1) AS `inscripciones` FROM `inscriptions` `i` left join `config_params` `p1` on `i`.`tipocursado` = `p1`.`value` and `p1`.`field` = 'tipocursado' join `configuration` `c` on `c`.`id`='FACULTAD' join `facesp` `fe` on `c`.`value` = `fe`.`id_facultad` and `i`.`carrera` = `fe`.`id_especialidad` join `especialidades` `e` on `fe`.`id_especialidad` = `e`.`id` WHERE `i`.`fecha_cierre` is not null ".$filter." GROUP BY 1 order by 2");
            
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function fetchInscriptionQuestions(){
        $stmt = Connection::connect()->prepare("SHOW COLUMNS FROM inscriptions");

        $stmt->execute();

        return $stmt->fetchAll();
    }

    public static function fetchDynamicQuestions(){
        $stmt = Connection::connect()->prepare("SELECT DISTINCT field FROM config_params");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function fetchDynamicQuestionValues($field){
        $stmt = Connection::connect()->prepare("SELECT * FROM config_params WHERE field = :field");

        $stmt->bindParam(':field', $field, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function saveAcceptance($id, $message){

        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET state_messages = concat(state_messages, concat(now(), concat(:message,'\n'))), state = 'aprobado' where id = :id");

        $m = ' ['.$_SESSION['user'].'] Aprobado: '.$message;
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':message', $m, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public static function saveRejection($id, $message, $reopen){
        $reopenQuery="";
        if($reopen){
            $reopenQuery = ", fecha_cierre = NULL ";
        }

        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET state_messages = concat(state_messages, concat(now(), concat(:message,'\n'))), state = 'rechazado' ".$reopenQuery." where id = :id");

        $m = ' ['.$_SESSION['user'].'] Rechazado: '.$message.$reopen?' (REABIERTO)':'';
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':message', $m, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public static function getEmailAddressForInscription($id){
        $stmt = Connection::connect()->prepare("SELECT contactoemail FROM inscriptions where id = :id limit 1");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function resetToken($id){
        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET access_token=md5(:token) WHERE id=:id");

        $token = bin2hex(random_bytes(20));

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);

        if($stmt->execute()){
            return $token;
        } else {
            return "error";
        }

    }

    public static function changeFacultad($id){
        $stmt = Connection::connect()->prepare("UPDATE configuration SET value='' WHERE id IN ('SA_CARRERA','OPEN_CARRE')");
        $stmt->execute();

        $stmt = Connection::connect()->prepare("UPDATE configuration SET value=:id WHERE id ='FACULTAD'");
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        $stmt->execute();

        $stmt = Connection::connect()->prepare("SELECT * FROM facesp fe JOIN especialidades e ON fe.id_especialidad=e.id WHERE id_facultad=:id");
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll();        
    }

    public static function fetchFacultades(){
        $stmt = Connection::connect()->prepare("SELECT * FROM facultades ORDER BY nombre");

        $stmt->execute();

        return $stmt->fetchAll();        
    }

    public static function fetchCarreras(){
        $stmt = Connection::connect()->prepare("SELECT e.nombre as display FROM configuration c JOIN facesp fe ON c.value=fe.id_facultad JOIN especialidades e ON e.id=fe.id_especialidad WHERE c.id='FACULTAD'");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_COLUMN);        
    }
    
    public static function fetchCarrerasFor($userId){
        $stmt = Connection::connect()->prepare("SELECT substr( replace(carreras,' ',','), 1, length(carreras)-1 ) FROM users WHERE id=:id");
        $stmt->bindParam(':id', $userId, PDO::PARAM_STR);
        $stmt->execute();

        $carreras = $stmt->fetchColumn();
        $stmt = Connection::connect()->prepare("SELECT e.nombre as display FROM especialidades e WHERE e.id in (".$carreras.")");
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_COLUMN);        
    }
    
    public static function updateCarrera($id, $nombre, $sedes, $ingresos){
        $db = Connection::connect();
        $stmt = $db->prepare("UPDATE especialidades SET nombre=:nombre WHERE id=:id");
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->execute();

        //elimino lugarcursado y formaingreso para ese ID
        $stmt = $db->prepare("update config_params set related_values = REPLACE(related_values,'".$id."','') where field in ('formaingreso','lugarcursado') and REGEXP_INSTR(related_values, '^".$id." | ".$id." | ".$id."$|^".$id."$')");
        $stmt->execute();

        //agrego lugarcursado y formaingreso para ese ID
        foreach (explode(",",$sedes) as $sede){
            $stmt = $db->prepare("update config_params set related_values = if(REGEXP_INSTR(related_values, '^".$id." | ".$id." | ".$id."$|^".$id."$'),related_values,concat(related_values,' ".$id."')) where field = 'lugarcursado' AND value = :sede");
            $stmt->bindParam(':sede', $sede, PDO::PARAM_INT);    
            $stmt->execute();    
        }
        
        foreach (explode(",",$ingresos) as $ingreso){
            $stmt = $db->prepare("update config_params set related_values = if(REGEXP_INSTR(related_values, '^".$id." | ".$id." | ".$id."$|^".$id."$'),related_values,concat(related_values,' ".$id."')) where field = 'formaingreso' AND value = :formaingreso");
            $stmt->bindParam(':formaingreso', $ingreso, PDO::PARAM_STR);    
            $stmt->execute();    
        }
        
    }
    
    public static function addCarrera($id, $nombre, $sedes, $ingresos){
        $db = Connection::connect();
        // verifico si está la especialidad
        $stmt = $db->prepare("SELECT count(1) from especialidades WHERE id=:id");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        if($stmt->fetchColumn()==0){
            // no está la especialidad, la genero
            $stmt = $db->prepare("INSERT INTO especialidades VALUES (:id, :nombre)");
        }else{
            // está la especialidad, la actualizo
            $stmt = $db->prepare("UPDATE especialidades SET nombre=:nombre WHERE id=:id");
        }
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);    
        $stmt->execute();

        //agrego la relación
        $stmt = $db->prepare("insert into `facesp` values ((select `value` from `configuration` WHERE `id`='FACULTAD'),:id)");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        //elimino lugarcursado y formaingreso para ese ID
        $stmt = $db->prepare("update config_params set related_values = REPLACE(related_values,'".$id."','') where field in ('formaingreso','lugarcursado') and REGEXP_INSTR(related_values, '^".$id." | ".$id." | ".$id."$|^".$id."$')");
        $stmt->execute();

        //agrego lugarcursado y formaingreso para ese ID
        foreach (explode(",",$sedes) as $sede){
            $stmt = $db->prepare("update config_params set related_values = if(REGEXP_INSTR(related_values, '^".$id." | ".$id." | ".$id."$|^".$id."$'),related_values,concat(related_values,' ".$id."')) where field = 'lugarcursado' AND value = :sede");
            $stmt->bindParam(':sede', $sede, PDO::PARAM_INT);    
            $stmt->execute();    
        }
        
        foreach (explode(",",$ingresos) as $ingreso){
            $stmt = $db->prepare("update config_params set related_values = if(REGEXP_INSTR(related_values, '^".$id." | ".$id." | ".$id."$|^".$id."$'),related_values,concat(related_values,' ".$id."')) where field = 'formaingreso' AND value = :formaingreso");
            $stmt->bindParam(':formaingreso', $ingreso, PDO::PARAM_INT);    
            $stmt->execute();    
        }

    }
    
    public static function delCarrera($id){
        $stmt = Connection::connect()->prepare("delete from especialidades where id=:id");
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        $stmt->execute();
    }
    
    public static function fetchAllCarreras(){
        $stmt = Connection::connect()->prepare("SELECT e.id as value, e.nombre as display FROM configuration c JOIN facesp fe ON c.value=fe.id_facultad JOIN especialidades e ON e.id=fe.id_especialidad WHERE c.id='FACULTAD'");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);        
    }

    public static function fetchActiveCarreras(){
        //carreras
        $stmt = Connection::connect()->prepare("select c.value FROM configuration c WHERE c.id='OPEN_CARRE'");
        $stmt->execute();
        $carreras = $stmt->fetchColumn();
        $stmt = Connection::connect()->prepare("select 'carrera' as field, e.nombre as display, e.id as value FROM especialidades e WHERE e.id IN (".$carreras.") order by e.nombre");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function fetchCarreraDetail($id){
        $stmt = Connection::connect()->prepare("SELECT e.id as value, e.nombre as display, cp.field as campo, cp.display as campovalor, cp.value as campoid FROM configuration c JOIN facesp fe ON c.value=fe.id_facultad JOIN especialidades e ON e.id=fe.id_especialidad JOIN config_params cp ON cp.related_values rlike CONCAT('^',e.id,' | ',e.id,' | ',e.id,'$|^',e.id,'$') WHERE c.id='FACULTAD' and e.id=:id");
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);        
    }

    public static function fetchUsuarioDetail($id){
        $stmt = Connection::connect()->prepare("SELECT * FROM users where id=:id");
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);        
    }

    public static function fetchSedes(){
        $stmt = Connection::connect()->prepare("SELECT display FROM config_params WHERE field = 'lugarcursado'");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public static function fetchSedesFor( $userId ){
        $stmt = Connection::connect()->prepare("select display from config_params cp JOIN users u ON cp.field='lugarcursado' and cp.value=u.lugarcursado WHERE u.id=:id");
        $stmt->bindParam(':id', $userId, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchEstados(){
        $stmt = Connection::connect()->prepare("SELECT DISTINCT state FROM inscriptions");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_COLUMN);
        
    }

    public static function fetchAniosIngreso(){
        $stmt = Connection::connect()->prepare("SELECT DISTINCT anioingreso FROM inscriptions");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public static function fetchDataToCampus($filename){
        $stmt = Connection::connect()->prepare("select * from (SELECT 'Username', 'Password', 'Firstname', 'Lastname', 'Email' union all (SELECT concat('2022',lpad(id,4,0)) as `Username`, '' as `Password`, alumnonombres as `Firstname`, alumnoapellido as `Lastname`, contactoemail as `Email` FROM inscriptions where fecha_cierre is not null and carrera in (5,7,17,27) )) resulting_set INTO 
              OUTFILE '".$filename."'
              CHARACTER SET latin1
              FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"'
              LINES TERMINATED BY '\n';");
        $stmt->execute();
    }
    // select * from (SELECT 'Username', 'Password', 'Firstname', 'Lastname', 'Email' union all (SELECT concat('2022',lpad(id,4,0)) as `Username`, '' as `Password`, alumnonombres as `Firstname`, alumnoapellido as `Lastname`, contactoemail as `Email` FROM inscriptions where fecha_cierre is not null and carrera in (5,7,17,27) )) resulting_set INTO OUTFILE '/var/www/inscripcion-admin/files/export-campus.csv' CHARACTER SET latin1 FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\n';

    public static function fetchDataToCSV($periodos, $carreras, $detalle, $comision, $sede, $userId, $discapacidad){
        $stmt = Connection::connect()->prepare("SELECT lugarcursado, substr( replace(carreras,' ',','), 1, length(carreras)-1 ) as carreras FROM `users` WHERE role='Supervisor' and id=:id");
        $stmt->bindParam(':id', $userId, PDO::PARAM_STR);
        $stmt->execute();
        $supervisor = $stmt->fetch(PDO::FETCH_ASSOC);

        $wherefilter='';
        if($supervisor){
            $wherefilter=" and `i`.`lugarcursado` in (".$supervisor['lugarcursado'].") ";
            $wherefilter=$wherefilter." and `i`.`anioingreso` = (select `value` from `configuration` where `id`='ANIO_INSC') ";
        }

        $filter='';
        if($detalle){
            $filter=", e.nombre as Carrera";
        }
        if($comision){
            $filter=$filter.", (SELECT cp2.display FROM `config_params` cp2 WHERE cp2.field='tipocursado' and cp2.value=i.tipocursado) as Comision";
        }
        if($sede){
            $filter=$filter.", (SELECT cp2.display FROM `config_params` cp2 WHERE cp2.field='lugarcursado' and cp2.value=i.lugarcursado) as Sede";
        }
        if($discapacidad){
            $filter=", `discapacidad` as Discapacidad, `discapacidadtipo[]` as Tipo, `discapacidadtipootro` as TipoOtro, `discapacidadmedicacion` as Medicacion, `discapacidadcertificado` as CertificadoDiscapacidad, `discapacidados` as ObraSocial, `discapacidadoscual` as NombreObraSocial, `discapacidadbarreras[]` as BarrerasQueEnfrenta, `discapacidadbarrerasotro` as OtrasBarreras, `discapacidadelementos[]` as Elementos, `discapacidadelementosotro` as OtrosElementos ";
        }


        $stmt = Connection::connect()->prepare("SELECT if(legajo_sysacad is null or legajo_sysacad='', concat('2022',lpad(i.id,4,0)), concat('23-',legajo_sysacad)) as `Username`, '' as `Password`, alumnonombres as `Firstname`, alumnoapellido as `Lastname`, contactoemail as `Email`".$filter." FROM inscriptions i JOIN especialidades e on i.carrera=e.id WHERE i.fecha_cierre is not null and i.anioingreso in (".$periodos.") and i.carrera in (".$carreras.") ".$wherefilter.";");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function fetchEmailConfiguration(){
        $stmt = Connection::connect()->prepare("SELECT id,value FROM configuration WHERE id like 'EMAIL_%'");

        $stmt->execute();

        $result = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $result[$row['id']] = $row['value'];
        }
        return $result;
    }

    public static function fetchConfigurations(){
        $stmt = Connection::connect()->prepare("SELECT * FROM configuration WHERE id not like 'X_%'");

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function fetchConfiguration($id){
        $stmt = Connection::connect()->prepare("SELECT value FROM configuration where id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        
        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function saveConfiguration($id, $value){
        $stmt = Connection::connect()->prepare("UPDATE configuration SET value = :value where id = :id");

        $stmt->bindParam(':value', $value, PDO::PARAM_STR);
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public static function fetchInscriptionDocuments(){
        $stmt = Connection::connect()->prepare("SELECT `id`, `documentacionanalitico`, `documentacioncuil`, `documentacioncv`, `documentaciondni`, `documentaciondniback`, `documentacionnacimiento`, `documentaciontitulogrado` FROM `inscriptions`");

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function updateInscriptionField($id, $field, $val){
        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET ".$field." = :documentName where id = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':documentName', $val, PDO::PARAM_STR);

        return $stmt->execute();

    }

    public static function fetchAPIInscriptionsAmount(){
        $db = Connection::connect();
        $stmt = $db->prepare("SELECT value FROM `configuration` WHERE id='SA_CARRERA'");
        $stmt->execute();
        $carreras = $stmt->fetchColumn();
        if($carreras && !empty(trim($carreras))){
            $carreras=' carrera in ('.$carreras.') and ';
        }

        $stmt = $db->prepare("SELECT value FROM `configuration` WHERE id='I_SEDE'");
        $stmt->execute();
        $sedes = $stmt->fetchColumn();
        if($sedes && !empty(trim($sedes))){
            $sedes=' lugarcursado in ('.$sedes.') and ';
        }

        $stmt = $db->prepare("SELECT count(1) as cant FROM `inscriptions`, (SELECT value FROM `configuration` WHERE id='SA_STATE') ss where ".$carreras.$sedes." state=ss.value and (legajo_sysacad is null or legajo_sysacad = '')");

        $stmt->execute();
        $r = array();
        $r = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $r;
    }

    public static function inscriptionsToDel($to){
        $stmt = Connection::connect()->prepare("SELECT count(1) as cant FROM `inscriptions` where state='cargando' and fecha_inicio < :to");
        $stmt->bindParam(':to', $to, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function deleteInscriptionsUntil($to){
        $stmt = Connection::connect()->prepare("delete FROM `inscriptions` where state='cargando' and fecha_inicio < :to");
        $stmt->bindParam(':to', $to, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->rowCount();
    }

}
?>