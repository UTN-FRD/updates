<?php
class Util
{
    private static $numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
    private static $letters = ['U', 'v', 'f', 'T', 'm', 'Q', 'P', 'x', 'b', 'N'];

    public static function encode($str)
    {
        return str_replace(self::$numbers, self::$letters, $str);
    }

    public static function decode($str)
    {
        return str_replace(self::$letters, self::$numbers, $str);
    }

    public static function randomPassword() 
    {
        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
        $pass = array(); 
        $alphaLength = strlen($alphabet) - 1; 
        for ($i = 0; $i < 8; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); 
    }
}
