<?php
require_once '../Modells/Util.php';
require_once '../Modells/Data.php';
require_once '../Modells/emailer.php';

$password = Util::randomPassword();
//save data
echo Data::removeUser($_POST['userid']);

