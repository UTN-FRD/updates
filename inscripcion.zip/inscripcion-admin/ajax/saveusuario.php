<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["mode"]) && !empty($_POST["nombre"])) {
	if($_POST["mode"]=='edit'){
		echo Data::updateUser($_POST["id"],$_POST["nombre"],$_POST["correo"],$_POST["rol"],$_POST["carreras"],$_POST["lugarcursado"]);
	}
} 
?>