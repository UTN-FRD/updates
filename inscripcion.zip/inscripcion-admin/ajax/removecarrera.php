<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["id"])) {
	echo Data::delCarrera( $_POST["id"] );
} 
?>