<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["user_id"])) {
	echo json_encode( Data::fetchUserProfile( $_POST["user_id"] ) );
} 
?>