<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["action"])) {
    if( $_POST["action"]=='count' ){
        echo Data::inscriptionsToDel($_POST["to"]);
    }else if( $_POST["action"]=='del' ){
        echo Data::deleteInscriptionsUntil($_POST["to"]);
    }
} 
?>