<?php 
require_once('../Modells/Data.php');
require_once('../Modells/Config.php');

/*
$file = basename('export-campus.csv');
$path = $GLOBALS['documents_admin_base']; 
if($_GET['generate']=='1'){
	if(file_exists($path.$file)){ // file does exist
		unlink($path.$file);
	}
	Data::fetchDataToCampus($path.$file);
}

if(!file_exists($path.$file)){ // file does not exist
    die('El archivo no existe: '.$path.$file);
} else {
    header("Cache-Control: public");
    header("Content-Description: File Transfer");
    header("Content-Disposition: attachment; filename=$file");
    header("Content-Type: text/csv");
    header("Content-Transfer-Encoding: binary");

    readfile($path.$file);
}
*/

foreach($_GET['carreras'] as $item){
  // query to delete where item = $item
}

$incluyeCarrera=false;
if( isset($_GET['incluyecarrera']) ){
    $incluyeCarrera=true;
}
$incluyeComision=false;
if( isset($_GET['incluyecomision']) ){
    $incluyeComision=true;
}
$incluyeSede=false;
if( isset($_GET['incluyesede']) ){
    $incluyeSede=true;
}

$incluyeDisc=false;
if( isset($_GET['incluyedisc']) ){
    $incluyeDisc=true;
}

$rows = Data::fetchDataToCSV( implode(',',$_GET['periodos']), implode(',',$_GET['carreras']), $incluyeCarrera, $incluyeComision, $incluyeSede, $_GET['user_id'], $incluyeDisc );
//Get the column names.

$columnNames = array();
if(!empty($rows)){
    //We only need to loop through the first row of our result
    //in order to collate the column names.
    $firstRow = $rows[0];
    foreach($firstRow as $colName => $val){
        $columnNames[] = $colName;
    }
}

//Setup the filename that our CSV will have when it is downloaded.
$fileName = 'inscripciones.csv';

//Set the Content-Type and Content-Disposition headers to force the download.
// header('Content-Type: application/excel');
//header('Content-Disposition: attachment; filename="' . $fileName . '"');

header("Cache-Control: public");
header("Content-Description: File Transfer");
header('Content-Disposition: attachment; filename="' . $fileName . '"');
header("Content-Type: text/csv");
header("Content-Transfer-Encoding: binary");


//Open up a file pointer
$fp = fopen('php://output', 'w');
fprintf($fp, chr(0xEF).chr(0xBB).chr(0xBF));

//Start off by writing the column names to the file.
fputcsv($fp, $columnNames);

//Then, loop through the rows and write them to the CSV file.
foreach ($rows as $row) {
    fputcsv($fp, $row);
}

//Close the file pointer.
fclose($fp);

?>