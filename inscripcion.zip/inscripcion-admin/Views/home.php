<p>Las inscripciones Vigentes son aquellas que aún no fueron cerradas y se iniciaron en los últimos 3 días.</p>

<table id="example" class="display" style="width:100%">
    <thead>
        <tr>
            <th>Apellido</th>
            <th>Nombre</th>
            <th>Nro Documento</th>
            <th>Carrera</th>
            <th>Sede</th>
            <th>Estado</th>
            <th>Fecha Inicio</th>
            <th></th>
        </tr>
    </thead>
</table>

<script>


$(document).ready(function() {
    var table = $('#example').DataTable( {
        'processing': true,
        'serverSide': true,
        'ajax': './ajax/dt_home.php',
        'columnDefs': [ {
            'targets': -1,
            'data': null,
            'defaultContent': '<button class="btn btn-success">Ver detalle</button>'
        } ]
    } );

    $('#example tbody').on( 'click', 'button', function () {
        var data = table.row( $(this).parents('tr') ).data();
        window.location = 'index.php?action=inscription-form&id='+data[ 7 ]; 
    } );
} );
</script>