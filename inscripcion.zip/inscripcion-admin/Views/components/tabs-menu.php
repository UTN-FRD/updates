<ul class="nav nav-tabs" style="width:100%">
    <?php
        $activeMenu = 'all';
        if(isset($_GET['action'])){
            $activeMenu = $_GET['action'];
        }
        if($_SESSION['rol'] == 'Admin'){
    ?>
    <li class="nav-item">
        <a class="nav-link collapse <?= $activeMenu=='home'?'active':'' ?>" href="index.php?action=home">En curso <span class="badge badge-pill badge-info"><?=$controller->getInscriptionCurrentCount()?></span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapse <?= $activeMenu=='closed'?'active':'' ?>" href="index.php?action=closed">Pendientes <span class="badge badge-pill badge-info"><?=$controller->getInscriptionCloseCount()?></span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeMenu=='all'?'active':'' ?>" href="index.php?action=all">Inscripciones <span class="badge badge-pill badge-info"><?=$controller->getInscriptionCount()?></span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeMenu=='exported'?'active':'' ?>" href="index.php?action=exported">Exportados</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeMenu=='sysacad'?'active':'' ?>" href="index.php?action=sysacad">SysAcad</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeMenu=='inscexc'?'active':'' ?>" href="index.php?action=inscexc">Excepción</a>
    </li>
    <li class="nav-item ">
        <a class="nav-link <?= $activeMenu=='conf'?'active':'' ?>" href="index.php?action=conf">Configuraci&oacute;n</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeMenu=='questions'?'active':'' ?>" href="index.php?action=questions">Preguntas</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $activeMenu=='usuarios'?'active':'' ?>" href="index.php?action=usuarios">Usuarios</a>
    </li>
<?php
    }
?>
    <li class="nav-item">
        <a class="nav-link <?= $activeMenu=='export'?'active':'' ?>" href="index.php?action=export">Exportar</a>
    </li>
</ul>
