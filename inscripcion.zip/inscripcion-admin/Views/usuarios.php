<table id="example" class="display" >
    <thead>
        <tr>
            <th>Nombre de Usuario</th>
            <th>Correo Electrónico</th>
            <th>Rol</th>
            <th></th>
        </tr>
    </thead>
</table>
<hr>
<div class="row">

    <div class="col-12">
        <h3>Agregar Usuario</h3>
    </div>
    <div class="col-12">
        <div class="row">
            <div class="form-group col-4">
                <label for="username">Nombre de usuario</label>
                <input type="text" class="form-control" id="username" name="username">
            </div>
            <div class="form-group col-4">
                <label for="email">Correo Electrónico</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="form-group col-2">
                <label for="role">Rol</label>
                <select class="form-control" id="role" name="role" >
                    <option value="Consumidor">Consumidor</option>
                    <option value="Supervisor">Supervisor</option>
                    <option value="Admin">Administrador</option>
                </select>
            </div>
            <div class="form-group col-2">
                <br>
                <button id="adduser" class="btn btn-success">Agregar</button>
            </div>
        </div>
        <div class="row">
        <p>Detalle de los roles disponibles:</p>
        <ul>
            <li><b>Administrador:</b> Acceso total al sistema, puede ver todas las inscripciones, configuraciones y crear usuarios</li>
            <li><b>Supervisor:</b> Acceso a las inscripciones para gestionar los estados</li>
            <li><b>Consumidor:</b> Acceso a los reportes para descarga de datos de inscripciones en CSV</li>
        </ul>
        </div>
    </div>
</div>
<script>

var table;
$('#adduser').click(function(){
    $(this).prop('disabled', true);
    $.ajax({
        type: 'POST',
		url: './ajax/adduser.php',
		data:'username='+$('#username').val()+'&email='+$('#email').val()+'&role='+$('#role').val(),
		success: function(data){
            if(data.startsWith("[")){
                table.row.add(data).draw(false);
                $('#username').val('');
                $('#email').val('');
                $('#role').val('');
            }else{
                alert(data);
            }
            $('#adduser').prop('disabled', false);
        }
    });
});


$(document).ready(function() {
    table = $('#example').DataTable( {
        'processing': true,
        'serverSide': true,
        'search': { 'regex': true },
        'ajax': './ajax/dt_users.php',
        'columnDefs': [ 
            {
                'targets': -1,
                'data': null,
                'defaultContent': '<button class="btn btn-danger">Eliminar</button>'
            }
        ]
    } );

    yadcf.init(table, [
        {column_number : 2, data:['admin','eval'], column_data_type: "html", html_data_type: "text", filter_default_label: "Todos"}
        ]);

    $('#example tbody').on( 'click', 'button', function () {
        $(this).attr('disabled', true);
        var parent = $(this).parents('tr');
        var data = table.row( parent ).data();
        $.ajax({
            type: 'POST',
            url: './ajax/removeuser.php',
            data:'userid='+data[ 3 ],
            success: function(data){
                table.row(parent).remove().draw();
                if( data != true ){
                    alert(data);
                }
            }
        });
    } );

} );
</script>
<style>
</style>
