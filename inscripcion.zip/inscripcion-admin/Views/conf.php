<?php
require_once('Controllers/Controller.php');

$controller = new Controller();
$config = $controller->getConfigurations();

?>
<div class="row">
<div class="col-md-2" style="display:none">
	<ul class="nav flex-column">
		<li class="nav-item">
			<a class="nav-link active" aria-current="page" href="#">Active</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Link</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="#">Link</a>
		</li>
		<li class="nav-item">
			<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
		</li>
	</ul>
</div>
<div class="col">
<h2>Inscripci&oacute;n</h2>
<div class="row">
	<div class="col">
		<!-- FORM_OPEN -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
			return $v['id'] == "FORM_OPEN";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="custom-control custom-switch">
			<input type="checkbox" class="custom-control-input" id="formopen" <?= $row['value']=='true'?"checked":"" ?>>
			<label class="custom-control-label" for="formopen">Inscripciones Abiertas</label>
			<small class="form-text text-muted"><?= $row['description'] ?></small>
		</div>
		<script>
			$("#formopen").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=FORM_OPEN&value='+$(this).prop('checked'),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
	<div class="col">
		<!-- ANIO_INSC -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "ANIO_INSC";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="ANIO_INSC">A&ntilde;o de inscripción:</label>
		    <input type="text" id="ANIO_INSC" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#ANIO_INSC").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=ANIO_INSC&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
	<div class="col">
		<!-- CAPTCHA -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
			return $v['id'] == "CAPTCHA";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="custom-control custom-switch">
		<input type="checkbox" class="custom-control-input" id="captcha" <?= $row['value']=='true'?"checked":"" ?>>
		<label class="custom-control-label" for="captcha">Usar Captcha</label>
		<small class="form-text text-muted"><?= $row['description'] ?></small>
		</div>
		<script>
			$("#captcha").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=CAPTCHA&value='+$(this).prop('checked'),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
</div>
<br>
<div class="row">
	<div class="col">
		<!-- FORM_ADMIN -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "FORM_ADMIN";
		}, ARRAY_FILTER_USE_BOTH))[0];
		$useCode = $row['value'];
		?>
		<div class="custom-control custom-switch">
		  <input type="checkbox" class="custom-control-input" id="formadmin" <?= $row['value']=='true'?"checked":"" ?>>
		  <label class="custom-control-label" for="formadmin">Código de Admisión</label>
		  <small class="form-text text-muted"><?= $row['description'] ?></small>
		</div>
		<script>
			$("#formadmin").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=FORM_ADMIN&value='+$(this).prop('checked'),
					success: function(data){
						$("#FORM_CODE").prop("disabled",!$("#formadmin").prop('checked'));
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
	<div class="col">
		<!-- FORM_CODE -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "FORM_CODE";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="FORM_CODE">Codigo usado para admisión</label>
			<select id="FORM_CODE" class="custom-select" <?= $useCode=='true'?"":"disabled" ?>>
			  <option value="ID" <?= $row['value']=='ID'?"selected":"" ?>>ID de la carrera</option>
			  <option value="2021" <?= $row['value']=='2021'?"selected":"" ?>>2021</option>
			</select>
		    <small class="form-text text-muted"><?= $row['description'] ?></small>
		</div>
		<script>
			$("#FORM_CODE").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=FORM_CODE&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
</div>
<hr>
<h2>Carreras</h2>
<div class="row">
	<div class="col">
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "FACULTAD";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<select id="facultades" class="custom-select">
			<option value="-1" <?= $row['value']==""?"selected":"" ?>>--Seleccione--</option>

		<?php
		foreach($controller->getFacultades() as $fac){
		?>
			<option value="<?= $fac['id'] ?>" <?= $fac['id']==$row['value']?"selected":"" ?>><?= $fac['nombre']?></option>
		<?php	
		}
		?>
		</select>
		<script>
			var previous;
			$("#facultades").focus(function(){
				previous = this.value;
			}).change(function(){
				if(confirm("Al cambiar de Facultad se perderá la selección de carreras actual. Seguro que desea continuar?")){
					$.ajax({
						type: 'POST',
						url: './ajax/changefacultad.php',
						data:'id='+this.value,
						success: function(res){
							$("#list-carreras").html("");
							data = JSON.parse(res);
							for(d in data){
								$("#list-carreras").append('<tr id="carrera'+data[d].id+'"><td>'+data[d].id+' - '+data[d].nombre+'</td><td><input type="checkbox" name="OPEN_CARRE" value="'+data[d].id+'" ></td><td><input type="checkbox" name="SA_CARRERA" value="'+data[d].id+'" ></td><td><button class="btn btn-info carrera" onclick="editCarrera('+data[d].id+', \''+data[d].nombre+'\')">Editar</button></td></tr>');
							}
							$("input[name='SA_CARRERA']").change(function(){saveChangeCarrera('SA_CARRERA')});
							$("input[name='OPEN_CARRE']").change(function(){saveChangeCarrera('OPEN_CARRE')});
						}
					});
				}else{
					this.value = previous;
				}
			});
		</script>

		<!-- SA_CARRERA -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "SA_CARRERA";
		}, ARRAY_FILTER_USE_BOTH))[0];
		$opencarre = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "OPEN_CARRE";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<table class="table">
			<thead>
				<tr>
					<th>Carrera</th>
					<th>Inscripción Abierta</th>
					<th>Enviar al SysAcad</th>
				</tr>
			</thead>
			<tbody id="list-carreras">
			<?php
			$carrerasSeleccionadas = explode(',',$row['value']);
			$carrerasAbiertas = explode(',',$opencarre['value']);
			foreach ($controller->getAllCarreras() as $carr) {
			?>
			<tr id="carrera<?= $carr['value'] ?>">
				<td><?= $carr['value'] ?> - <?= $carr['display'] ?></td>
				<td><input type="checkbox" name="OPEN_CARRE" value="<?= $carr['value'] ?>" id="<?= $carr['value'] ?>" <?= in_array($carr['value'],$carrerasAbiertas)?"checked":"" ?>></td>
				<td><input type="checkbox" name="SA_CARRERA" value="<?= $carr['value'] ?>" id="<?= $carr['value'] ?>" <?= in_array($carr['value'],$carrerasSeleccionadas)?"checked":"" ?>></td>
				<td><button class="btn btn-info carrera" onclick="editCarrera(<?= $carr['value'] ?>,'<?= $carr['display'] ?>')">Editar</button></td>
			</tr>
			<?php
			}
			?>
			</tbody>
		</table>
		<div class="d-flex justify-content-center">
			<button class="btn btn-success" onclick="newCarrera()">Nueva Carrera</button>
		</div>
		<style>
		td:nth-child(2),td:nth-child(3){text-align:center;vertical-align:middle}
		</style>

		<!-- Modal -->
		<div class="modal fade" id="carreraModal" tabindex="-1" role="dialog" aria-labelledby="carreraModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="carreraModalLabel">Editar Carrera</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<input type="hidden" id="carreramodemodal" name="carreramodemodal">
					<div class="form-group">
						<label for="carreraidmodal">ID</label>
						<input type="text" id="carreraidmodal" class="form-control" name="carreraidmodal">
						<small class="form-text text-muted">Debe ser el mismo ID que tiene el SysAcad</small>
					</div>
					<div class="form-group">
						<label for="carreranombremodal">Nombre</label>
						<input type="text" id="carreranombremodal" class="form-control" name="carreranombremodal">
					</div>
					<div class="row">
						<div class="col">
							<div class="form-group" id="lugarcursado">
								<label><b>Sedes</b></label>
								<?php
								foreach ($controller->getLugaresCursado() as $lc) {
								?>
								<div class="custom-control custom-switch">
									<input type="checkbox" class="custom-control-input" name="<?= $lc['value'] ?>" id="<?= $lc['value'] ?>">
									<label class="custom-control-label" for="<?= $lc['value'] ?>"><?= $lc['display'] ?></label>
								</div>
								<?php
								}
								?>
							</div>
						</div>
						<div class="col">
							<div class="form-group" id="formaingreso">
								<label><b>Forma de Ingreso</b></label>
								<?php
								foreach ($controller->getFormasIngreso() as $fi) {
								?>
								<div class="custom-control custom-switch">
									<input type="checkbox" class="custom-control-input" name="<?= $fi['value'] ?>" id="<?= $fi['value'] ?>">
									<label class="custom-control-label" for="<?= $fi['value'] ?>"><?= $fi['display'] ?></label>
								</div>
								<?php
								}
								?>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger mr-auto" id="btndelcarreramodal">Eliminar</button>
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
					<button type="button" class="btn btn-primary" id="btnsavecarreramodal">Guardar</button>
				</div>
				</div>
			</div>
		</div>
		<script>
			function editCarrera(id,nombre){
				$("#carreraModal input[type=checkbox]").prop('checked', false);
				$.ajax({
					type: 'POST',
					url: './ajax/getCarreraDetail.php',
					data:'id='+id,
					dataType: 'json',
					success: function(data){
						for(i in data){
							$("#"+data[i].campo+" input[name="+data[i].campoid+"]").prop('checked', true);
						}
						$("input[name=carreramodemodal]").val( "edit" );
						$("input[name=carreraidmodal]").val( id );
						$("input[name=carreraidmodal]").prop( "readonly", true );
						$("input[name=carreranombremodal]").val( nombre );
						$("#btndelcarreramodal").show();
						$('#carreraModal').modal('show');
					}
				});
			}
			function newCarrera(){
				$("input[name=carreramodemodal]").val( "new" );
				$("input[name=carreraidmodal]").prop( "readonly", false );
				$("input[name=carreraidmodal]").val( "" );
				$("input[name=carreranombremodal]").val( "" );
				$("#btndelcarreramodal").hide();
				$('#carreraModal').modal('show');
			}
			function saveChangeCarrera(nameElem){
				var favorite = [];
	            $.each($("input[name='"+nameElem+"']:checked"), function(){
	                favorite.push($(this).val());
	            });
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id='+nameElem+'&value='+favorite.join(","),
					success: function(data){
					}
				});
			}
			$("input[name='SA_CARRERA']").change(function(){saveChangeCarrera('SA_CARRERA')});
			$("input[name='OPEN_CARRE']").change(function(){saveChangeCarrera('OPEN_CARRE')});
			$("#btnsavecarreramodal").click(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/savecarrera.php',
					data:'mode='+$("#carreramodemodal").val()+'&id='+$("#carreraidmodal").val()+'&nombre='+$("#carreranombremodal").val(),
					success: function(data){
						if($("#carreramodemodal").val()=='edit'){
							$("#carrera"+$("#carreraidmodal").val()+">td:first-child").text($("#carreraidmodal").val()+' - '+$("#carreranombremodal").val());
						}else{
							$("#list-carreras").append('<tr id="carrera'+$("#carreraidmodal").val()+'"><td>'+$("#carreraidmodal").val()+' - '+$("#carreranombremodal").val()+'</td><td><input type="checkbox" name="OPEN_CARRE" value="'+$("#carreraidmodal").val()+'" ></td><td><input type="checkbox" name="SA_CARRERA" value="'+$("#carreraidmodal").val()+'" ></td><td><button class="btn btn-info carrera" onclick="editCarrera('+$("#carreraidmodal").val()+', \''+$("#carreranombremodal").val()+'\')">Editar</button></td></tr>');
						}
						$('#carreraModal').modal('hide');
					}
				});
			});
			$("#btndelcarreramodal").click(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/removecarrera.php',
					data:'id='+$("#carreraidmodal").val(),
					success: function(data){
						$("#carrera"+$("#carreraidmodal").val()).remove();
						$('#carreraModal').modal('hide');
					}
				});
			});
		</script>

	</div>
</div>
<hr>
<h2>Correos Electrónicos</h2>
<div class="row">
	<div class="col">
		<!-- EMAIL_SEND -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_SEND";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_SEND"><?= $row['id'] ?></label>
		    <input type="text" id="EMAIL_SEND" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_SEND").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_SEND&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>		
	</div>
	<div class="col">
		<!-- EMAIL_SUBJ -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_SUBJ";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_SUBJ"><?= $row['id'] ?></label>
		    <input type="text" id="EMAIL_SUBJ" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_SUBJ").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_SUBJ&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>		
	</div>	
</div>
<div class="row">
	<div class="col">
		<!-- EMAIL_URL -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_URL";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_URL"><?= $row['id'] ?></label>
		    <input type="text" id="EMAIL_URL" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_URL").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_URL&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
	<div class="col">
		<!-- EMAIL_SIGN -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_SIGN";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_SIGN"><?= $row['id'] ?></label>
		    <input type="text" id="EMAIL_SIGN" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_SIGN").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_SIGN&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>		
	</div>	
</div>
<div class="row">
	<div class="col">
		<!-- EMAIL_CLOS -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "EMAIL_CLOS";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="EMAIL_CLOS"><?= $row['id'] ?></label>
		    <textarea id="EMAIL_CLOS" class="form-control" rows="5" name="<?=  $row['id'] ?>"><?=  $row['value'] ?></textarea>
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#EMAIL_CLOS").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=EMAIL_CLOS&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
</div>
<hr>
<h2>Otras Configuraciones</h2>
<div class="row">
	<div class="col">
		<!-- DOCUM_URL -->
		<?php 
		$row = array_values(array_filter($config,function($v,$k) {
		    return $v['id'] == "DOCUM_URL";
		}, ARRAY_FILTER_USE_BOTH))[0];
		?>
		<div class="form-group">
		    <label for="DOCUM_URL"><?= $row['id'] ?></label>
		    <input type="text" id="DOCUM_URL" class="form-control" name="<?=  $row['id'] ?>" value="<?=  $row['value'] ?>">
		    <small class="form-text text-muted"><?=  $row['description'] ?></small>
		</div>
		<script>
			$("#DOCUM_URL").change(function(){
				$.ajax({
					type: 'POST',
					url: './ajax/saveconfig.php',
					data:'id=DOCUM_URL&value='+$(this).val(),
					success: function(data){
						$(this).addClass("btn-success");
						setTimeout(function(){ $(this).removeClass("btn-success"); }, 3000);
					}
				});
			});
		</script>
	</div>
</div>
<hr>
<h2>Eliminar Inscripciones</h2>
<p><b>ATENCI&Oacute;N:</b> Una vez seleccionada la fecha se muestra la cantidad de inscripciones que se eliminar&aacute;n. Al presionar el botón se eliminarán todas las inscripciones en estado "cargando" (o sea, las que no fueron completadas) hasta la fecha seleccionada.</p>
<p>Esta acci&oacute;n no se puede deshacer</p>
<div class="row">
	<div class="col">
		<div class="form-group">
		    <label for="deleteinscriptions">Seleccione la fecha hasta la que desea eliminar las inscripciones</label>
		    <input type="date" id="deleteinscriptions" class="form-control" >
		</div>
	</div>
	<div class="col">
		<label >&nbsp;</label><br>
		<button id="btndeleteinscriptions" class="btn btn-danger" disabled="disabled">Eliminar</button>
	</div>
	<script>
		$("#deleteinscriptions").change(function(){
			$.ajax({
				type: 'POST',
				url: './ajax/deleteinscriptions.php',
				data:'action=count&to='+$("#deleteinscriptions").val(),
				success: function(data){
					$("#btndeleteinscriptions").html("Eliminar "+data+" inscripciones");
					$("#btndeleteinscriptions").prop("disabled", false);
				}
			});
		});
		$("#btndeleteinscriptions").click(function(){
			$.ajax({
				type: 'POST',
				url: './ajax/deleteinscriptions.php',
				data:'action=del&to='+$("#deleteinscriptions").val(),
				success: function(data){
					alert("Se eliminaron "+data+" inscripciones.");
					$("#btndeleteinscriptions").html("Eliminar");
					$("#btndeleteinscriptions").prop("disabled", true);
				}
			});
		});
	</script>
</div>
</div>
</div>
<style>
input.success{
color: green;
border-color: green;
}
</style>