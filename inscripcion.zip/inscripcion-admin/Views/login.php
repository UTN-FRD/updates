<?php
require_once('Controllers/Controller.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <div class="content">
        <div class="row">
            <div class="mx-auto" style="width: 50%;text-align: center;">
                <img src="img/utn-logo.jpg" class="img-fluid" width="" alt="">
                <h2>Administración de Inscripciones</h2>
                <p>Ingrese su usuario y contrase&ntilde;a para continuar</p>
            </div>
        </div>
        <?php 
        if(isset($_GET['msg'])){
        ?>
        <div class="row">
            <div class="mx-auto" style="width: 50%;text-align: center;">
                <div class="alert alert-danger">
                    <?= $_GET['msg'] ?>
                </div>
            </div>
        </div>
        <?php 
        }
        ?>
        <div class="row">
            <div class="col"></div>
            <div class="col">
                <form method="post">
                    <div class="form-group has-feedback">
                        <input name="user" type="text" class="form-control" placeholder="Usuario">
                    </div>
                    
                    <div class="form-group has-feedback">
                        <input name= "pass" type="password" class="form-control" placeholder="Contraseña">
                    </div>

                    <div class="row">
                        <div class="mx-auto">
                            <button type="submit" class="btn btn-primary btn-block btn-flat">Entrar</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col"></div>
        </div>
    </div>
</body>
</html>

<?php
    $controller= new Controller();

    $controller -> login();
?>