<p>Se muestran las inscripciones que se encuentran cerradas.</p>

<table id="example" class="display" style="width:100%">
    <thead>
        <tr>
            <th>Apellido</th>
            <th>Nombre</th>
            <th>Nro Documento</th>
            <th>Carrera</th>
            <th>Sede</th>
            <th>Estado</th>
            <th></th>
        </tr>
    </thead>
</table>

<script>


$(document).ready(function() {
    var table = $('#example').DataTable( {
        'processing': true,
        'serverSide': true,
        'ajax': './ajax/dt_closed.php',
        'columnDefs': [ {
            'targets': -1,
            'data': null,
            'defaultContent': '<button class="btn btn-success">Ver detalle</button>'
        } ],
        'createdRow': function( row, data, dataIndex){
            $(row).addClass( data[5] );
        }
    } );

    $('#example tbody').on( 'click', 'button', function () {
        var data = table.row( $(this).parents('tr') ).data();
        window.location = 'index.php?action=inscription-form&id='+data[ 6 ]; 
    } );
} );
</script>