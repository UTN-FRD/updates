<?php
require_once('Controllers/Controller.php');
$controller = new Controller();
$configParams = $controller->getConfigParams();
$savedValues = $controller->getSavedValues();
$activeQuestions = $controller->getActiveQuestions();
$disabled = '';
$editable = true;

if($savedValues['state']=='cargando' || $savedValues['state']=='aprobado' || $savedValues['state']=='rechazado'){
	$disabled = 'disabled="disabled"';
	$editable = false;
}
?>

<div class="row">
	<?php if($_SESSION['rol']=='Admin'){ ?>
	<div class="col">
		<div class="form-group">
			<label for="estadoinscripcion">Estado</label>
			<select class="custom-select" id="estadoinscripcion" name="estadoinscripcion">
				<option value="cargando">Cargando</option>
				<option value="pendiente">Pendiente</option>
				<option value="aprobado">Aprobado</option>
				<option value="rechazado">Rechazado</option>
				<option value="corregido">Corregido</option>
			</select>
		</div>
	</div>
	<?php }?>
	<?php if($editable){?>
	<div class="col">
		<button class="btn btn-warning btn-edicion" data-state="false">Habilitar edición</button>
	</div>
	<?php }?>
	<div class="col">
		<button class="btn btn-primary float-right" onclick="window.close();">Volver</button>
	</div>
</div>
<hr>
<form method="POST" id="inscription-form" class="needs-validation" novalidate autocomplete="off">
	<?php include_once('components/inscription-questions.php') ?>
	<?php include_once('components/inscription-files.php') ?>
	<br>
</form>
<div class="row">
	<div class="col">
	<?php if($editable){?>
		<button class="btn btn-warning btn-edicion" data-state="false">Habilitar edición</button>
	<?php }?>
	</div>
	<div class="col">
		<button class="btn btn-primary float-right" onclick="window.close();">Volver</button>
	</div>
</div>
<div class="row">
	<div class="col">
		<h2>Estado actual: <span id="inscription-state"></span></h2>
		<a data-toggle="collapse" href="#collapse-historial" role="button" aria-expanded="false" aria-controls="collapse-historial">Ver historial de cambios</a>
		<div class="collapse" id="collapse-historial">
			<div class="card card-body">
				<textarea class="form-control" id="inscription-history" readonly="readonly" style="background:white"></textarea>
			</div>
			<?php
			foreach( $controller->getCorreos($_GET['id']) as $correo ){
			?> 
			<div class="card border-primary">
				<div class="card-header">
					<div class="row">
						<div class="col"><?= $correo['fecha'] ?></div>
						<div class="col"><p><b>Para: </b><?= $correo['para'] ?></p></div>
						<div class="col"><p><b>De: </b><?= $correo['de'] ?></p></div>
					</div>
					<div class="row">
						<div class="col"><p><b>Asunto: </b><?= $correo['asunto'] ?></p></div>
						<div class="col"><a data-toggle="collapse" href="#collapse-correo-<?= $correo['id'] ?>" role="button" aria-expanded="false" aria-controls="collapse-correo-<?= $correo['id'] ?>">Ver correo</a></div>
					</div>					
				</div>
				<div class="card-body collapse" id="collapse-correo-<?= $correo['id'] ?>">
					<p class="card-text"><?= $correo['cuerpo'] ?></p>
				</div>
				<?php if( isset($correo['resultado']) ){ ?>
					<div class="card-footer">
						<div class="row">
							<div class="col-9">
								<div class="alert alert-danger">Este correo no ha sido enviado por el siguiente error: <?= $correo['resultado'] ?></div>
							</div>
							<div class="col-3">
								<button class="btn btn-primary" onclick="reenviarCorreo(<?= $correo['id'] ?>)">Reenviar correo</button>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>
			<?php
			}
			?>
			<script>
			function reenviarCorreo(id){
				$.ajax({
					type: 'POST',
					url: './ajax/resend_email.php',
					data:'id='+id,
					success: function(){
						window.location.reload();
					}
				});
			}
			</script>
		</div>
		<h2>SysAcad</h2>
		<a data-toggle="collapse" href="#collapse-sysacad" role="button" aria-expanded="false" aria-controls="collapse-sysacad">Ver detalle</a>
		<div class="collapse" id="collapse-sysacad">
			<div class="form-group">
				<label for="legajo_sysacad">Legajo generado por el SysAcad</label>
				<input type="text" class="form-control" id="legajo_sysacad" name="legajo_sysacad" disabled >
			</div>
			<div class="form-group">
				<label for="fecha_sysacad">Fecha de última interacción con el SysAcad</label>
				<input type="text" class="form-control" id="fecha_sysacad" name="fecha_sysacad" disabled >
			</div>
			<div class="form-group">
				<label for="error_sysacad">Error enviado por el SysAcad (en caso que hubiera)</label>
				<input type="text" class="form-control" id="error_sysacad" name="error_sysacad" disabled >
			</div>
		</div>
		<h2>Cambiar de estado</h2>
		<p>Sólo los estados <b>pendiente</b> y <b>corregido</b> pueden ser modificados. <a data-toggle="collapse" href="#collapseEstados" role="button" aria-expanded="false" aria-controls="collapseEstados">(ver diagrama estados)</a></p>
		<div class="collapse" id="collapseEstados">
			<div class="card card-body">
				<img class="card-img" src="img/inscripcionfrd-estados.jpg"/>
			</div>
		</div>
		<form method="post">
			<input type="hidden" name="id" id="id" value="<?=$_GET['id']?>">
			<label for="">Comentarios</label>
			<textarea class="form-control" name="statemessage" <?= $disabled ?>></textarea>
			<div class="form-check d-none">
				<input type="checkbox" class="form-check-input" name="notifychanges" value="SI" checked="checked">
				<label class="form-check-label" for="notifychanges">Notificar por e-mail al inscripto (se enviará el texto escrito en el comentario).</label>
			</div>
			<div class="form-check d-none">
				<input type="checkbox" class="form-check-input" name="reopen" value="SI" checked="checked">
				<label class="form-check-label" for="reopen">Reabrir la inscripción (permite que se pueda modificar el formulario sólo cuando está rechazado)</label>
			</div>
			<div class="row">
				<div class="col">
					<center>
					<button class="btn btn-success" name="aprobar" <?= $disabled ?>>Aprobar</button>	
					<p>Al aprobar una inscripción se pasa a estado <b>aprobado</b> y se está dando fé que la misma se encuentra completa y con los datos correctos, así como también la documentación adjunta.</p>
					<p>Se notificará al inscripto por correo electrónico, enviando el texto escrito aquí.</p>
					</center>
				</div>
				<div class="col">
					<center>
					<button class="btn btn-danger" name="rechazar" <?= $disabled ?>>Rechazar</button>
					<p>Al rechazar una inscripción se pasa a estado <b>rechazado</b> y se envía una notificación al inscripto via correo electrónico.</p>
					<p>En ese correo electrónico se envía la descripción escrita aquí y un link para que el usuario pueda modificar la inscripción.</p>
					<p>Una vez que el usuario realice las modificaciones se pasa a estado <b>corregido</b>, donde se dará la opción de aprobar o rechazar la inscripción.</p>

					</center>
				</div>
			</div>
		</form>
	</div>
</div>
<script>
$("nav").addClass("collapse");
$(document).ready(function(){
	$('#inscription-state').html(savedValues.state);
	$('#estadoinscripcion').val(savedValues.state);
	$('#inscription-history').html(savedValues.state_messages);
	$('#inscription-history').attr("rows",savedValues.state_messages?'savedValues.state_messages.split(/\n/).length':'3');
});
</script>

<?php

?>
<br><hr>
<script>
var savedValues = jQuery.parseJSON(JSON.stringify(<?= json_encode(array_filter($savedValues)); ?>));
var configParams = jQuery.parseJSON(JSON.stringify(<?= json_encode(array_filter($configParams)); ?>));
var activeQuestions = '<?= $activeQuestions; ?>'.split('|');
var username = "<?= $_SESSION["user"] ?>";

<?php if($editable){?>
$(document).ready(function(){
	if(savedValues.state=='pendiente' || savedValues.state=='corregido'){
		$(".btn-edicion").show();
	}
	$(".btn-edicion").click(function(){
		charging = false;
		if(savedValues.state=='pendiente' || savedValues.state=='corregido'){
			if($(this).data("state")){
				$('form#inscription-form input,form#inscription-form select').prop('disabled',true);
				$(this).text("Habilitar edición");
				$(this).data("state", false);
			}else{
				$('form#inscription-form input,form#inscription-form select').prop('disabled',false);
				$(this).text("deshabilitar edición");
				$(this).data("state", true);
			}
		}
	});
});
<?php }?>

<?php if($_SESSION['rol']=='Admin'){ ?>
$(document).ready(function(){
	$("#estadoinscripcion").change(function(){
		if(confirm("Está seguro que desea cambiar el estado de la inscripción a "+$(this).val()+"?")){
			$.ajax({
				type: 'POST',
				url: './ajax/change_state.php',
				data:'id=<?=$_GET['id']?>&state='+$(this).val(),
				success: function(){
					window.location.reload();
				}
			});
		}else{
			return false;
		}
	});
});	
<?php }?>
</script>
<script src="js/inscription-script.js"></script>
<?php
if(isset($_POST['aprobar']) || isset($_POST['rechazar'])){ 
	$controller->changeStateInscription();
}
?>

