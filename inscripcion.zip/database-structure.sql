SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `configuration` (
  `id` varchar(10) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `value` varchar(3000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `config_params` (
  `id` int(11) NOT NULL,
  `field` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `display` varchar(255) DEFAULT NULL,
  `sort_criteria` int(11) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `related_values` varchar(255) DEFAULT NULL,
  `related_field` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `message` text NOT NULL,
  `creation_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `entidades_educativas` (
  `cue` decimal(10,0) NOT NULL,
  `nombre` varchar(120) DEFAULT NULL,
  `direccion` varchar(120) DEFAULT NULL,
  `localidad` varchar(60) DEFAULT NULL,
  `provincia` varchar(60) DEFAULT NULL,
  `pais` varchar(50) DEFAULT NULL,
  `facultad` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `especialidades` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `facesp` (
  `id_facultad` int(11) NOT NULL,
  `id_especialidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `facultades` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `inscriptions` (
  `id` int(11) NOT NULL,
  `alumnonumerodocumento` varchar(40) NOT NULL,
  `contactoemail` varchar(100) NOT NULL,
  `access_token` varchar(100) NOT NULL,
  `carrera` varchar(100) DEFAULT NULL,
  `carrera_preseteada` tinyint(1) NOT NULL DEFAULT 0,
  `lugarcursado` varchar(100) DEFAULT NULL,
  `formaingreso` varchar(100) DEFAULT NULL,
  `tipocursado` varchar(100) DEFAULT NULL,
  `introductoriointensivo` varchar(100) DEFAULT NULL,
  `alumnoapellido` varchar(100) DEFAULT NULL,
  `alumnonombres` varchar(100) DEFAULT NULL,
  `alumnotipodocumento` varchar(100) DEFAULT NULL,
  `alumnocuil` varchar(100) DEFAULT NULL,
  `alumnosexo` varchar(100) DEFAULT NULL,
  `alumnogenero` VARCHAR(50) DEFAULT NULL,
  `alumnogenerodet` VARCHAR(255) DEFAULT NULL,
  `alumnoestadocivil` varchar(100) DEFAULT NULL,
  `nacfechanacimiento` varchar(100) DEFAULT NULL,
  `nacnacionalidad` varchar(100) DEFAULT NULL,
  `nacvencdni` varchar(100) DEFAULT NULL,
  `nacpais` varchar(100) DEFAULT NULL,
  `nacprovincia` varchar(100) DEFAULT NULL,
  `naclocalidad` varchar(100) DEFAULT NULL,
  `nacpartidodepartamento` varchar(100) DEFAULT NULL,
  `nacgruposanguineo` varchar(100) DEFAULT NULL,
  `domiciliocalle` varchar(100) DEFAULT NULL,
  `domicilionumero` varchar(100) DEFAULT NULL,
  `domiciliopiso` varchar(100) DEFAULT NULL,
  `domiciliolocalidad` varchar(100) DEFAULT NULL,
  `domiciliopartido` varchar(100) DEFAULT NULL,
  `domicilioprovincia` varchar(100) DEFAULT NULL,
  `domiciliocp` varchar(100) DEFAULT NULL,
  `contactotelefonofijo` varchar(100) DEFAULT NULL,
  `contactotelefonomovil` varchar(100) DEFAULT NULL,
  `emergenciacontacto` varchar(100) DEFAULT NULL,
  `emergenciatelefono` varchar(100) DEFAULT NULL,
  `contactoemailalternativo` varchar(100) DEFAULT NULL,
  `secundarioegreso` varchar(100) DEFAULT NULL,
  `secundarioestado` varchar(100) DEFAULT NULL,
  `secundarioanioegreso` varchar(100) DEFAULT NULL,
  `secundariotituladoen` varchar(100) DEFAULT NULL,
  `secundariotecnico` varchar(100) DEFAULT NULL,
  `secundarioanalitico` varchar(100) DEFAULT NULL,
  `secundariocue` varchar(50) DEFAULT NULL,
  `secundarioinstitucion` varchar(100) DEFAULT NULL,
  `secundarioprovincia` varchar(100) DEFAULT NULL,
  `secundariolocalidad` varchar(100) DEFAULT NULL,
  `secundariodependede` varchar(100) DEFAULT NULL,
  `titulounivnombre` varchar(1000) DEFAULT NULL,
  `titulouniventramite` varchar(11) DEFAULT NULL,
  `titulounivcue` varchar(50) DEFAULT NULL,
  `titulounivinstitucion` varchar(255) DEFAULT NULL,
  `titulounivanioegreso` varchar(11) DEFAULT NULL,
  `titulounivlocalidad` varchar(100) DEFAULT NULL,
  `titulounivprovincia` varchar(100) DEFAULT NULL,
  `otrosestudiostipo` varchar(100) DEFAULT NULL,
  `otrosestudioscarrera` varchar(100) DEFAULT NULL,
  `otrosestudiosinstitucion` varchar(100) DEFAULT NULL,
  `otrosestudiosmateriasaprobadas` varchar(100) DEFAULT NULL,
  `otrosestudiosestado` varchar(100) DEFAULT NULL,
  `trabajotrabajas` varchar(100) DEFAULT NULL,
  `situacionlaboral` varchar(50) DEFAULT NULL,
  `tipotrabajo` varchar(50) DEFAULT NULL,
  `trabajoocupacion` varchar(50) DEFAULT NULL,
  `tipoocupacion` varchar(50) DEFAULT NULL,
  `trabajoenque` varchar(100) DEFAULT NULL,
  `trabajohoras` varchar(100) DEFAULT NULL,
  `trabajorelcarrera` varchar(50) DEFAULT NULL,
  `trabajoempresa` varchar(100) DEFAULT NULL,
  `trabajodireccion` varchar(100) DEFAULT NULL,
  `trabajotelefono` varchar(100) DEFAULT NULL,
  `deporte` varchar(100) DEFAULT NULL,
  `tecnotienepc` varchar(100) DEFAULT NULL,
  `tecnodondepc` varchar(100) DEFAULT NULL,
  `tecnocelular` varchar(100) DEFAULT NULL,
  `tecnotieneinternet` varchar(100) DEFAULT NULL,
  `tecnointernet` varchar(100) DEFAULT NULL,
  `tecnousointernet` varchar(100) DEFAULT NULL,
  `hijosacargo` varchar(100) DEFAULT NULL,
  `familiaacargo` varchar(50) DEFAULT NULL,
  `padreapellido` varchar(100) DEFAULT NULL,
  `padrenombre` varchar(100) DEFAULT NULL,
  `padrefechanac` varchar(100) DEFAULT NULL,
  `padrevive` varchar(100) DEFAULT NULL,
  `padreestudios` varchar(100) DEFAULT NULL,
  `padretrabajo` varchar(100) DEFAULT NULL,
  `padresituacionlaboral` varchar(50) DEFAULT NULL,
  `padreobrasocial` varchar(100) DEFAULT NULL,
  `madreapellido` varchar(100) DEFAULT NULL,
  `madrenombre` varchar(100) DEFAULT NULL,
  `madrefechanac` varchar(100) DEFAULT NULL,
  `madrevive` varchar(100) DEFAULT NULL,
  `madreestudios` varchar(100) DEFAULT NULL,
  `madretrabajo` varchar(100) DEFAULT NULL,
  `madresituacionlaboral` varchar(50) DEFAULT NULL,
  `madreobrasocial` varchar(100) DEFAULT NULL,
  `hermanoscantidad` varchar(100) DEFAULT NULL,
  `hermanosedades` varchar(100) DEFAULT NULL,
  `hermanosactividades` varchar(100) DEFAULT NULL,
  `casatipo` varchar(100) DEFAULT NULL,
  `casacondicion` varchar(100) DEFAULT NULL,
  `casamediotraslado` varchar(100) DEFAULT NULL,
  `documentaciondni` varchar(100) DEFAULT NULL,
  `documentaciondniback` varchar(100) DEFAULT NULL,
  `documentacioncuil` varchar(100) DEFAULT NULL,
  `documentacionnacimiento` varchar(100) DEFAULT NULL,
  `documentacionanalitico` varchar(100) DEFAULT NULL,
  `documentacioncv` varchar(255) DEFAULT NULL,
  `documentaciontitulogrado` varchar(255) DEFAULT NULL,
  `documentacioncertmaterias` varchar(255) DEFAULT NULL,
  `fecha_inicio` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_cierre` datetime DEFAULT NULL,
  `state` varchar(10) NOT NULL DEFAULT 'cargando',
  `state_messages` text DEFAULT NULL,
  `legajo_sysacad` varchar(100) DEFAULT NULL,
  `error_sysacad` text DEFAULT NULL,
  `fecha_sysacad` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `requisitosacad` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `related_field` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` varchar(30) NOT NULL,
  `last_access` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


ALTER TABLE `configuration`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `config_params`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `entidades_educativas`
  ADD PRIMARY KEY (`cue`);

ALTER TABLE `especialidades`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `facultades`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `inscriptions`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `requisitosacad`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `config_params`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `especialidades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `facultades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `inscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

set sql_mode='';


ALTER TABLE `users` ADD `lugarcursado` VARCHAR(255) NULL AFTER `role`, ADD `carreras` VARCHAR(255) NULL AFTER `lugarcursado`;
ALTER TABLE `inscriptions` ADD `anioingreso` INT(4) NULL AFTER `carrera_preseteada`;


CREATE TABLE `discapacidad` (
  `ID` int(11) NOT NULL,
  `CERTDISCAP` varchar(2) DEFAULT NULL,
  `NEAEAUDITI` varchar(2) DEFAULT NULL,
  `NEAEVISUAL` varchar(2) DEFAULT NULL,
  `NEAEMOTRIZ` varchar(2) DEFAULT NULL,
  `NEAEPSICOS` varchar(2) DEFAULT NULL,
  `NEAEOTRAS` varchar(2) DEFAULT NULL,
  `AUD_DIFICU` varchar(2) DEFAULT NULL,
  `AUD_COMUNI` varchar(2) DEFAULT NULL,
  `AUD_COM_LA` varchar(2) DEFAULT NULL,
  `AUD_COMOTR` varchar(5) DEFAULT NULL,
  `AUD_COMOTRDESC` varchar(255) DEFAULT NULL,
  `AUD_APOYO` varchar(255) DEFAULT NULL,
  `AUD_APY_I` varchar(2) DEFAULT NULL,
  `AUD_APY_A` varchar(2) DEFAULT NULL,
  `AUD_APY_O` varchar(2) DEFAULT NULL,
  `AUD_APY_D` varchar(255) DEFAULT NULL,
  `VIS_DIFICU` varchar(2) DEFAULT NULL,
  `VIS_APOYO` varchar(255) DEFAULT NULL,
  `VIS_APY_A` varchar(2) DEFAULT NULL,
  `VIS_APY_T` varchar(2) DEFAULT NULL,
  `VIS_APY_B` varchar(2) DEFAULT NULL,
  `VIS_APY_O` varchar(2) DEFAULT NULL,
  `VIS_APY_D` varchar(255) DEFAULT NULL,
  `MOT_APOYO` varchar(255) DEFAULT NULL,
  `MOT_APY_P` varchar(255) DEFAULT NULL,
  `MOT_APY_O` varchar(2) DEFAULT NULL,
  `MOT_APY_D` varchar(255) DEFAULT NULL,
  `PSI_DESCRI` varchar(255) DEFAULT NULL,
  `PSI_APOYO` varchar(255) DEFAULT NULL,
  `PSI_APY_O` varchar(2) DEFAULT NULL,
  `PSI_APY_D` varchar(255) DEFAULT NULL,
  `OTRA_CUAL` varchar(255) DEFAULT NULL,
  `OTRA_APY_O` varchar(2) DEFAULT NULL,
  `OTRA_APY_D` varchar(255) DEFAULT NULL,
  `OTRA_DISCA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB;

ALTER TABLE `discapacidad`
  ADD PRIMARY KEY (`ID`);

CREATE TABLE `mat_com` ( 
  `id` INT NOT NULL AUTO_INCREMENT , 
  `id_curso` INT NOT NULL , 
  `id_materia` INT NOT NULL , 
  `id_comision` INT NOT NULL , 
  PRIMARY KEY (`id`)
) ENGINE = InnoDB;

CREATE TABLE `cursos` (
  `id` int(11) NOT NULL AUTO_INCREMENT, 
  `id_especialidad` INT NOT NULL , 
  `nombre` varchar(255) NOT NULL, 
  `cupo` int(11) DEFAULT NULL, 
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;


COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
