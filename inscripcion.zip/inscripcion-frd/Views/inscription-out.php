<div class="elementor-widget-container">
	<h2 class="elementor-heading-title elementor-size-default">El período de inscripción se encuentra cerrado.</h2>
	<div id="myProgress">
		<div id="myBar"></div>
	</div>
</div>

<script>
var width = 1;
$(function() {
	var i = 0;
	var id = setInterval(function(){
		if (width >= 100) {
			//window.location.href = "https://www.frd.utn.edu.ar/ingresantes/";
			clearInterval(id);
		} else {
			$('#myBar').css( 'width', width++ + "%");
		}
	}, 25);
});
</script>
<style>
#myProgress{width:100%}
#myBar{width: 0%;height: 5px;background-color:#49bb97}
</style>