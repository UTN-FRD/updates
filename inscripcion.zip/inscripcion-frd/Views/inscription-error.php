<br>
<div class="row">
	<div class="col-md-12">
		<center>
			<div class="alert alert-warning">El enlace para la inscripci&oacute;n que desea acceder ha vencido. Esto signica que ya fu&eacute; completada.<br>Verifique que est&aacute; accediendo al &uacute;ltimo correo enviado.<br>No dude en comunicarse con nosotros en caso de alg&uacute;n problema.</div>
			<a href="." class="btn btn-info">Volver</a>
		</center>
	</div>
</div>