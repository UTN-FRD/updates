<br>
<div class="row">
	<div class="col-md-12">
		<center>
			<div class="alert alert-success">Se realiz&oacute; la inscripci&oacute;n correctamente. Enviamos un correo electr&oacute;nico con la informaci&oacute;n de su inscripci&oacute;n.</div>
		</center>
	</div>
</div>