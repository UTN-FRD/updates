<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["field"])) {
    $id = $_POST["id"];
    $token = $_POST["token"];
    $field = $_POST["field"];
    $value = $_POST["value"];
    echo json_encode( Data::saveFieldValue($id, $token, $field, $value) );
} 
?>