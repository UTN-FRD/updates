<?php
require_once('../Modells/Data.php');

$files=$_FILES['fileupload'];
$tmp_name=$files['tmp_name'];
$name=$files['name'];
$destination_dir=dirname(__FILE__).'/../documents/'.$_GET['id'];
if(!is_dir($destination_dir)){
	mkdir($destination_dir, 0755, true);
}
$destination=$destination_dir.'/'.$name;
$res=move_uploaded_file($tmp_name, $destination);

if($res) {
	Data::saveFieldValue($_GET["id"], $_GET["token"], $_GET["field"], $name); 
	echo $name;
} else {
	echo 'error';
}
?>