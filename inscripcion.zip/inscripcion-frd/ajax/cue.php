<?php 
require_once('../Modells/Data.php');

if (!empty($_POST["id"])) {
    $result = Data::fetchCUE($_POST["id"]);

	echo json_encode($result);
} 
if (!empty($_POST["nombre"]) || !empty($_POST["pais"]) || !empty($_POST["provincia"]) || !empty($_POST["ciudad"])) {
    $result = Data::searchCUE($_POST["nombre"],$_POST["pais"],$_POST["provincia"],$_POST["ciudad"]);

	echo json_encode($result);
} 

?>