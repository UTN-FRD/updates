<?php 
require_once('../Modells/Data.php');

$result = Data::checkAdmissionCode($_POST["code"]);

echo $result;

?>