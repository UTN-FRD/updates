<?php
//require_once('../Modells/Data.php');
require_once('../Modells/emailer.php');

$correo = $_POST['correo'];
$tel = $_POST['tel'];
$msg = $_POST['msg'];

//$res = Data::saveContactMessage($correo, $tel, $msg);

//if( !array_key_exists('block', $res) ){
	Emailer::sendContactMessage($correo, $tel, $msg);
	
	echo "Mensaje enviado";
//}else{
//	echo "error: ".$res['block'];
//}
?>