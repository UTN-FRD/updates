<?php
require_once('Connection.php');

class Data extends Connection{

    //Funcion que compara si existe el usuario que intenta logearse, pasandole los datos a traves de un objeto y ademas el nombre de la tabla,
    //Asi como se convierte a la contraseña con la funcion MD5 para que se compare correctamente con la almacenada en la base de datos
    public static function validarUsuario($datos){

        $stmt = Connection::connect()->prepare("SELECT * FROM usuarios WHERE correo = :correo AND contrasena = md5(:contra) ");

        $stmt->bindParam(':correo', $datos['correo'], PDO::PARAM_STR);
        $stmt->bindParam(':contra', $datos['contrasena'], PDO::PARAM_STR);

        $stmt->execute();

        $r = array();

        $r = $stmt->fetch(PDO::FETCH_ASSOC);

        return $r;

    }

    /** Verifica si se ha enviado un mensaje en los últimos minutos. Si es así, guarda y bloquea el envío. Sino guarda el mensaje. **/
    public static function saveContactMessage($correo, $tel, $msg){
        $response = array();

        $stmt = Connection::connect()->prepare("select * from contacts where DATE_ADD(creation_date, INTERVAL 10 MINUTE) >= NOW() and (email=:email OR phone=:phone)");

        $stmt->bindParam(':email', $correo, PDO::PARAM_STR);
        $stmt->bindParam(':phone', $tel, PDO::PARAM_STR);

        $stmt->execute();

        $r = $stmt->fetchAll();

        $stmt2 = Connection::connect()->prepare("INSERT INTO contacts (email, phone, message) VALUES (:email, :phone, :message)");
        $stmt2->bindParam(':email', $correo, PDO::PARAM_STR);
        $stmt2->bindParam(':phone', $tel, PDO::PARAM_STR);

        if( !empty($r) ){
            $stmt2->bindParam(':message', '[BLOQUEADO]'.$msg, PDO::PARAM_STR);

            $response = array('blocked' => 'Ya se ha enviado un mensaje en los últimos minutos. Vuelva a intentar mas tarde.');
        }else{
            $stmt2->bindParam(':message', $msg, PDO::PARAM_STR);
        }

        if($stmt2.execute() && empty($response)){
            return array('success'=>'success');
        }else{
            if(empty($response)){
                $response = array('error'=>'Error al guardar el mensaje.');
            }
            return $response;
        }

    }

    public static function fetchConfigParams($id, $token){
        $stmt = Connection::connect()->prepare("SELECT cp.field, cp.display, cp.value FROM config_params cp WHERE related_field is NULL ORDER BY cp.sort_criteria");
        $stmt->execute();
        $r = array();
        $r = $stmt->fetchAll();

        //carreras
        $stmt = Connection::connect()->prepare("select c.value FROM configuration c WHERE c.id='OPEN_CARRE'");
        $stmt->execute();
        $carreras = $stmt->fetchColumn();
        $stmt = Connection::connect()->prepare("select 'carrera' as field, e.nombre as display, e.id as value FROM especialidades e WHERE e.id IN (".$carreras.") order by e.nombre");
        $stmt->execute();
        $r = array_merge($r, $stmt->fetchAll());

        //cursos
        $stmt = Connection::connect()->prepare("select 'tipocursado' as field, nombre as display, id as value from cursos where id=(select tipocursado from inscriptions WHERE id = :id)");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $r = array_merge($r, $stmt->fetchAll());

        //find related fields to check if were saved
        $stmt2 = Connection::connect()->prepare("SELECT DISTINCT cp.field FROM config_params cp WHERE related_field is not NULL");
        $stmt2->execute();

        foreach ($stmt2->fetchAll() as $row) {
            $stmt3 = Connection::connect()->prepare("SELECT cp.field, cp.display, cp.value FROM config_params cp WHERE cp.field='".$row['field']."' and cp.value = (select ".$row['field']." from inscriptions WHERE id = :id AND access_token = md5(:token) AND ".$row['field']." is not NULL)");
            $stmt3->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt3->bindParam(':token', $token, PDO::PARAM_STR);
            $stmt3->execute();
            $r = array_merge($r, $stmt3->fetchAll());
        }

        return $r;
    }


    public static function fetchConfigParamsRelated($field, $value){
        $query = "(SELECT cp.display, cp.value, cp.field FROM config_params cp WHERE (related_values rlike '^".$value." | ".$value." | ".$value."$' or related_values rlike '^".$value.",|,".$value.",|,".$value."$') and related_field=:field ORDER BY cp.sort_criteria)";

        if($field=='carrera'){
            //$query=$query." UNION SELECT c.nombre as display, c.id as value, 'tipocursado' as field from cursos c where c.id_especialidad=".$value;
            $query=$query." UNION SELECT c.nombre as display, c.id as value, 'tipocursado' as field from cursos c where c.id_especialidad=:carrera and (c.cupo > (SELECT count(i.id) FROM inscriptions i where i.anioingreso = (SELECT co.value from configuration co where co.id='ANIO_INSC') and i.tipocursado=c.id and i.state!='cargando') or c.cupo=0 or c.cupo is null)";
        }

        $stmt = Connection::connect()->prepare($query);
        $stmt->bindParam(':field', $field, PDO::PARAM_STR);
        $stmt->bindParam(':carrera', $value, PDO::PARAM_STR);

        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function hasInscription($alumnonumerodocumento){
        $db = Connection::connect();
        $stmt = $db->prepare("SELECT count(i.id) from inscriptions i join configuration c on c.id='ANIO_INSC' and i.anioingreso=c.value WHERE i.alumnonumerodocumento=:dni and i.state<>'cargando' and i.state<>'rechazado'");

        $stmt->bindParam(':dni', $alumnonumerodocumento, PDO::PARAM_STR);

        $stmt->execute();

        return !($stmt->fetchColumn()==0);
    }

    public static function registerInscription($alumnonumerodocumento, $contactoemail, $carrera){
        $db = Connection::connect();

        $stmt = $db->prepare("INSERT INTO inscriptions (alumnonumerodocumento, contactoemail, access_token, carrera, carrera_preseteada, anioingreso) VALUES (:dni, :email, md5(:token), :carrera, :carrera_preseteada, (select value from configuration where id='ANIO_INSC'))");

        $token = bin2hex(random_bytes(20));

        $carrera_preseteada = isset($carrera)&&$carrera<>''?1:0;

        $stmt->bindParam(':dni', $alumnonumerodocumento, PDO::PARAM_STR);
        $stmt->bindParam(':email', $contactoemail, PDO::PARAM_STR);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->bindParam(':carrera', $carrera, PDO::PARAM_STR);
        $stmt->bindParam(':carrera_preseteada', $carrera_preseteada, PDO::PARAM_BOOL);

        if($stmt->execute()){
            return array('token' => $token, 'id' => $db->lastInsertId());
        } else {
            return array('error' => 'error');
        }

    }

    public static function closeInscription($id, $token){
        $stmt = Connection::connect()->prepare("UPDATE inscriptions SET fecha_cierre = NOW(), state_messages = IF(state='rechazado',concat(state_messages,concat(now(),' Corregido por el interesado.\n')), concat(now(),' Fin de la carga.\n')), state = IF(state='rechazado','corregido','pendiente') where id = :id and access_token = md5(:token)");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);

        return $stmt->execute();
    }

    public static function getInscriptionState($id){
        $stmt = Connection::connect()->prepare("SELECT state FROM inscriptions WHERE id = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchColumn();        
    }

    public static function checkRegistration($id, $token){
        $db = Connection::connect();
        // verifico que el token sea válido
        $stmt = $db->prepare("SELECT count(1) FROM inscriptions WHERE id = :id AND access_token = md5(:token) AND fecha_cierre IS NULL ");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->execute();

        // verifico que no tenga una inscripción cerrada
        $stmt2 = $db->prepare("SELECT count(i.id) from inscriptions i join configuration c on c.id='ANIO_INSC' and i.anioingreso=c.value WHERE i.alumnonumerodocumento in (SELECT ss.alumnonumerodocumento from inscriptions ss WHERE ss.id=:id) and i.state<>'cargando' and i.state<>'rechazado';");
        $stmt2->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt2->execute();

        // verifico si está abierta la inscripción
        // si es rechazado lo dejo pasar
        $stmt3 = $db->prepare("SELECT not(i.state='cargando' and value='false') FROM `inscriptions` i, configuration c WHERE i.id=:id and c.id='FORM_OPEN'");
        $stmt3->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt3->execute();

        return (!($stmt->fetchColumn()==0) && $stmt2->fetchColumn()==0 && $stmt3->fetchColumn()==1);
    }

    public static function fetchSavedValues($id, $token){
        $stmt = Connection::connect()->prepare("SELECT i.*, if(d.id is null,'NO','SI') as discapacidad, CERTDISCAP as discapacidadCERTDISCAP, NEAEAUDITI as discapacidadNEAEAUDITI, NEAEVISUAL as discapacidadNEAEVISUAL, NEAEMOTRIZ as discapacidadNEAEMOTRIZ, NEAEPSICOS as discapacidadNEAEPSICOS, if(NEAEOTRAS is null OR NEAEOTRAS='' ,'NO','otro') as discapacidadOTRAS, NEAEOTRAS as discapacidadNEAEOTRAS, AUD_DIFICU as discapacidadAUD_DIFICU, AUD_COMUNI as discapacidadAUD_COMUNI, AUD_COM_LA as discapacidadAUD_COM_LA, AUD_COMOTR as discapacidadAUD_COMOTR, AUD_COMOTRDESC as discapacidadAUD_COMOTRDESC, AUD_APOYO as discapacidadAUD_APOYO, AUD_APY_I as discapacidadAUD_APY_I, AUD_APY_A as discapacidadAUD_APY_A, AUD_APY_O as discapacidadAUD_APY_O, AUD_APY_D as discapacidadAUD_APY_D, VIS_DIFICU as discapacidadVIS_DIFICU, VIS_APOYO as discapacidadVIS_APOYO, VIS_APY_A as discapacidadVIS_APY_A, VIS_APY_T as discapacidadVIS_APY_T, VIS_APY_B as discapacidadVIS_APY_B, VIS_APY_O as discapacidadVIS_APY_O, VIS_APY_D as discapacidadVIS_APY_D, MOT_APOYO as discapacidadMOT_APOYO, MOT_APY_P as discapacidadMOT_APY_P, MOT_APY_O as discapacidadMOT_APY_O, MOT_APY_D as discapacidadMOT_APY_D, PSI_DESCRI as discapacidadPSI_DESCRI, PSI_APOYO as discapacidadPSI_APOYO, PSI_APY_O as discapacidadPSI_APY_O, PSI_APY_D as discapacidadPSI_APY_D, OTRA_CUAL as discapacidadOTRA_CUAL, OTRA_APY_O as discapacidadOTRA_APY_O, OTRA_APY_D as discapacidadOTRA_APY_D, OTRA_DISCA as discapacidadOTRA_DISCA FROM inscriptions i left join discapacidad d on i.id=d.id WHERE i.id = :id AND access_token = md5(:token)");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function saveFieldValue($id, $token, $field, $value){
        if( substr( $field, 0, 12 ) === "discapacidad" ) {
            if($field==="discapacidad"){
                if($value=='SI'){
                    $stmt = Connection::connect()->prepare("INSERT INTO discapacidad (id) SELECT :id FROM DUAL WHERE NOT EXISTS (SELECT id FROM discapacidad WHERE id=:id)");
                    $stmt->bindParam(':id', $id, PDO::PARAM_INT);    
                }else{
                    $stmt = Connection::connect()->prepare("DELETE FROM discapacidad WHERE id=:id");
                    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
                }
            }else{
                $field = substr($field, 12);
                $stmt = Connection::connect()->prepare("UPDATE discapacidad SET `".$field."`=:val where id=:id");
                $stmt->bindParam(':val', $value, PDO::PARAM_STR);
                $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            }
        } else {
            if( !($value=='SI' || $value=='NO' ||  substr( $field, 0, 8 ) === "document") ){
                $stmt = Connection::connect()->prepare("select count(1) from config_params where field='".$field."'");
                $stmt->execute();
                if($stmt->fetchColumn()==0){
                    $value = ucwords($value);
                }
            }
            $stmt = Connection::connect()->prepare("UPDATE inscriptions SET `".$field."`= :val where id = :id and access_token = md5(:token)");
            $stmt->bindParam(':val', $value, PDO::PARAM_STR);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        }


        if($stmt->execute()){
            return "success";
        } else {
            return "error";
        }    
    }

    public static function fetchCareer($id){
        $stmt = Connection::connect()->prepare("select e.nombre as display FROM especialidades e WHERE e.id = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchValueConfiguration($id){
        $stmt = Connection::connect()->prepare("SELECT value FROM configuration WHERE id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchEmailConfiguration(){
        $stmt = Connection::connect()->prepare("SELECT id,value FROM configuration WHERE id like 'EMAIL_%'");

        $stmt->execute();

        $result = array();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $result[$row['id']] = $row['value'];
        }
        return $result;
    }

    public static function fetchConfiguration($id){
        $stmt = Connection::connect()->prepare("SELECT value FROM configuration where id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        
        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchCUE($id){
        $stmt = Connection::connect()->prepare("SELECT * FROM entidades_educativas WHERE cue = :id");

        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);        
    }

    public static function searchCUE($name,$country,$province,$city){
        $where = '';
        if( !empty($name) ){
            $where = $where.' nombre like :name';
        }

        if( !empty($country) ){
            if(strlen($where)>0){
                $where = $where.' and';
            }
            $where = $where.' pais = :country';
        }

        if( !empty($province) ){
            if(strlen($where)>0){
                $where = $where.' and';
            }
            $where = $where.' provincia = :province';
        }

        if( !empty($city) ){
            if(strlen($where)>0){
                $where = $where.' and';
            }
            $where = $where.' localidad = :city';
        }

        $stmt = Connection::connect()->prepare("SELECT * FROM entidades_educativas WHERE ".$where." order by nombre limit 10");

        if( !empty($name) ){
            $nameFilter = '%'.$name.'%';
            $stmt->bindParam(':name', $nameFilter, PDO::PARAM_STR);
        }
        if( !empty($country) ){
            $stmt->bindParam(':country', $country, PDO::PARAM_STR);
        }
        if( !empty($province) ){
            $stmt->bindParam(':province', $province, PDO::PARAM_STR);
        }
        if( !empty($city) ){
            $stmt->bindParam(':city', $city, PDO::PARAM_STR);
        }

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);        
    }

    public static function searchCUEfilterValues($country,$province){
        $field = 'pais';
        $where = '';

        if( !empty($country) ) {
            $where = $where.'WHERE pais = :country';
            $field = 'provincia';
            if( !empty($province) ){
                $where = $where.' and provincia = :province';
                $field = 'localidad';
            }
        }
        $stmt = Connection::connect()->prepare("SELECT ".$field." as item FROM entidades_educativas ".$where." group by 1 order by 1");

        if( !empty($country) ){
            $stmt->bindParam(':country', $country, PDO::PARAM_STR);
        }
        if( !empty($province) ){
            $stmt->bindParam(':province', $province, PDO::PARAM_STR);
        }

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);        
    }

    public static function checkAdmissionCode($code){
        $stmt = Connection::connect()->prepare("SELECT nombre FROM especialidades WHERE id=:code");

        $stmt->bindParam(':code', $code, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function fetchPrettyInscription($id){
        $stmt = Connection::connect()->prepare("SELECT concat('NOMBRE: ',alumnonombres,' ',alumnoapellido,' con ',(SELECT cp1.display FROM config_params cp1 where cp1.field='alumnotipodocumento' and cp1.value=i.alumnotipodocumento),': ',alumnonumerodocumento,' inscripción a CARRERA: ',e.nombre, ifNULL((SELECT concat(' - SEDE: ',cp2.display) FROM config_params cp2 where cp2.field='lugarcursado' and cp2.value=i.lugarcursado),'')) as descripcion FROM inscriptions i join especialidades e on i.carrera=e.id WHERE i.id=:id");

        $stmt->bindParam(':id', $id, PDO::PARAM_STR);

        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public static function isCloseCarrerForInscription($id){
        $db = Connection::connect();

        $stmt = $db->prepare("SELECT carrera from inscriptions WHERE id=:id");
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        $stmt->execute();

        $carrera = $stmt->fetchColumn();


        $stmt = $db->prepare("SELECT count(1) from configuration WHERE id='OPEN_CARRE' and (value rlike '^".$carrera.",|,".$carrera.",|,".$carrera."$' or value rlike '^".$carrera." | ".$carrera." | ".$carrera."$')");
        $stmt->execute();

        return ($stmt->fetchColumn()==0);
    }

    public static function isCloseCarrer($id){
        $db = Connection::connect();

        $carrera = $id;

        $stmt = $db->prepare("SELECT count(1) from configuration WHERE id='OPEN_CARRE' and (value rlike '^".$carrera.",|,".$carrera.",|,".$carrera."$' or value rlike '^".$carrera." | ".$carrera." | ".$carrera."$')");
        $stmt->execute();

        return ($stmt->fetchColumn()==0);
    }

}
?>