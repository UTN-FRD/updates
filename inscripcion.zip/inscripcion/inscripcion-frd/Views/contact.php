<div class="modal fade" id="contactModal" tabindex="-1" role="dialog" aria-labelledby="contactModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="contactModalLabel">Contacto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="row">
			<div class="col">

				<div class="alert alert-success collapse"></div>
				<form id="contact-form">
					<div class="form-group">
						<label for="formcontactocorreo">Correo electrónico</label>
						<input type="email" class="form-control" id="formcontactocorreo" name="formcontactocorreo" >
						<div class="invalid-feedback">Es necesario ingresar un medio de contacto. Debe ser un correo electrónico válido.</div>
					</div>
					<div class="form-group">
						<label for="formcontactotel">Teléfono</label>
						<input type="tel" class="form-control" id="formcontactotel" name="formcontactotel" >
						<div class="invalid-feedback">Es necesario ingresar un medio de contacto.</div>
					</div>
					<div class="form-group">
						<label for="formcontactomensaje">Mensaje</label>
						<textarea id="formcontactomensaje" name="formcontactomensaje" class="form-control" rows="5"></textarea>
						<div class="invalid-feedback">Este valor es obligatorio.</div>
					</div>
				</form>
			</div>
		</div>
      </div>
      <div class="modal-footer">
		<button type="button" id="formcontactosend" class="btn btn-info"><span class="collapse"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span><span>Loading...</span></span><span>Enviar Mensaje</span></button>
      </div>
    </div>
  </div>
</div>
<script>
$('#formcontactocorreo, #formcontactotel').keypress(function(){
	$('#formcontactocorreo, #formcontactotel').siblings('.invalid-feedback').hide();
});
$('#formcontactomensaje').keypress(function(){
	$(this).siblings('.invalid-feedback').hide();
});
$('#formcontactosend').click(function(){
	var valid = true;
	if(($('#formcontactocorreo').val()=='' && $('#formcontactotel').val()=='')){
		$('#formcontactocorreo, #formcontactotel').siblings('.invalid-feedback').show();
		valid = false;
	}else{
		if($('#formcontactocorreo').val()!=''){
        	if( ! /\S+@\S+\.\S+/.test($('#formcontactocorreo').val()) ){
        		$('#formcontactocorreo').siblings('.invalid-feedback').show();
        		valid = false;
        	}
		}
	}
	if($('#formcontactomensaje').val()==''){
		$('#formcontactomensaje').siblings('.invalid-feedback').show();
		valid = false;
	}
	if(!valid) return;
	$('button#formcontactosend>span:nth-child(1)').removeClass('collapse');
	$('button#formcontactosend>span:nth-child(2)').addClass('collapse');
	$('button#formcontactosend').attr('disabled', true);
	$.ajax({
		type: 'POST',
		url: './ajax/sendMessage.php',
		data:'correo='+$('#formcontactocorreo').val()+'&tel='+$('#formcontactotel').val()+'&msg='+$('#formcontactomensaje').val(),
		success: function(data){
			$('#contactModal .alert').append(data);
			$('#contactModal .alert').show();
			setTimeout(function(){
				$('#contactModal').modal('hide');
				$('#formcontactocorreo').val('');
				$('#formcontactotel').val('');
				$('#formcontactomensaje').val('');
				$('button#formcontactosend>span:nth-child(1)').addClass('collapse');
				$('button#formcontactosend>span:nth-child(2)').removeClass('collapse');
				$('button#formcontactosend').attr('disabled', false);
				$('#contactModal .alert').hide();
				$('#contact-form .invalid-feedback').hide();
			},3000);

		}
	});

});
</script>



