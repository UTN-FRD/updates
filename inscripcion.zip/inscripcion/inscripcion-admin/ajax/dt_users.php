<?php

$table = 'users';
$primaryKey = 'id';
 
$col = 0;
$columns = array(
    array( 'db' => 'username',  'dt' => $col++ ),
    array( 'db' => 'email', 'dt' => $col++ ),
    array( 'db' => 'role',  'dt' => $col++ ),
    array( 'db' => 'id', 'dt' => $col++ )
);

require( '../vendor/ssp.class.php' );
require( '../Modells/Connection.php' );
 
echo json_encode(
    SSP::simple( $_GET, $GLOBALS['sql_details'], $table, $primaryKey, $columns )
);