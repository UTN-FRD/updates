#!/bin/sh
# Nombre de la base de datos: inscripcionsysacad
dbname="inscripcionsysacad"
# Usuario de la base de datos: inscripsysacad
dbuser="inscripsysacad"
dbhost="localhost"

read -p "Usuario MySQL [default:root]" dbroot
if [ ! -n "$dbroot" ];
then 
   dbroot="root"
fi

read -p "Password de $dbroot" dbrootpass
if [ ! -n "$dbrootpass" ];
then 
   dbrootpass=""
fi

echo '
[client]
user='$dbroot'
password='$dbrootpass'

' > xn

echo '
REVOKE ALL PRIVILEGES FROM '"'"''$dbuser''"'"'@'"'"''$dbhost''"'"';
DROP DATABASE IF NOT EXISTS `'$dbname'`;
DROP USER '"'"''$dbuser''"'"'@'"'"''$dbhost''"'"';
FLUSH PRIVILEGES;

' > dbremove.sql

mysql --defaults-extra-file=xn < dbremove.sql

rm -rf *

echo 'Fin del proceso!'

