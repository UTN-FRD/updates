<?php
require_once('Controllers/Controller.php');
$controller = new Controller();
?>
<h2>Inscripción por excepción</h2>
<h2 id="c-name">

<?php if(isset($_GET['c'])){ ?>
Inscripci&oacute;n a la Carrera: <?= $controller->getCareer($_GET['c']) ?>
<?php } ?>
</h2>
<div class="row">
	<div class="col">
		<p>La inscripción por excepción permite crear una inscripción fuera el período de inscripciones. Se envía el link por email para continuar con la inscripción.</p>
		<p></p>
	</div>
</div>

<div class="row">
	<div class="col">
		<div id="msg" class="alert collapse" role="alert"></div>
		<form id="registration-form" method="POST" class="needs-validation" novalidate autocomplete="off">
			<div class="form-group">
				<label for="carrera">Carrera</label>
				<input type="text" class="form-control" name="carrera">
			</div>
			<div class="form-group">
				<label for="alumnonumerodocumento">Número de Documento</label>
				<input type="text" class="form-control" id="alumnonumerodocumento" name="alumnonumerodocumento" required>
				<div class="invalid-feedback">Este valor es obligatorio.</div>
			</div>
			<div class="form-group">
				<label for="contactoemail">Ingrese su correo electrónico</label>
				<input type="email" class="form-control" id="contactoemail" name="contactoemail" required>
				<div class="invalid-feedback">Este valor es obligatorio y debe coincidir con la repetición del correo electrónico.</div>
			</div>
			<center>
				
				<button type="submit" class="btn btn-info"><span class="collapse"><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span><span>Loading...</span></span><span>Registrar</span></button>
			</center>
			<br>
		</form>
	</div>
</div>
<script>
function error(msg){
	$( '#admissionModal' ).remove();
	$('#msg').addClass('alert-danger');
	$('#msg').html('Ocurrió un error al registrar la inscripción, '+msg+'.<br>Por favor intente más tarde o póngase en contacto con nosotros.');
	$('#msg').show(200);
}
function success(msg){
	$( '#admissionModal' ).remove();
	$('form').hide(200);
	$('#msg').addClass('alert-success');
	$('#msg').append(msg);
	$('#msg').show(200);
}
function inscripto(){
	$( '#admissionModal' ).remove();
	$('#msg').addClass('alert-warning');
	$('#msg').html('Ya existe una inscripci&oacute;n previa para este documento.');
	$('#msg').show(200);	
}
$(document).ready(function(){
	/*** Form validation ***/
	$('.needs-validation').submit(function(event){
		if (this.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }else{
        	$('button>span:nth-child(1)').removeClass('collapse');
        	$('button>span:nth-child(2)').addClass('collapse');
        	$('button').attr('disabled', true);
//            $('#registration-form').unbind('submit').submit();
        }
        $(this).addClass('was-validated');
	});
	$("#contactoemail, #contactoemailcheck").keypress(function(e){
		$("#validateemail").addClass('collapse');
	});
});
</script>
<?php
    $controller -> registerInscription();
?>

