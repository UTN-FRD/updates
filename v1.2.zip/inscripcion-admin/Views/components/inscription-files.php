<section>
	<h2>Documentación</h2>
	<br><br>
	<div id="documentacion" class="row">
		<div class="col-12 question">
			<h3>DNI</h3>
			<div id="documentaciondni"></div>
		</div>
		<div class="col-12 question">
			<h3>CUIL</h3>
			<div id="documentacioncuil"></div>
		</div>
		<div class="col-12 question">
			<h3>Partida de Nacimiento</h3>
			<div id="documentacionnacimiento"></div>
		</div>
		<div class="col-12 question">
			<h3>Analítico</h3>
			<div id="documentacionanalitico"></div>
		</div>
		<div class="col-12 question">
			<h3>Título de grado</h3>
			<div id="documentaciontitulogrado"></div>
		</div>
		<div class="col-12 question">
			<h3>CV</h3>
			<div id="documentacioncv"></div>
		</div>
		<div class="col-12 question">
			<h3>Certificado de T&iacute;tulo en tr&aacute;mite</h3>
			<div id="documentacioncertmaterias"></div>
		</div>
	</div>
</section>
<script src="js/pdfjs/build/pdf.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#documentacion>div>div").each(function(){
		if(savedValues[$(this).attr('id')]){
			var file = savedValues[$(this).attr('id')];
			var url = '<?= $controller->getDocumentsUrl()?>/'+savedValues['id']+'/'+file;
			if(file.endsWith('pdf')){
				$(this).html($('<a/>',{'href':url,'text':'Descargar PDF','target':'_documents'}));
				$(this).append($('<canvas/>',{'id':$(this).attr('id')+'canvas'}))
				showPDF( url, $(this).attr('id')+'canvas' );
			}else{
				$(this).html($('<a/>',{'href':url,'text':'Descargar Imagen','target':'_documents'}));
				$(this).append($('<img/>',{'width':'100%','src':url}));
			}
		}
	});

});
</script>
<style>
#documentacion canvas,#documentacion img{border:solid 1px;width:100%}
#documentacion>div>div{align-content:center}
</style>
