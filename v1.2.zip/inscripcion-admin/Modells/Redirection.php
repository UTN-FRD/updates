<?php
class Redirection {
    public static function showPage($action){
        $route = "Views/unauthorized.php";
        $admin_actions = array("home","inscription-form","closed","all","exported","conf","questions","inscexc","sysacad","usuarios");
        $supervisor_actions = array("inscription-form","all","export");
        $consumidor_actions = array("export");
        if($_SESSION['rol'] == 'Admin'){
            if( in_array($action, $admin_actions) || in_array($action, $consumidor_actions) ){
                $route = "Views/". $action .".php";
            }else{
                $route = "Views/home.php";
            }
        }

        if($_SESSION['rol'] == 'Supervisor'){
            if( in_array($action, $supervisor_actions) ){
                $route = "Views/". $action .".php";
            }else{
                $route = "Views/all.php";
            }
        }

        if($_SESSION['rol'] == 'Consumidor'){
            if( in_array($action, $consumidor_actions) ){
                $route = "Views/". $action .".php";
            }else{
                $route = "Views/export.php";
            }
        }
        return $route;
    }
}