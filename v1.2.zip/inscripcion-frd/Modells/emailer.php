<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once(dirname(__FILE__).'/../vendor/autoload.php');
require_once('Data.php');

class Emailer {
	static $baseurl = '';
	static $replyTo = '';
	static $marca = '';

	static $signature = '';
	static $closeMsg = '';

	public static function fetchEmailParams(){
		$config = Data::fetchEmailConfiguration();
		Self::$replyTo = $config['EMAIL_SEND'];
		Self::$marca = $config['EMAIL_SUBJ'];
		Self::$baseurl = $config['EMAIL_URL'];
		Self::$signature = $config['EMAIL_SIGN'];
		Self::$closeMsg = $config['EMAIL_CLOS'];
	}
	public static function enviar($destinatario, $replyTo, $asunto, $mensaje) {
		$mail = new PHPMailer(true);

		try {
			$mail->SMTPDebug = 0;
			$mail->isSMTP();
			$mail->CharSet    = 'UTF-8';
			$mail->Host       = 'smtp.gmail.com';
			$mail->SMTPAuth   = true;
			$mail->Username   = $GLOBALS['emailAdmin'];
			$mail->Password   = $GLOBALS['emailPass'];
			$mail->SMTPSecure = 'ssl';
			$mail->Port       = 465;

			if( !empty($replyTo) ){
				$mail->addReplyTo($replyTo);
			}
			$mail->setFrom($GLOBALS['emailAdmin'],Self::$marca);
			$mail->addAddress($destinatario);
			// Content
			$mail->isHTML(true);
			$mail->Subject = $asunto;
			$mail->Body    = '<p>' . $mensaje . '</p>';
			$mail->AltBody = $mensaje;

			$mail->send();
			return 'success';
		} catch (Exception $e) {
			return "Error: {$mail->ErrorInfo}";
		}
	}

	public static function sendContactMessage($correo, $tel, $msg) {
		Emailer::fetchEmailParams();
		if(!$correo){
			$correo = Self::$replyTo;
		}
		return Emailer::enviar(Self::$replyTo, $correo, Self::$marca.' - Formulario de contacto', 'Hola, se ha recibido un nuevo mensaje en el formulario de contacto.<br><b>De: </b> '.$correo.'<br><b>Tel&eacute;fono: </b>'.$tel.'<br><b>Mensaje:</b><br>'.$msg);
	}

	public static function enviarURL($correo, $id, $token){
		Emailer::fetchEmailParams();
		Emailer::enviar($correo, Self::$replyTo, Self::$marca, 'Hola,<br><br>Enviamos este correo para continuar con su proceso de inscripci&oacute;n.<br><br>Conserve este mensaje hasta completar la inscripci&oacute;n. En caso de no completarla, podr&aacute; reutilizar el link adjunto para acceder cuantas veces sea necesario, los valores ya ingresados ser&aacute;n guardados en la medida que los vaya cargando.<br><br><br><a href="'.Self::$baseurl.'?utm_source=registro_nuevo&action=inscription&id='.$id.'&token='.$token.'" style="background-color:#49bb97;color: #FFFFFF;padding:1rem;margin:2rem;border-radius:20px;">Continuar Inscripci&oacute;n</a><br><br><br> o bien copie y pegue la siguiente url en su navegador:<br>'.Self::$baseurl.'?action=inscription&id='.$id.'&token='.$token.'<br><br>Ante cualquier inquietud, no dude en comunicarse con nosotros a trav&eacute;s de nuestra web o respondiendo este correo electr&oacute;nico.<br>'.Self::$signature);
	}

	public static function enviarConfirmacion($correo, $id, $detail){
		Emailer::fetchEmailParams();
		Emailer::enviar($correo, Self::$replyTo, Self::$marca, 'Hola,<br><br>Enviamos este correo para confirmar su solicitud de ingreso con los siguientes datos:<br><h3>'.$detail.'</h3>'.Self::$closeMsg.'<br><br>Ante cualquier inquietud, no dude en comunicarse con nosotros a trav&eacute;s de nuestra web o respondiendo este correo electr&oacute;nico.<br>'.Self::$signature);
	}

	public static function enviarConfirmacionCorreccion($correo, $id){
		Emailer::fetchEmailParams();
		Emailer::enviar($correo, Self::$replyTo, Self::$marca, 'Hola,<br><br>Enviamos este correo para confirmar que ha modificado su solicitud de ingreso.<br><br>A la brevedad ser&aacute; controlado nuevamente y le avisaremos por este medio cualquier cambio.<br><br>Ante cualquier inquietud, no dude en comunicarse con nosotros a trav&eacute;s de nuestra web o respondiendo este correo electr&oacute;nico.<br>'.Self::$signature);
	}
}
